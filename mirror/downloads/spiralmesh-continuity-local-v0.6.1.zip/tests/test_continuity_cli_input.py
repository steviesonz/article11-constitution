"""Focused CLI stdin checks; synthetic stores, stdlib only, no model calls.

Run from a checkout or extracted continuity bundle:
    python -S -B tests/test_continuity_cli_input.py
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'src'
sys.path.insert(0, str(SOURCE))

from spiralmesh.continuity.mcp import MAX_INPUT
from spiralmesh.continuity.store import MemoryLibrary

BOM = b'\xef\xbb\xbf'


class ContinuityCLIInputTests(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(prefix='continuity-cli-input-')
        self.directory = Path(self.scratch.name)
        self.root = self.directory / 'synthetic-library'
        self.library = MemoryLibrary(self.root, 'codex', create=True)

    def tearDown(self):
        self.scratch.cleanup()

    def call(self, payload, operation='browse'):
        env = dict(os.environ, PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1')
        result = subprocess.run([sys.executable, '-S', '-B', '-m', 'spiralmesh.continuity.cli',
            '--root', str(self.root), '--principal', 'codex', 'call', operation],
            input=payload, capture_output=True, env=env, timeout=20)
        self.assertEqual(result.stderr, b'')
        return result.returncode, json.loads(result.stdout)

    def refused_without_write(self, payload, error, operation='remember'):
        before = self.library.path.read_bytes()
        code, result = self.call(payload, operation)
        self.assertEqual(code, 1)
        self.assertEqual(result['error'], error)
        self.assertFalse(result.get('persisted', False))
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_plain_and_single_bom_json_have_same_result(self):
        plain = self.call(b'{}')
        self.assertEqual(plain[0], 0)
        self.assertEqual(self.call(BOM + b'{}'), plain)
        self.assertEqual(self.call(BOM + b' \t\r\n{}\n'), plain)

    def test_plain_and_bom_remember_persist_unicode_with_verified_readback(self):
        for index, prefix in enumerate([b'', BOM]):
            with self.subTest(bom=bool(prefix)):
                value = {'title': 'Synthetic caf\u00e9', 'body': 'Only test data: \u6d77 \U0001f332',
                         'operation_id': 'stdin-example-' + str(index)}
                payload = prefix + json.dumps(value, ensure_ascii=False).encode('utf-8')
                code, saved = self.call(payload, 'remember')
                self.assertEqual(code, 0)
                self.assertTrue(saved['ok'] and saved['persisted'] and saved['readback_verified'])
                self.assertEqual(saved['storage_outcome'], 'committed')
                observed = MemoryLibrary(self.root, 'codex').read(saved['note_id'])
                self.assertEqual((observed['title'], observed['body']), (value['title'], value['body']))

    def test_bom_inside_a_json_string_is_preserved(self):
        value = {'title': 'Synthetic', 'body': '\ufeffinside the body'}
        code, saved = self.call(BOM + json.dumps(value, ensure_ascii=False).encode('utf-8'), 'remember')
        self.assertEqual(code, 0)
        self.assertEqual(self.library.read(saved['note_id'])['body'], value['body'])

    def test_malformed_json_and_nonfinite_numbers_still_refuse(self):
        for payload in [b'{', BOM + b'{', BOM + b'{} {}', BOM + b'{"title":"x","body":NaN}']:
            with self.subTest(payload=payload):
                self.refused_without_write(payload, 'INVALID_JSON')

    def test_repeated_or_displaced_bom_still_refuses(self):
        for payload in [BOM + BOM + b'{}', b' ' + BOM + b'{}', b'{}' + BOM]:
            with self.subTest(payload=payload):
                self.refused_without_write(payload, 'INVALID_JSON')

    def test_request_size_counts_bom_bytes_before_removal(self):
        at_limit = b' ' * (MAX_INPUT - 2) + b'{}'
        self.assertEqual(self.call(at_limit)[0], 0)
        self.refused_without_write(BOM + at_limit, 'REQUEST_TOO_LARGE', 'browse')

    def test_bom_does_not_admit_nonobject_or_host_override_arguments(self):
        for value in [[], {'title': 'Synthetic', 'body': 'test', 'principal': 'claude'},
                      {'title': 'Synthetic', 'body': 'test', 'root': 'elsewhere'}]:
            with self.subTest(value=value):
                plain_code, plain_error = self.call(json.dumps(value).encode(), 'remember')
                self.assertEqual(plain_code, 1)
                self.refused_without_write(BOM + json.dumps(value).encode(), plain_error['error'])

    @unittest.skipUnless(os.name == 'nt', 'Built-in Windows PowerShell regression')
    def test_windows_powershell_utf8_preamble_first_save(self):
        system_root = os.environ.get('SystemRoot')
        if not system_root:
            self.skipTest('SystemRoot unavailable')
        shell = Path(system_root) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
        if not shell.is_file():
            self.skipTest('Built-in powershell.exe unavailable')
        script = self.directory / 'first_save.ps1'
        script.write_text('''param([string]$Python, [string]$Source, [string]$Library)
$ErrorActionPreference = 'Stop'
$env:PYTHONPATH = $Source
$env:PYTHONDONTWRITEBYTECODE = '1'
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
'{"title":"First shell save","body":"Synthetic caf\\u00e9 note","operation_id":"first-shell-save"}' | & $Python -S -B -m spiralmesh.continuity.cli --root $Library --principal codex call remember
exit $LASTEXITCODE
''', encoding='ascii')
        result = subprocess.run([str(shell), '-NoProfile', '-NonInteractive', '-File', str(script),
            '-Python', sys.executable, '-Source', str(SOURCE), '-Library', str(self.root)],
            capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        saved = json.loads(result.stdout.decode('utf-8-sig'))
        self.assertTrue(saved['ok'] and saved['persisted'] and saved['readback_verified'])
        self.assertEqual(saved['storage_outcome'], 'committed')
        readback = MemoryLibrary(self.root, 'codex').read(saved['note_id'])
        self.assertEqual(readback['body'], 'Synthetic caf\u00e9 note')


if __name__ == '__main__':
    unittest.main()
