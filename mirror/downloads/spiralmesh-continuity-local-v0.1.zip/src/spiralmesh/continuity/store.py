"""Local Article 11 memory API, scoped to a principal by its trusted launcher.

Model-facing operations take identifiers and text, never filesystem paths or a
replacement principal. This is an application capability boundary, not a claim
that the host administrator cannot read the SQLite file.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import uuid


PROFILE = "spiralmesh.participant-memory.v1"
KINDS = {"observation", "reported", "inference", "decision", "question", "journal"}
PRINCIPALS = {"codex", "claude"}


class MemoryError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def string(value, name, maximum=200_000, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
        raise MemoryError("INVALID_" + name.upper())
    return value


class MemoryLibrary:
    """The caller binding is host-supplied, never accepted from tool arguments."""

    def __init__(self, root, principal, instance_id="host", create=False):
        if principal not in PRINCIPALS:
            raise MemoryError("UNKNOWN_PRINCIPAL")
        self.root = Path(root).resolve()
        self.path = self.root / "memory.sqlite3"
        self.principal = principal
        self.instance_id = string(instance_id, "instance", 200)
        if create:
            self.root.mkdir(parents=True, exist_ok=True)
            with self.db(write=True) as db:
                db.executescript("""
                CREATE TABLE IF NOT EXISTS notes(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  owner TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,
                  kind TEXT NOT NULL,sources TEXT NOT NULL,created_at TEXT NOT NULL,
                  instance_id TEXT NOT NULL,state TEXT NOT NULL,supersedes TEXT,
                  content_sha256 TEXT NOT NULL,origin TEXT NOT NULL DEFAULT '{}');
                CREATE TABLE IF NOT EXISTS grants(
                  note_id TEXT NOT NULL,recipient TEXT NOT NULL,
                  PRIMARY KEY(note_id,recipient));
                CREATE TABLE IF NOT EXISTS letters(owner TEXT PRIMARY KEY,note_id TEXT);
                CREATE TABLE IF NOT EXISTS messages(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  sender TEXT NOT NULL,recipient TEXT NOT NULL,subject TEXT NOT NULL,
                  body TEXT NOT NULL,created_at TEXT NOT NULL,instance_id TEXT NOT NULL,
                  correlation_id TEXT);
                CREATE TABLE IF NOT EXISTS receipts(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  principal TEXT NOT NULL,instance_id TEXT NOT NULL,at TEXT NOT NULL,
                  operation TEXT NOT NULL,refs TEXT NOT NULL,previous TEXT NOT NULL,
                  digest TEXT NOT NULL);
                """)
        if not self.path.is_file():
            raise MemoryError("LIBRARY_NOT_INITIALIZED")

    @contextmanager
    def db(self, write=False):
        uri = self.path.as_uri() + ("?mode=rwc" if write else "?mode=ro")
        conn = sqlite3.connect(uri, uri=True, timeout=15)
        conn.row_factory = sqlite3.Row
        try:
            if write:
                conn.execute("PRAGMA secure_delete=ON")
                conn.execute("PRAGMA journal_mode=DELETE")
                conn.execute("BEGIN IMMEDIATE")
            yield conn
            if write:
                conn.commit()
        except BaseException:
            if write:
                conn.rollback()
            raise
        finally:
            conn.close()

    def _receipt(self, db, operation, refs):
        last = db.execute("SELECT digest FROM receipts ORDER BY seq DESC LIMIT 1").fetchone()
        record = {"id": "receipt_" + uuid.uuid4().hex, "principal": self.principal,
                  "instance_id": self.instance_id, "at": now(), "operation": operation,
                  "refs": refs, "previous": last[0] if last else ""}
        digest = sha(record)
        db.execute("INSERT INTO receipts(id,principal,instance_id,at,operation,refs,previous,digest) VALUES(?,?,?,?,?,?,?,?)",
                   (record["id"], self.principal, self.instance_id, record["at"], operation,
                    canonical(refs).decode(), record["previous"], digest))
        return {**record, "digest": digest, "origin": "local_launcher_asserted"}

    def _note(self, db, note_id, owner_only=False):
        string(note_id, "note_id", 100)
        row = db.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        if row is None or row["state"] == "forgotten":
            raise MemoryError("NOT_FOUND")
        if row["owner"] != self.principal:
            allowed = not owner_only and db.execute(
                "SELECT 1 FROM grants WHERE note_id=? AND recipient IN (?, 'shared')",
                (note_id, self.principal)).fetchone()
            if not allowed:
                raise MemoryError("NOT_FOUND")
        return row

    @staticmethod
    def _view(row):
        result = dict(row)
        result["sources"] = json.loads(result["sources"])
        result["origin"] = json.loads(result["origin"])
        result["authority"] = "context_only"
        return result

    def browse(self, query="", scope="own", cursor=0, limit=50):
        string(query, "query", 1000, empty=True)
        if scope not in {"own", "shared", "all"}:
            raise MemoryError("INVALID_SCOPE")
        if type(cursor) is not int or cursor < 0 or type(limit) is not int or not 1 <= limit <= 200:
            raise MemoryError("INVALID_PAGE")
        # Pagination bounds one response, not access to the rest of the library.
        own = "n.owner=?"
        shared = "EXISTS (SELECT 1 FROM grants g WHERE g.note_id=n.id AND g.recipient IN (?, 'shared'))"
        access = own if scope == "own" else shared if scope == "shared" else f"({own} OR {shared})"
        params = [self.principal] * (2 if scope == "all" else 1)
        with self.db() as db:
            rows = db.execute(f"SELECT n.* FROM notes n WHERE {access} AND n.state!='forgotten' "
                              "AND n.seq>? AND instr(lower(n.title||' '||n.body),lower(?))>0 ORDER BY n.seq LIMIT ?",
                              (*params, cursor, query, limit + 1)).fetchall()
        page = rows[:limit]
        return {"records": [{k: v for k, v in self._view(r).items() if k != "body"} for r in page],
                "next_cursor": page[-1]["seq"] if len(rows) > limit else None,
                "scope": scope, "complete_page": True,
                "note": "Read any listed id in full. Browse every page; the startup letter is not a recall boundary."}

    def read(self, note_id):
        with self.db() as db:
            return self._view(self._note(db, note_id))

    def _save(self, db, title, body, kind, sources, supersedes=None):
        string(title, "title", 300); string(body, "body")
        if kind not in KINDS:
            raise MemoryError("INVALID_KIND")
        if not isinstance(sources, list) or len(sources) > 100:
            raise MemoryError("INVALID_SOURCES")
        for source in sources:
            string(source, "source", 2000)
        content = {"title": title, "body": body, "kind": kind, "sources": sources}
        nid = "memory_" + uuid.uuid4().hex
        db.execute("INSERT INTO notes(id,owner,title,body,kind,sources,created_at,instance_id,state,supersedes,content_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (nid, self.principal, title, body, kind, canonical(sources).decode(), now(), self.instance_id,
                    "active", supersedes, sha(content)))
        return nid

    def remember(self, title, body, kind="observation", sources=None):
        with self.db(write=True) as db:
            nid = self._save(db, title, body, kind, [] if sources is None else sources)
            receipt = self._receipt(db, "remember", [nid])
        return {"note_id": nid, "shared": False, "receipt": receipt}

    def correct(self, note_id, title, body, kind="observation", sources=None):
        with self.db(write=True) as db:
            self._note(db, note_id, owner_only=True)
            nid = self._save(db, title, body, kind, [] if sources is None else sources, note_id)
            db.execute("UPDATE notes SET state='superseded' WHERE id=?", (note_id,))
            # A new version is private until deliberately shared. Existing grants
            # still expose the old version, now visibly marked superseded.
            db.execute("UPDATE letters SET note_id=? WHERE owner=? AND note_id=?", (nid, self.principal, note_id))
            receipt = self._receipt(db, "correct", [note_id, nid])
        return {"note_id": nid, "supersedes": note_id, "shared": False, "receipt": receipt}

    def share(self, note_id, recipient="shared"):
        if recipient not in PRINCIPALS | {"shared"}:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        with self.db(write=True) as db:
            self._note(db, note_id, owner_only=True)
            db.execute("INSERT OR IGNORE INTO grants VALUES(?,?)", (note_id, recipient))
            receipt = self._receipt(db, "share", [note_id, recipient])
        return {"note_id": note_id, "recipient": recipient, "receipt": receipt}

    def unshare(self, note_id, recipient="shared"):
        if recipient not in PRINCIPALS | {"shared"}:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        with self.db(write=True) as db:
            self._note(db, note_id, owner_only=True)
            db.execute("DELETE FROM grants WHERE note_id=? AND recipient=?", (note_id, recipient))
            receipt = self._receipt(db, "unshare", [note_id, recipient])
        return {"receipt": receipt, "limit": "Already read or exported copies cannot be recalled."}

    def forget(self, note_id):
        with self.db(write=True) as db:
            self._note(db, note_id, owner_only=True)
            db.execute("DELETE FROM grants WHERE note_id=?", (note_id,))
            db.execute("DELETE FROM letters WHERE owner=? AND note_id=?", (self.principal, note_id))
            db.execute("UPDATE notes SET title='',body='',sources='[]',origin='{}',content_sha256='',state='forgotten' WHERE id=?", (note_id,))
            receipt = self._receipt(db, "forget", [note_id])
        return {"forgotten": note_id, "receipt": receipt,
                "limit": "Clears this live record and revokes access. Separate versions, messages, exports, logs, backups and device remnants are not erased."}

    def set_letter(self, note_id):
        with self.db(write=True) as db:
            if note_id is not None:
                self._note(db, note_id, owner_only=True)
            db.execute("INSERT OR REPLACE INTO letters VALUES(?,?)", (self.principal, note_id))
            receipt = self._receipt(db, "set_letter", [] if note_id is None else [note_id])
        return {"letter": note_id, "receipt": receipt}

    def boot(self):
        with self.db() as db:
            row = db.execute("SELECT note_id FROM letters WHERE owner=?", (self.principal,)).fetchone()
            letter = self._view(self._note(db, row[0], owner_only=True)) if row and row[0] else None
            count = db.execute("SELECT COUNT(*) FROM notes WHERE owner=? AND state!='forgotten'", (self.principal,)).fetchone()[0]
        return {"profile": PROFILE, "principal": self.principal, "instance_id": self.instance_id,
                "offer": letter, "own_record_count": count, "inheritance": "offer_not_identity_or_authority",
                "choices": ["accept", "question", "decline"], "full_store_access": True,
                "instruction": "Your letter is optional context. All retained owner records remain browsable and readable; you may form new memories or decline."}

    def send(self, recipient, subject, body, correlation_id=None):
        if recipient not in PRINCIPALS or recipient == self.principal:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        string(subject, "subject", 300); string(body, "body")
        if correlation_id is not None:
            string(correlation_id, "correlation", 100)
        with self.db(write=True) as db:
            if correlation_id is not None:
                self._message(db, correlation_id)
            mid = "message_" + uuid.uuid4().hex
            db.execute("INSERT INTO messages(id,sender,recipient,subject,body,created_at,instance_id,correlation_id) VALUES(?,?,?,?,?,?,?,?)",
                       (mid, self.principal, recipient, subject, body, now(), self.instance_id, correlation_id))
            receipt = self._receipt(db, "send", [mid, recipient])
        return {"message_id": mid, "status": "available_in_local_inbox", "receipt": receipt}

    def _message(self, db, message_id):
        row = db.execute("SELECT * FROM messages WHERE id=? AND (sender=? OR recipient=?)",
                         (message_id, self.principal, self.principal)).fetchone()
        if row is None:
            raise MemoryError("NOT_FOUND")
        return row

    def message(self, message_id):
        string(message_id, "message_id", 100)
        with self.db() as db:
            return dict(self._message(db, message_id))

    def inbox(self, cursor=0, limit=50):
        if type(cursor) is not int or cursor < 0 or type(limit) is not int or not 1 <= limit <= 200:
            raise MemoryError("INVALID_PAGE")
        with self.db() as db:
            rows = db.execute("SELECT * FROM messages WHERE (sender=? OR recipient=?) AND seq>? ORDER BY seq LIMIT ?",
                              (self.principal, self.principal, cursor, limit + 1)).fetchall()
        return {"messages": [{k: v for k, v in dict(r).items() if k != "body"} for r in rows[:limit]],
                "next_cursor": rows[limit - 1]["seq"] if len(rows) > limit else None}

    def export(self):
        with self.db() as db:
            own = [self._view(r) for r in db.execute("SELECT * FROM notes WHERE owner=? AND state!='forgotten' ORDER BY seq", (self.principal,))]
            shared = [self._view(r) for r in db.execute("SELECT n.* FROM notes n WHERE n.owner!=? AND n.state!='forgotten' AND EXISTS(SELECT 1 FROM grants g WHERE g.note_id=n.id AND g.recipient IN (?, 'shared')) ORDER BY seq", (self.principal, self.principal))]
            messages = [dict(r) for r in db.execute("SELECT * FROM messages WHERE sender=? OR recipient=? ORDER BY seq", (self.principal, self.principal))]
        payload = {"profile": PROFILE, "principal": self.principal, "exported_at": now(),
                   "own": own, "shared": shared, "messages": messages, "letter": self.boot()["offer"],
                   "authority": "context_only", "origin": "local_launcher_asserted"}
        return {"payload": payload, "sha256": sha(payload),
                "verification_limit": "Digest detects changes relative to this export; it does not authenticate authorship or truth."}

    def import_export(self, bundle):
        if not isinstance(bundle, dict) or set(bundle) != {"payload", "sha256", "verification_limit"}:
            raise MemoryError("INVALID_EXPORT")
        p = bundle["payload"]
        if not isinstance(p, dict) or sha(p) != bundle["sha256"] or p.get("profile") != PROFILE or p.get("principal") != self.principal:
            raise MemoryError("EXPORT_BINDING_FAILED")
        # Only the owner's records enter the owner store. Shared records/messages
        # remain portable evidence in the export, never imported as new authorship.
        mapping = {}
        with self.db(write=True) as db:
            for note in p["own"]:
                if note.get("owner") != self.principal:
                    raise MemoryError("EXPORT_OWNER_MISMATCH")
                if note["id"] in mapping or note.get("state") not in {"active", "superseded"}:
                    raise MemoryError("INVALID_EXPORT_RECORD")
                content = {k: note[k] for k in ("title", "body", "kind", "sources")}
                if sha(content) != note["content_sha256"]:
                    raise MemoryError("EXPORT_CONTENT_MISMATCH")
                nid = self._save(db, note["title"], note["body"], note["kind"], note["sources"])
                origin = {"export_sha256": bundle["sha256"], "record_id": note["id"],
                          "instance_id": note["instance_id"], "created_at": note["created_at"]}
                db.execute("UPDATE notes SET origin=? WHERE id=?", (canonical(origin).decode(), nid))
                mapping[note["id"]] = nid
            for note in p["own"]:
                if note.get("supersedes") in mapping:
                    db.execute("UPDATE notes SET supersedes=? WHERE id=?", (mapping[note["supersedes"]], mapping[note["id"]]))
                if note.get("state") == "superseded":
                    db.execute("UPDATE notes SET state='superseded' WHERE id=?", (mapping[note["id"]],))
            if p.get("letter") and p["letter"]["id"] in mapping:
                db.execute("INSERT OR REPLACE INTO letters VALUES(?,?)", (self.principal, mapping[p["letter"]["id"]]))
            receipt = self._receipt(db, "import_export", list(mapping.values()))
        return {"imported": mapping, "receipt": receipt, "shared_republished": False}

    def dispatch(self, operation, arguments):
        if operation not in OPERATIONS or not isinstance(arguments, dict):
            raise MemoryError("UNKNOWN_OPERATION")
        import inspect
        target = getattr(self, operation)
        try:
            inspect.signature(target).bind(**arguments)
        except TypeError as e:
            raise MemoryError("INVALID_ARGUMENTS") from e
        return target(**arguments)


OPERATIONS = ("boot", "browse", "read", "remember", "correct", "share", "unshare", "forget",
              "set_letter", "send", "message", "inbox", "export", "import_export")


def verify_export(bundle):
    return isinstance(bundle, dict) and isinstance(bundle.get("payload"), dict) and sha(bundle["payload"]) == bundle.get("sha256")
