"""Human launcher: reopen a participant's library and start a bounded dialogue."""
import argparse
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("principal", choices=("codex", "claude"))
    parser.add_argument("--root", help="Host-selected private memory directory")
    args = parser.parse_args()
    package = Path(__file__).resolve().parents[1]
    existing = package / ".continuity-data"
    # This checkout already has an authorized library. A clean extracted fork
    # keeps newly created private data outside the distributable source tree.
    root = Path(args.root).resolve() if args.root else (
        existing if existing.is_dir() else package.parent / (package.name + "-memory"))
    sys.path.insert(0, str(package / "src"))
    from spiralmesh.continuity.store import MemoryLibrary
    from spiralmesh.continuity.runner import main as dialogue_main
    MemoryLibrary(root, args.principal, "human-launcher", create=True)
    print("Article11 memory for " + args.principal)
    print("Private local library: " + str(root))
    print("Cloud inference uses your existing CLI login and provider usage.")
    print("Your whole authorized library is available; an empty task closes the session.")
    sys.argv = [sys.argv[0], "--root", str(root), "--principal", args.principal, "--interactive"]
    dialogue_main()


if __name__ == "__main__":
    main()
