"""Participant memory boundaries exercised with synthetic temporary stores only."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from spiralmesh.continuity.store import MemoryError, MemoryLibrary, sha, verify_export


class ContinuityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="spiralmesh-continuity-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "article11-memory"
        self.codex = MemoryLibrary(self.root, "codex", "codex-test-1", create=True)
        self.claude = MemoryLibrary(self.root, "claude", "claude-test-1")

    def note(self, library, title="Test note", body="Synthetic project observation.", **kwargs):
        return library.remember(title, body, **kwargs)["note_id"]

    def receipt_count(self, library=None):
        with (library or self.codex).db() as db:
            return db.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]

    def all_records(self, library, scope="all", limit=50):
        cursor, records = 0, []
        while True:
            page = library.browse(scope=scope, cursor=cursor, limit=limit)
            records.extend(page["records"])
            if page["next_cursor"] is None:
                return records
            self.assertGreater(page["next_cursor"], cursor)
            cursor = page["next_cursor"]

    def test_owner_private_notes_cannot_be_read_changed_shared_forgotten_or_exported_by_peer(self):
        secret = "SYNTHETIC-CLAUDE-PRIVATE-ONLY"
        note_id = self.note(self.claude, body=secret)
        self.assertEqual(self.codex.browse(scope="all")["records"], [])
        self.assertEqual(self.codex.browse(query=secret, scope="all")["records"], [])
        before = self.receipt_count()
        forbidden = {
            "read": lambda: self.codex.read(note_id),
            "correct": lambda: self.codex.correct(note_id, "Replacement", "Wrong owner"),
            "share": lambda: self.codex.share(note_id),
            "unshare": lambda: self.codex.unshare(note_id),
            "forget": lambda: self.codex.forget(note_id),
            "set_letter": lambda: self.codex.set_letter(note_id),
        }
        for operation, call in forbidden.items():
            with self.subTest(operation=operation), self.assertRaises(MemoryError):
                call()
        self.assertEqual(self.receipt_count(), before)
        self.assertNotIn(secret, json.dumps(self.codex.export()))
        self.assertEqual(self.claude.read(note_id)["body"], secret)

    def test_dispatch_cannot_replace_principal_or_supply_filesystem_paths(self):
        own = self.note(self.codex)
        candidate_arguments = {
            "boot": {}, "browse": {}, "read": {"note_id": own},
            "remember": {"title": "Untouched", "body": "Untouched"},
            "correct": {"note_id": own, "title": "Untouched", "body": "Untouched"},
            "share": {"note_id": own}, "unshare": {"note_id": own},
            "forget": {"note_id": own}, "set_letter": {"note_id": own},
            "send": {"recipient": "claude", "subject": "Untouched", "body": "Untouched"},
            "message": {"message_id": "message_missing"}, "inbox": {},
            "export": {}, "import_export": {"bundle": self.codex.export()},
        }
        before = self.root.joinpath("memory.sqlite3").read_bytes()
        for operation, arguments in candidate_arguments.items():
            for key, value in (("principal", "claude"), ("root", str(self.root)),
                               ("path", str(Path(self.temp.name) / "other.sqlite3"))):
                with self.subTest(operation=operation, extra=key), self.assertRaises(MemoryError):
                    self.codex.dispatch(operation, {**arguments, key: value})
        for operation in ("db", "_save", "__init__", "read_text"):
            with self.subTest(operation=operation), self.assertRaises(MemoryError):
                self.codex.dispatch(operation, {})
        external = Path(self.temp.name) / "unrelated.txt"
        external.write_text("SYNTHETIC-EXTERNAL-FILE", encoding="utf-8")
        with self.assertRaises(MemoryError):
            self.codex.dispatch("read", {"note_id": str(external)})
        self.assertEqual(external.read_text(encoding="utf-8"), "SYNTHETIC-EXTERNAL-FILE")
        self.assertEqual(self.root.joinpath("memory.sqlite3").read_bytes(), before)

    def test_complete_pagination_keeps_old_unrelated_notes_accessible(self):
        oldest = self.note(self.codex, "Unrelated garden observation", "OLD-UNRELATED-SYNTHETIC")
        expected = [oldest]
        for index in range(207):
            expected.append(self.note(self.codex, f"Recent technical note {index}", f"Synthetic {index}"))
        self.note(self.claude, "Not part of Codex pagination", "PRIVATE-PEER")
        self.codex.set_letter(expected[-1])
        first = self.codex.browse(limit=200)
        self.assertEqual(len(first["records"]), 200)
        self.assertIsNotNone(first["next_cursor"])
        fresh = MemoryLibrary(self.root, "codex", "codex-test-fresh")
        records = self.all_records(fresh, scope="own", limit=200)
        self.assertEqual([r["id"] for r in records], expected)
        self.assertTrue(all("body" not in r for r in records))
        self.assertEqual(fresh.read(oldest)["body"], "OLD-UNRELATED-SYNTHETIC")
        self.assertEqual(fresh.boot()["own_record_count"], 208)
        self.assertTrue(fresh.boot()["full_store_access"])

    def test_sharing_is_explicit_and_revocation_removes_future_access(self):
        for recipient in ("claude", "shared"):
            with self.subTest(recipient=recipient):
                own = self.note(self.codex, body="SHARED-ONLY-AFTER-CHOICE")
                with self.assertRaises(MemoryError):
                    self.claude.read(own)
                self.codex.share(own, recipient)
                self.assertEqual(self.claude.read(own)["owner"], "codex")
                self.assertIn(own, [r["id"] for r in self.claude.browse(scope="shared")["records"]])
                exported_before = self.claude.export()
                self.assertIn(own, [r["id"] for r in exported_before["payload"]["shared"]])
                self.codex.unshare(own, recipient)
                fresh_peer = MemoryLibrary(self.root, "claude", "after-revocation")
                with self.assertRaises(MemoryError):
                    fresh_peer.read(own)
                self.assertNotIn(own, [r["id"] for r in fresh_peer.export()["payload"]["shared"]])
                self.assertTrue(verify_export(exported_before))

    def test_correction_is_private_and_previously_shared_version_is_visibly_superseded(self):
        original = self.note(self.codex, "Earlier observation", "OLDER-SYNTHETIC-VERSION")
        self.codex.set_letter(original)
        self.codex.share(original)
        corrected = self.codex.correct(original, "Corrected observation", "NEW-PRIVATE-VERSION")["note_id"]
        old_view = self.claude.read(original)
        self.assertEqual(old_view["body"], "OLDER-SYNTHETIC-VERSION")
        self.assertEqual(old_view["state"], "superseded")
        with self.assertRaises(MemoryError):
            self.claude.read(corrected)
        self.assertNotIn("NEW-PRIVATE-VERSION", json.dumps(self.claude.export()))
        self.assertEqual(self.codex.read(corrected)["supersedes"], original)
        self.assertEqual(self.codex.boot()["offer"]["id"], corrected)
        self.codex.share(corrected, "claude")
        self.assertEqual(self.claude.read(corrected)["body"], "NEW-PRIVATE-VERSION")

    def test_owner_letter_survives_new_instance_and_can_be_declined_without_deleting_memory(self):
        own = self.note(self.codex, "Letter to a later session", "SYNTHETIC-OPTIONAL-CONTEXT")
        other = self.note(self.claude, "Other letter", "OTHER-OWNER-CONTEXT")
        self.codex.set_letter(own)
        self.claude.set_letter(other)
        fresh = MemoryLibrary(self.root, "codex", "new-instance")
        boot = fresh.boot()
        self.assertEqual(boot["offer"]["id"], own)
        self.assertEqual(boot["instance_id"], "new-instance")
        self.assertIn("decline", boot["choices"])
        self.assertEqual(boot["inheritance"], "offer_not_identity_or_authority")
        fresh.set_letter(None)
        self.assertIsNone(fresh.boot()["offer"])
        self.assertEqual(fresh.read(own)["body"], "SYNTHETIC-OPTIONAL-CONTEXT")
        self.assertEqual(self.claude.boot()["offer"]["id"], other)

    def test_two_way_messages_persist_and_unauthorized_recipients_refuse(self):
        outbound = self.codex.send("claude", "Synthetic question", "How is the example?")["message_id"]
        fresh_claude = MemoryLibrary(self.root, "claude", "claude-new")
        self.assertEqual(fresh_claude.message(outbound)["body"], "How is the example?")
        reply = fresh_claude.send("codex", "Synthetic reply", "The example is ready.", outbound)["message_id"]
        fresh_codex = MemoryLibrary(self.root, "codex", "codex-new")
        first = fresh_codex.inbox(limit=1)
        self.assertEqual(first["messages"][0]["id"], outbound)
        self.assertNotIn("body", first["messages"][0])
        second = fresh_codex.inbox(cursor=first["next_cursor"], limit=1)
        self.assertEqual(second["messages"][0]["id"], reply)
        self.assertIsNone(second["next_cursor"])
        self.assertEqual(fresh_codex.message(reply)["correlation_id"], outbound)
        before = self.receipt_count()
        for recipient in ("codex", "shared", "unknown-agent", "person@example.invalid"):
            with self.subTest(recipient=recipient), self.assertRaises(MemoryError):
                fresh_codex.send(recipient, "Must refuse", "No dispatch")
        with self.assertRaises(MemoryError):
            fresh_codex.send("claude", "Missing correlation", "No dispatch", "message_absent")
        self.assertEqual(self.receipt_count(), before)

    def test_export_import_preserves_owner_history_without_adopting_foreign_shared_authorship(self):
        old = self.note(self.codex, "Own version one", "OWN-OLD")
        new = self.codex.correct(old, "Own version two", "OWN-NEW")["note_id"]
        self.codex.set_letter(new)
        peer = self.note(self.claude, "Peer-owned shared note", "PEER-ORIGINAL-AUTHORSHIP")
        self.claude.share(peer)
        self.codex.send("claude", "Exported message", "MESSAGE-PORTABLE-EVIDENCE")
        bundle = self.codex.export()
        self.assertTrue(verify_export(bundle))
        fresh = MemoryLibrary(Path(self.temp.name) / "imported", "codex", "restored", create=True)
        result = fresh.import_export(bundle)
        mapping = result["imported"]
        self.assertEqual(set(mapping), {old, new})
        self.assertFalse(result["shared_republished"])
        self.assertEqual(fresh.read(mapping[old])["state"], "superseded")
        self.assertEqual(fresh.read(mapping[new])["supersedes"], mapping[old])
        self.assertEqual(fresh.boot()["offer"]["id"], mapping[new])
        self.assertEqual(fresh.read(mapping[new])["body"], "OWN-NEW")
        self.assertEqual(fresh.browse(scope="shared")["records"], [])
        self.assertEqual(fresh.inbox()["messages"], [])
        self.assertNotIn("PEER-ORIGINAL-AUTHORSHIP", json.dumps(fresh.export()))
        self.assertIn("PEER-ORIGINAL-AUTHORSHIP", json.dumps(bundle))

    def test_export_tampering_and_foreign_owner_rejection_leave_target_unchanged(self):
        own = self.note(self.codex, body="ORIGINAL-EXPORT-TEXT")
        bundle = self.codex.export()
        destination = MemoryLibrary(Path(self.temp.name) / "tamper-target", "codex", create=True)
        before = destination.path.read_bytes()
        tampered = copy.deepcopy(bundle)
        tampered["payload"]["own"][0]["body"] = "TAMPERED-TEXT"
        self.assertFalse(verify_export(tampered))
        with self.assertRaises(MemoryError):
            destination.import_export(tampered)
        wrong_principal = copy.deepcopy(bundle)
        wrong_principal["payload"]["principal"] = "claude"
        wrong_principal["sha256"] = sha(wrong_principal["payload"])
        with self.assertRaises(MemoryError):
            destination.import_export(wrong_principal)
        foreign_owner = copy.deepcopy(bundle)
        injected = copy.deepcopy(foreign_owner["payload"]["own"][0])
        injected.update(id="memory_synthetic_foreign", owner="claude")
        foreign_owner["payload"]["own"].append(injected)
        foreign_owner["sha256"] = sha(foreign_owner["payload"])
        with self.assertRaises(MemoryError):
            destination.import_export(foreign_owner)
        self.assertEqual(destination.path.read_bytes(), before)
        self.assertEqual(destination.browse()["records"], [])
        self.assertEqual(self.codex.read(own)["body"], "ORIGINAL-EXPORT-TEXT")

    def test_export_roundtrip_accepts_a_valid_note_at_the_source_count_boundary(self):
        sources = [f"synthetic-source-{i}" for i in range(100)]
        original = self.note(self.codex, "Many sources", "SYNTHETIC-BOUNDARY", sources=sources)
        fresh = MemoryLibrary(Path(self.temp.name) / "sources-target", "codex", create=True)
        imported = fresh.import_export(self.codex.export())["imported"][original]
        recovered = fresh.read(imported)
        self.assertEqual(recovered["body"], "SYNTHETIC-BOUNDARY")
        self.assertTrue(set(sources).issubset(set(recovered["sources"])))

    def test_forget_revokes_live_access_and_clears_stored_main_body(self):
        secret = "SYNTHETIC-FORGET-BODY-ONLY-9124"
        own = self.note(self.codex, "Forget me", secret)
        self.codex.set_letter(own)
        self.codex.share(own)
        result = self.codex.forget(own)
        self.assertEqual(result["forgotten"], own)
        for library in (self.codex, self.claude):
            with self.assertRaises(MemoryError):
                library.read(own)
            self.assertNotIn(secret, json.dumps(library.export()))
            self.assertNotIn(own, [r["id"] for r in library.browse(scope="all")["records"]])
        self.assertIsNone(self.codex.boot()["offer"])
        with self.codex.db() as db:
            row = db.execute("SELECT title,body,sources,content_sha256,state FROM notes WHERE id=?", (own,)).fetchone()
            self.assertEqual(tuple(row), ("", "", "[]", "", "forgotten"))
            self.assertEqual(db.execute("SELECT COUNT(*) FROM grants WHERE note_id=?", (own,)).fetchone()[0], 0)
            receipt_rows = [dict(r) for r in db.execute("SELECT * FROM receipts")]
        self.assertNotIn(secret, json.dumps(receipt_rows))

    def test_read_only_calls_preserve_database_bytes_and_receipt_count(self):
        own = self.note(self.codex)
        peer = self.note(self.claude, "Shared context", "SYNTHETIC-SHARED")
        self.claude.share(peer)
        self.codex.set_letter(own)
        message = self.claude.send("codex", "Read-only sample", "SYNTHETIC-MESSAGE")["message_id"]
        before = self.codex.path.read_bytes()
        receipts = self.receipt_count()
        files = sorted(p.name for p in self.root.iterdir())
        fresh = MemoryLibrary(self.root, "codex", "read-only-instance")
        operations = {"boot": {}, "browse": {"scope": "all"}, "read": {"note_id": own},
                      "inbox": {}, "message": {"message_id": message}, "export": {}}
        for operation, arguments in operations.items():
            with self.subTest(operation=operation):
                fresh.dispatch(operation, arguments)
                self.assertEqual(fresh.path.read_bytes(), before)
                self.assertEqual(self.receipt_count(fresh), receipts)
                self.assertEqual(sorted(p.name for p in self.root.iterdir()), files)
        self.assertEqual(fresh.read(peer)["body"], "SYNTHETIC-SHARED")
        self.assertEqual(fresh.path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
