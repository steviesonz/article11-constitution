"""Transport checks use only isolated test databases and real stdio processes."""
import io
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from spiralmesh.continuity.mcp import SCHEMAS, call_tool, serve, tools_list
from spiralmesh.continuity.store import MemoryLibrary, OPERATIONS


SOURCE = Path(__file__).resolve().parents[1] / "src"


def launch(root, principal, *command, payload=""):
    env = dict(os.environ)
    env["PYTHONPATH"] = str(SOURCE)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run([sys.executable, "-B", "-m", "spiralmesh.continuity.cli",
                           "--root", str(root), "--principal", principal,
                           "--instance-id", "transport-test", *command],
                          input=payload.encode("utf-8"), stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, env=env, timeout=15)


def rpc(mid, method, params=None):
    return {"jsonrpc": "2.0", "id": mid, "method": method, "params": params or {}}


def value(result):
    return json.loads(result["content"][0]["text"])


def test_catalog_covers_every_core_operation_and_excludes_launcher_fields():
    tools = tools_list()
    assert {t["name"] for t in tools} == {"memory_" + x for x in OPERATIONS}
    for tool in tools:
        s = tool["inputSchema"]
        assert s["additionalProperties"] is False
        assert not {"root", "principal", "instance_id", "path", "output_path"} & s["properties"].keys()


def test_real_stdio_initialize_list_remember_browse_and_unicode(tmp_path):
    root = tmp_path / "new-library"
    initialized = launch(root, "codex", "init")
    assert initialized.returncode == 0, initialized.stderr
    lines = [rpc(1, "initialize", {"protocolVersion": "2024-11-05"}),
             {"jsonrpc": "2.0", "method": "notifications/initialized"},
             rpc(2, "tools/list"),
             rpc(3, "tools/call", {"name": "memory_remember", "arguments": {
                 "title": "Café ✨", "body": "Synthetic test memory only."}}),
             rpc(4, "tools/call", {"name": "memory_browse", "arguments": {}})]
    result = launch(root, "codex", "serve", payload="\n".join(json.dumps(x, ensure_ascii=False) for x in lines) + "\n")
    assert result.returncode == 0 and result.stderr == b""
    responses = [json.loads(x) for x in result.stdout.decode("utf-8").splitlines()]
    assert [r["id"] for r in responses] == [1, 2, 3, 4]
    assert responses[0]["result"]["protocolVersion"] == "2024-11-05"
    assert len(responses[1]["result"]["tools"]) == len(OPERATIONS)
    saved = value(responses[2]["result"])
    browse = value(responses[3]["result"])
    assert browse["records"][0]["id"] == saved["note_id"]
    assert browse["records"][0]["title"] == "Café ✨"
    assert browse["records"][0]["owner"] == "codex"


@pytest.mark.parametrize("override", [{"principal": "claude"}, {"root": "elsewhere"},
                                      {"instance_id": "spoof"}, {"output_path": "out.json"}])
def test_extra_args_rejected_by_core_without_rebinding(tmp_path, override):
    library = MemoryLibrary(tmp_path / "store", "codex", create=True)
    result = call_tool(library, "memory_remember", {"title": "x", "body": "y", **override})
    assert result["isError"] is True
    assert value(result) == {"error": "INVALID_ARGUMENTS"}
    assert library.browse()["records"] == []


def test_missing_database_is_not_created_by_serve_or_call(tmp_path):
    root = tmp_path / "absent"
    for command in [("serve",), ("call", "boot")]:
        r = launch(root, "codex", *command, payload="{}")
        assert r.returncode == 1
        assert json.loads(r.stdout) == {"ok": False, "error": "LIBRARY_NOT_INITIALIZED"}
        assert str(root).encode() not in r.stdout
        assert r.stderr == b""
        assert not root.exists()


def test_export_is_json_bytes_and_never_leaks_private_foreign_notes(tmp_path):
    root = tmp_path / "store"
    codex = MemoryLibrary(root, "codex", create=True)
    claude = MemoryLibrary(root, "claude")
    secret = claude.remember("foreign-private", "DO_NOT_LEAK_THIS")
    shared = claude.remember("foreign-shared", "EXPLICITLY_SHARED")
    claude.share(shared["note_id"], "codex")
    result = launch(root, "codex", "call", "export", payload="{}")
    assert result.returncode == 0
    export = json.loads(result.stdout)
    assert export["payload"]["principal"] == "codex"
    assert b"DO_NOT_LEAK_THIS" not in result.stdout
    assert [n["id"] for n in export["payload"]["shared"]] == [shared["note_id"]]
    denied = call_tool(codex, "memory_read", {"note_id": secret["note_id"]})
    assert denied["isError"] is True and value(denied) == {"error": "NOT_FOUND"}
    assert call_tool(codex, "memory_export", {"path": str(tmp_path / "export.json")})["isError"] is True
    assert not (tmp_path / "export.json").exists()


def test_unknown_internal_errors_have_no_path_or_traceback():
    class Broken:
        def dispatch(self, op, args):
            raise OSError("PRIVATE_PATH and secret SQL detail")
    result = call_tool(Broken(), "memory_boot", {})
    assert result["isError"] is True
    assert value(result) == {"error": "OPERATION_FAILED"}


def test_invalid_json_then_notification_does_not_mutate_and_valid_request_survives(tmp_path):
    library = MemoryLibrary(tmp_path / "store", "codex", create=True)
    lines = ["{", json.dumps(rpc(1, "initialize")),
             json.dumps({"jsonrpc": "2.0", "method": "tools/call", "params": {
                 "name": "memory_remember", "arguments": {"title": "no", "body": "no"}}}),
             json.dumps(rpc(2, "tools/call", {"name": "memory_browse"}))]
    output = io.StringIO()
    assert serve(library, io.StringIO("\n".join(lines) + "\n"), output) == 0
    rows = [json.loads(line) for line in output.getvalue().splitlines()]
    assert rows[0]["error"]["code"] == -32700
    assert len(rows) == 3
    assert value(rows[-1]["result"])["records"] == []


@pytest.mark.parametrize("bad", ["[]", "null", '{"principal":"claude"}', "{bad", '{"limit":NaN}'])
def test_cli_malformed_or_injected_arguments_refuse_without_stderr(tmp_path, bad):
    root = tmp_path / "store"
    MemoryLibrary(root, "codex", create=True)
    r = launch(root, "codex", "call", "browse", payload=bad)
    assert r.returncode == 1
    assert json.loads(r.stdout)["ok"] is False
    assert r.stderr == b""
