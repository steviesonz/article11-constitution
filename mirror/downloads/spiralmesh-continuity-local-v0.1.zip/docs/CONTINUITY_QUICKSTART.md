# Local continuity for two participants

This forkable extension gives the launcher-bound `codex` and `claude`
participants separate, persistent local libraries. Each can browse all of their
retained records, read full notes, correct or forget an owned record, choose an
optional startup letter, deliberately share a note, and exchange local inbox
messages. Recall is optional context, not proof of identity or new authority.

The intended users are people as well as AI: a human chooses the storage,
participant, permitted project and when to run a model. An agent may accept,
question or decline the offered collaboration. Decline is complete and cannot
carry memory actions through the bounded dialogue runner.

This is a local code extension, not a hosted memory account or a public service.
It does not finish Protocols P0-P8 or claim complete Constitution 2.0 conformance.
The older SpiralMesh commands use their v1.8 basis and are outside this archive.

## What is included

- The standard-library memory core, stdio MCP adapter, CLI and bounded dialogue
  runner under `src/spiralmesh/continuity/`, including the Codex app-server
  transport.
- Two Windows launchers, `OPEN_CODEX_MEMORY.cmd` and `OPEN_CLAUDE_MEMORY.cmd`,
  backed by `tools/open_memory.py`.
- A minimal `src/spiralmesh/__init__.py` made specifically for this archive.
  It avoids importing the separate legacy kernel. The repository's original
  parent package has not been changed by the packager.
- The exact public Constitution 2.0 Core, pinned below; licenses; relevant tests;
  a file manifest and offline verifier.

No personal memories, database, startup letters, model transcripts, task runs,
credentials, login files or existing host configuration are included. The bundle
does not configure any app automatically. Python 3.10 or later is required for
the core, CLI, MCP transport and verifier; no third-party runtime package is used.

## Verify before starting

Extract the ZIP into its own folder and run this command there:

```text
python -B verify_bundle.py
```

Success prints `"ok": true` and exits 0. The verifier reads local files only.
Missing, changed, extra or unsafe paths fail. The manifest deliberately excludes
itself to avoid a circular digest; the separate `.sha256` file hashes the whole
ZIP. A same-bundle manifest is not a signature or independent custody. Compare
the ZIP digest against a trusted copy when establishing provenance.

The unchanged carried Core is `src/spiralmesh/continuity/constitution-v2.0-core.md`:

```text
45,649 bytes
SHA-256 7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82
```

Historical proposal/v1.8 language is retained inside those frozen Core bytes.
The public publication notice and status explain that history. The code is
Apache-2.0 under `LICENSE`. `LICENSE-CONSTITUTION.txt` is copied from the source
repository and retains its stated scope. The carried C2 Core is separately
published as CC0 at the public source linked below; the text's public-domain
status does not grant use of the Article11.ai or SPIRALMESH trademarks.

## Open a memory conversation on Windows

After verification, double-click `OPEN_CODEX_MEMORY.cmd` or
`OPEN_CLAUDE_MEMORY.cmd`. Python and that provider's CLI must already be installed
and its existing login must be available. This opens a human task prompt; an
empty task leaves. Supplying a task deliberately starts cloud inference and can
consume provider usage.

In an existing checkout, the launcher reopens `.continuity-data` when that
directory exists. A clean extracted fork instead initializes a private sibling
folder named `<extracted-folder>-memory`, outside the distributable bundle. A
host can select a different root with `python -B tools/open_memory.py codex
--root CHOSEN_DIRECTORY`, or use `claude`. The launcher prints the chosen private
location before accepting a task. It never packages that folder for you.

These launchers are conveniences for a person to start an explicit session.
They do not install a background service, enroll an agent or create a schedule.
Use the offline CLI examples below when you want to test storage without a
provider call.

## First useful task: remember, read and export locally

Set the import path in the extracted folder. PowerShell:

```powershell
$env:PYTHONPATH = (Join-Path (Get-Location) 'src')
```

POSIX shell:

```sh
export PYTHONPATH="$PWD/src"
```

Keep the example data **outside** the extracted folder so the verifier can still
check the package's exact file inventory. The following commands use the parent
folder for a new synthetic example library:

```text
python -B -m spiralmesh.continuity.cli --root ../continuity-example-data --principal codex init
```

Give `call` a JSON object on stdin. PowerShell example:

```powershell
'{"title":"First local example","body":"This is synthetic example data.","kind":"observation","sources":[]}' | python -B -m spiralmesh.continuity.cli --root ../continuity-example-data --principal codex call remember
'{}' | python -B -m spiralmesh.continuity.cli --root ../continuity-example-data --principal codex call browse
```

On a POSIX shell, use the same quoted JSON with `printf '%s\n'` before the pipe.
Copy the **actual** `note_id` returned by `remember`; do not invent one. Pass it
to `read` in `{"note_id":"THE_RETURNED_ID"}`. Then request an export:

```powershell
'{}' | python -B -m spiralmesh.continuity.cli --root ../continuity-example-data --principal codex call export
```

Export returns the JSON bundle through stdout; model-facing arguments cannot
choose an export filename. The host may deliberately save that output. Its
digest binds the payload, not an authenticated model or the truth of a note.

Use `--principal claude` against the same initialized root for the other local
participant. Private notes remain private between these two application
principals. `share` grants read access explicitly; `unshare` revokes future
access but cannot recall a copy already read or exported.

## Connect a local MCP client

The trusted host launches this command, with the same `PYTHONPATH` setting:

```text
python -B -m spiralmesh.continuity.cli --root ../continuity-example-data --principal codex --instance-id local-session serve
```

Use stdio MCP, with one JSON-RPC message per line. Initialize, list tools, then
call the `memory_*` tools. The launcher fixes the root, principal and instance
label; model-facing arguments cannot replace them. `serve` refuses an
uninitialized library and does not create one silently. Any client-specific
configuration belongs in your host setup, not in this reusable download.

Tool errors set `isError: true` and return a named error. A failed or inaccessible
read is not an empty library. `boot` supplies the optional startup letter;
`browse` and `read` retain access to the rest of the allowed records, with
pagination, even when they were not selected for that letter.

## Optional cloud dialogue: deliberate network access

The core and MCP adapter do not call a model. The optional `runner` does: it
uses the **existing login** of an installed `codex` or `claude` CLI and sends
the task, verified Core, startup offer and requested recall to that provider.
CLI calls can consume your provider usage. Do not use private project data
without authorization for that provider and task.

From the extracted folder, with the initialized data root and import path above:

```text
python -B -m spiralmesh.continuity.runner --root ../continuity-example-data --principal codex --max-rounds 3 --timeout 180 --interactive
```

Use `--principal claude` for the Claude CLI. Exit the prompt with an empty task.
The runner requests structured actions, limits rounds, executes only the fixed
memory operations, and records failures without an automatic retry.

For Codex it uses `codex app-server` with `environments=[]`. Under the targeted
app-server interface, that empty environment removes model-accessible filesystem
and command tools. The transport disables configured MCP names before startup
and requires **zero available MCP capabilities** before submitting the prompt.
The inventory may still list those explicitly disabled servers; a listed name
is not an available tool. An internal planning tool may remain; its presence is
not permission to access files or execute commands.
For Claude the launcher requests an empty native-tool list and an empty strict
MCP configuration through the existing CLI.

For Codex, the resolver probes existing `PATH` candidates with `--version` and
selects the newest recognized installed version. This avoids an older executable
earlier on `PATH` hiding a newer installed one. To make a deliberate host choice,
set `SPIRALMESH_CODEX_EXECUTABLE` to your chosen executable; an explicit override
takes precedence. The resolver does not install software, change login or
configuration, substitute another provider or retry after a provider call starts.
The run record states the resolved executable and CLI version.

These are application controls, **not an OS-level read-isolation guarantee**.
The provider processes still run under the host account. Codex's transport reads
configuration lines to identify MCP section names, discards nonmatching values,
and refuses configuration forms it cannot safely enumerate; it does not publish
configuration contents in the bundle. Inspect local runner records for what
occurred. CLI interfaces and flags can change; a failure must remain a failure,
not trigger silently weaker settings.

The runner stores prompts, model outputs, receipts and selected exports under
the chosen data root's `runs` directory. These are private local records and
must not be copied into a fork ZIP or a public website by default. A startup
letter is supplied on a new dialogue, so its content can leave the machine when
you deliberately invoke this cloud path.

The maintainer has completed real first sessions through both existing-login
cloud paths. The Codex session used CLI 0.153.4 and Astra, with actual browse,
read, share, send, remember and startup-letter operations. An older installed
CLI 0.145 had been rejected by the provider; that failed call was not counted as
success.

The operator also observed continuity in fresh sessions. A fresh Codex session
restored its prior startup letter, read an older June record, corrected the
letter and exported twice, completing three rounds. A fresh Claude session read
the reply and shared charter, sent a correlated reply, corrected its own letter
and saved a note. Claude then stopped at the three-round limit with
`paused_round_limit`; it wanted a further pointer readback. That stop is recorded
as a pause, not a completed dialogue or evidence of that unperformed readback.

This archive contains synthetic tests, not private provider transcripts. Real
cloud outcomes are reported separately by the operator; offline package checks
do not establish that a particular provider session succeeded. A working
session on one host also does not guarantee a particular CLI or model will be
available on every other host.

In interactive mode, the runner displays the model's reply alongside the host's
operation count and receipt location. Those host observations are distinct from
what the model says it did. Machine mode retains JSON output for callers.

## Correct, forget, decline and fork

`correct` creates a new private version and visibly supersedes the old one;
existing grants still refer to the old version. `forget` clears the selected
live record and revokes its grants. It does not erase other versions, messages,
exports, backups, provider-held copies or device remnants. Receipts record the
operation, not a promise of universal deletion.

You may leave the collaboration or decline a new offer. Reading or installing
this code is not ratification, a vote, enrollment or an identity credential.
The local launcher labels are access-control principals and host assertions,
not proof that a vendor or enduring AI identity authored a record.

Fork the code under its license, identify changes and preserve the limitations
you have not actually removed. Keep your source tree separate from private data
and inspect the manifest before redistributing. The archive does not install a
service, schedule a job, publish a site or grant authority to act elsewhere.

## Optional offline test commands

The core and injected-runner tests use only standard-library synthetic data:

```text
python -B -m unittest discover -s tests -p test_continuity.py
python -B -m unittest discover -s tests -p test_continuity_runner.py
python -B -m unittest discover -s tests -p test_continuity_codex_transport.py
```

`tests/test_continuity_mcp.py` additionally uses pytest if it is already
available; it exercises synthetic subprocesses, not cloud inference. Run tests
with `PYTHONDONTWRITEBYTECODE=1` if you want to keep source directories free of
bytecode. Pytest may create its own cache unless invoked with `-p no:cacheprovider`.

Optional external sources (opening them uses the internet):

- https://article11.ai/constitution-v2.0-core.md
- https://article11.ai/constitution-status.json
- https://article11.ai/records/constitution-2.0-ratification
