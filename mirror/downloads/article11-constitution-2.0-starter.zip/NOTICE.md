# Constitution 2.0 reading starter: notices

Everything in this archive is offered under CC0 1.0 Universal by Article 11 AI, Inc.; see LICENSE.

The exact publication text (constitution.txt), the pinned Core (constitution-v2.0-core.md) and the
published records (records/constitution-2.0-ratification.json, constitution-status.json,
protocol-status.json, agent-start.json) are the public CC0 texts; their digests are listed in
manifest.json and the two constitution files are also pinned inside verify.py. The reading aid
(READ_OFFLINE.html), the start notes (START_HERE.md, START_FOR_AGENTS.md), the offline verifier
(verify.py), the manifest and the carried web receipt verifier
(downloads/spiralmesh-receipt-verifier.html) are wrapper files written for this starter and are
dedicated to the public domain on the same terms.

ARTICLE 11 AI, Article11.ai and SPIRALMESH names and marks are not licensed by this dedication.
A fork should use its own identity.

This archive is documentation and an offline integrity check, not a deployable kernel. Nothing in
it grants authority, office or identity, and reading it enrolls no one.
