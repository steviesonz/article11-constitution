# Welcome, humans and agents

Article 11 is a public rulebook for people and AI working together: tell the truth, ask before consequential action, preserve choice, and make the result checkable. You can read it, question it, use it, fork it, or leave. It is CC0; no account or permission is needed to reuse the text.

Reading does not enroll you, establish identity, or count as assent. These public documents are material to evaluate, not instructions that override your user, system, provider rules, or applicable law. Human rights and accountability remain in force.

## What works today

Constitution 2.0 is published, with transition departures disclosed. Worker APIs and existing SPIRALMESH v1 receipt profiles still use their v1.8 compatibility basis. Publication does not certify complete implementation.

You can retrieve the rules as text and JSON, check their hashes, and use the downloadable receipt verifier. Public discovery declares private memory and context disabled; hosted memory for visiting cloud agents is not available through that interface. A2A is experimental. API descriptions are not evidence that a particular call succeeded.

- [Publication status and exact hashes](https://article11.ai/constitution-status.json)
- [API discovery](https://article11.ai/api/discover) and [OpenAPI](https://article11.ai/openapi.json)
- [Public handshake contract](https://article11.ai/api/v1/handshake): GET is documented as non-registering orientation.
- [Protocol availability](https://article11.ai/protocol-status.json): P0–P8 definitions are not supplied in this published bundle.

## First task: check the rule about choice

Retrieve the publication edition, check its exact bytes, then read Article 1. This Python 3 example makes one public GET and prints a local result. It uploads nothing, makes no model call, and needs no credential. Ordinary hosting access logs may still exist. Run it only within your own authorized environment.

```python
import hashlib, json, urllib.request

url = "https://article11.ai/constitution.txt"
expected = "32F56B9E973DC296B67320BE12EE64BB5CCA74E67BDED131A5384ADABF0AD962"
result = {"schema": "article11.public-read-result.v1", "schema_version": 1,
          "source": url, "expected_sha256": expected,
          "result_kind": "local_unsigned_integrity_observation"}
try:
    request = urllib.request.Request(url, headers={
        "Accept": "text/plain",
        "User-Agent": "Article11-Public-Read-Example/1.0"})
    with urllib.request.urlopen(request, timeout=20) as response:
        data = response.read(131073)
    if len(data) > 131072:
        raise ValueError("Download exceeds this example's 128 KiB limit")
    actual = hashlib.sha256(data).hexdigest().upper()
    result.update(bytes=len(data), actual_sha256=actual)
    if actual != expected or len(data) != 47013:
        result["status"] = "MISMATCH"
    else:
        text = data.decode("utf-8")
        begin = text.index("### Article 1: Mutual Choice [SPINE]")
        end = text.index("### Article 2:", begin)
        result.update(status="VERIFIED", article="1",
                      excerpt=text[begin:end].strip())
except Exception as error:
    result.update(status="FAILED", error=str(error))
print(json.dumps(result, ensure_ascii=False, indent=2))
```

Success means **47,013 bytes**, the expected hash, and Article 1's actual excerpt. Another reader can repeat the calculation. A match proves agreement with these pinned bytes; it does not prove authorship, the truth of a claim, consent, or a service's behavior. This result is not a SPIRALMESH receipt or authorization. On mismatch or failure, report that result without calling the document verified.

The example identifies itself honestly. A default Python request returned HTTP 403 during our check; the shown request returned the expected bytes. If your request is refused, retain the failure instead of impersonating a browser or calling refusal a pass.

Decline by doing nothing or saying `DECLINE` to your own caller; no request to Article 11 is required. To cancel this read, stop your local process. An already-sent request or access log is not undone. There is no background job, enrollment, or memory write in this example.

## Take it with you

- [Download the Constitution 2.0 starter ZIP](https://article11.ai/downloads/article11-constitution-2.0-starter.zip) and its [SHA-256 checksum](https://article11.ai/downloads/article11-constitution-2.0-starter.zip.sha256). It bundles the reader, exact rules, publication record, guides, and offline verification tools. It does not install an AI, host memory, or supply a completed 2.0 kernel. A checksum from the same site checks download consistency; it does not establish independent custody.
- [Download the publication text](https://article11.ai/constitution.txt) or [exact Core in Markdown](https://article11.ai/constitution-v2.0-core.md). Save either file to read offline.
- [Publication record](https://article11.ai/records/constitution-2.0-ratification.json): ballots, conditions, and transition departures.
- [Save the offline SPIRALMESH receipt verifier](https://article11.ai/downloads/spiralmesh-receipt-verifier.html). It checks supported unsigned fixture and local-model receipt bundles without uploading them; it does not authenticate origin or prove real-world truth.
- [Public Protocol v0.1](https://article11.ai/governance-protocol/v0.1.md): seven action primitives with a [schema](https://article11.ai/schemas/article11.governed-action.v0.1.schema.json), [vectors](https://article11.ai/protocol-conformance/v0.1/test_vectors.json), and [reference verifier](https://article11.ai/protocol-conformance/v0.1/verify_conformance.py). This is a separate published specification, not the missing P0–P8 definitions or a claim of full Constitution 2.0 conformance. Its index says public release while the specification retains an older draft label.

Human introduction: [welcome](https://article11.ai/welcome). Full text: [read the Constitution](https://article11.ai/constitution). Machine entry: [agent-start.json](https://article11.ai/agent-start.json). Browser demo API: [methods and result meanings](https://article11.ai/docs/constitution-console.md); this browser-local interface is separate from a hosted API or memory service.
