#!/usr/bin/env python3
"""Offline integrity check. Standard library only; no network or uploads."""
import hashlib
import json
from pathlib import Path
import sys

PINS = {'constitution.txt': (47013, '32f56b9e973dc296b67320be12ee64bb5cca74e67bded131a5384adabf0ad962'), 'constitution-v2.0-core.md': (45649, '7e6d12e1025a46cc3a860d6147d79e2362c4d88cb727ce9423854b5008be4c82')}


def main():
    base = Path(__file__).resolve().parent
    errors = []
    checked = 0
    try:
        manifest = json.loads((base / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("schema") != "article11.offline-starter.manifest.v1":
            raise ValueError("unsupported manifest schema")
        expected = manifest["files"]
        if not isinstance(expected, list):
            raise ValueError("manifest files must be a list")
        names = set()
        for row in expected:
            name = row["path"]
            if not isinstance(name, str) or not name or name in names:
                raise ValueError("invalid or duplicate manifest path")
            pieces = name.split("/")
            if any(p in ("", ".", "..") for p in pieces) or "\\" in name or ":" in name:
                raise ValueError("unsafe manifest path")
            if name == "manifest.json":
                raise ValueError("manifest cannot hash itself")
            names.add(name)
            path = base.joinpath(*pieces)
            if path.is_symlink() or any(p.is_symlink() for p in path.parents if p != base.parent):
                errors.append({"path": name, "status": "SYMLINK_REFUSED"})
                continue
            try:
                raw = path.read_bytes()
                actual = hashlib.sha256(raw).hexdigest()
                if len(raw) != row["bytes"] or actual != row["sha256"]:
                    errors.append({"path": name, "status": "MISMATCH"})
                checked += 1
            except OSError:
                errors.append({"path": name, "status": "UNREADABLE_OR_MISSING"})
        present = {p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file() or p.is_symlink()}
        for name in sorted(present - names - {"manifest.json"}):
            errors.append({"path": name, "status": "UNEXPECTED_FILE"})
        for name, (size, pin) in PINS.items():
            if name not in names:
                errors.append({"path": name, "status": "MISSING_PINNED_MANIFEST_ENTRY"})
            try:
                raw = (base / name).read_bytes()
                if len(raw) != size or hashlib.sha256(raw).hexdigest() != pin:
                    errors.append({"path": name, "status": "PIN_MISMATCH"})
            except OSError:
                errors.append({"path": name, "status": "PIN_UNREADABLE_OR_MISSING"})
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append({"status": "INVALID_MANIFEST", "detail": str(exc)})
    result = {"ok": not errors, "status": "VERIFIED" if not errors else "FAILED",
              "files_checked": checked, "publication_version": "2.0",
              "runtime_and_receipt_compatibility": "v1.8", "network_used": False,
              "identity_authenticated": False, "errors": errors}
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
