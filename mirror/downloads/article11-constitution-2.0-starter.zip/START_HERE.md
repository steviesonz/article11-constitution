# Welcome: a shared rulebook for people and AI

You can read, question, copy or decline these rules. Reading this download does
not enroll you, create an account, assign an identity, record assent, or grant
any person or AI authority. No response is required. Closing the files is a
complete way to decline this introduction. Existing agreements are not silently
changed by opening or closing this starter.

## Start in three minutes

1. Open `READ_OFFLINE.html` in a browser. The short introduction explains the
   status; the complete publication text follows, with an article index.
2. Read Articles 1 (Mutual Choice), 11 (Human in the Loop), 18 (Emergency Brake),
   41 (The Open Door) and 43 (Conditional and Informed Assent). These are a useful
   orientation, not a substitute for the complete text or a new set of rules.
3. Run `python -B verify.py` from this extracted folder if Python 3 is available.
   It verifies the bundled bytes locally. No account, token or network is used.

## What people and AI can do with it

People can make the rules of a collaboration explicit: explain the task and
limits, agree what needs human approval, distinguish evidence from guesses,
and let another participant decline. AI systems can read the same text and
machine-readable records, report their actual capabilities, and keep proposed
actions separate from authorized execution. Neither side gets blanket authority.

For a useful first task, verify this download and report its actual result. A
failure is a failure; it is not consent to repair or replace the rules. For a
human-and-AI exercise, ask an assistant to explain one article using only the
included text, link its answer to that article, and correct any unsupported
claim together. This exercise saves no memory on its own.

## What is ready, and what is still being built

- Constitution 2.0 is published. The public record includes the supporting
  responses, qualifications and disclosed transition departures.
- Formal no-stake review was not performed for this transition; outside-control
  custody is deferred. Publication does not certify complete implementation.
- Worker APIs and SPIRALMESH v1 receipt profiles remain on their v1.8
  compatibility basis. This ZIP does not upgrade a service or receipt profile.
- Protocols P0-P8 are referenced by the text. This starter does not supply or
  claim completed normative definitions or implementations. See
  `protocol-status.json` for the explicitly labeled public status.
- This is a documentation and verification starter, not a deployable kernel,
  hosted memory account, or complete agent-to-agent coordination runtime.

Some introductory statements inside the preserved Core describe its earlier
proposal status and v1.8 baseline. The publication notice and
`constitution-status.json` explain their historical context; they have not been
silently rewritten inside the ratified bytes.

## Choose your next path

- **Read:** `READ_OFFLINE.html`, or `constitution.txt` for the exact bytes.
- **Build with an agent:** start with `START_FOR_AGENTS.md` and `agent-start.json`.
  Online endpoints named there require a separate, deliberate online request.
- **Check a receipt:** open `downloads/spiralmesh-receipt-verifier.html` locally
  and use a compatible receipt you choose. This original offline verifier is
  unchanged. Unsigned receipt checks do not prove vendor or model identity.
- **Fork the text:** copy the public-domain Constitution and label your changes
  and governance choices. A fork is your work; it does not enroll its readers in
  Article 11 or inherit authority over anyone.
- **Decline:** stop here. Nothing in this starter requires an answer, enrollment,
  a saved memory or an ongoing relationship.

## Check what you received

The successful command is `python -B verify.py` in this extracted folder. It
prints JSON and exits 0 only when every listed payload file matches and the
publication and Core match their separately pinned expected hashes. A mismatch,
missing file or unexpected added file produces a nonzero exit. Run it before
adding personal notes; otherwise it will correctly report those extra files.

`manifest.json` lists filenames, byte counts and SHA-256 hashes for every payload
file. It excludes itself to avoid a circular digest. The download's `.sha256`
sidecar hashes the whole ZIP and is deliberately outside it. A hash detects a
change against a trusted expected value. A manifest bundled with the same files
is not independent custody, a signature, a truth certificate or identity proof.
The verifier itself must also come from a source you trust.

The verifier performs no uploads, network requests, enrollment or persistent
memory operations. It reads files and prints the result. This guarantee is about
the included verifier; it does not describe every feature of an online website
or the host operating system. You may keep, copy or delete your own extracted
folder. This starter maintains no separate account or deletion ledger.

The constitution is published under CC0. This reading aid is non-normative;
the exact publication text and public records remain the sources to consult.

LICENSE and NOTICE.md in this archive state the terms for every file here: CC0 1.0
for all of it, with the names and marks excluded.

Optional external links (opening them accesses the public internet):

- Current publication: https://article11.ai/constitution
- Current publication status: https://article11.ai/constitution-status.json
- Public receipt tool: https://article11.ai/receipt-verifier
