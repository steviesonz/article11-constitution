# Dated integration kit: 9 September 2026

This edition updates `agent_memory_library.py`. It does not change the bundled
dialogue loop, runtime routes, rule bytes, adapter example or dependency pins.
The earlier undated ZIP remains an immutable download; this edition has its own
filename and checksum.

## What changes

- Filtered browse matches the complete sanitized text and visible title, including
  visible text beyond the first returned slice. Guessing text removed by the
  host's privacy adapter no longer earns a match through the raw stored body.
- Exact-title search recognizes the supported flat, `metadata` and
  `data.metadata` title layouts, while retaining owner, node and exclusion checks.
- Exact-title lookup runs only when the privacy adapter leaves the query unchanged,
  and compares the sanitized returned title. If the query changes, the whole
  exact-title pass is skipped and `exact_title_lookup` reports
  `skipped_query_not_visible`. The semantic pass uses the sanitized query.

A skipped exact-title pass is not evidence that the requested note does not exist.
Semantic suggestions still do not establish an exact-title match. A title hidden
by the privacy adapter cannot earn exact-title credit from its hidden bytes; use
permitted browse and read operations to inspect available records. Complete recall
still requires following browse cursors and read slices. Nothing here makes
someone else's private history available.

## Check the repair without a service

```text
python -B verify_package.py
python -B tests/test_memory_visibility.py
python -B examples/inert_dialogue.py
python -B -m unittest test_agent_memory_dialogue -v
```

The new visibility test supplies in-process storage shapes and a narrowly defined,
synthetic redaction policy. That policy exists only inside the test process. It is
not a production privacy adapter, a configuration file, or a claim about every
Qdrant installation. No live node, model, owner store or network is required.

## Exact source lineage

- Earlier ZIP: `article11-local-agent-memory-kit.zip`, 60,350 bytes,
  SHA-256 `2A40418B82B462987F0863312B0957A1C19FA8B21FEB1DB1063D6ED2FA990E11`.
- Earlier library: 40,980 bytes,
  SHA-256 `C8FF46570E3AAE6C0DBD4E4747D3E4B2B4890321F169BC20A6057CCAB0DAC18E`.
- This library: 45,283 bytes,
  SHA-256 `D2AD7772FC7F1FD1F949BD82E693AF3684FB56E9594EC3D708A1F05038952357`.

The host still supplies authentication, owner binding, privacy sanitization,
storage, write admission and retention policy. Installing this kit does not
migrate a service or prove model identity, consent, truth or full constitutional
implementation. See `ADAPTER_CONTRACT.md` and `LICENSE` before integration.
