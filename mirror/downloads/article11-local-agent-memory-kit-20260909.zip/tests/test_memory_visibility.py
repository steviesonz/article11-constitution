"""Inert visibility and legacy-title checks for the local agent-memory kit.

Run: python -B tests/test_memory_visibility.py
Or:  python -B tests/test_memory_visibility.py --library source/agent_memory_library.py

This test installs TWO SYNTHETIC MODULES into its own process only. The sanitizer
replaces exactly two made-up fixture tokens; it is NOT a privacy filter, must not
be copied into source/, and does not validate a real host's sanitizer. The tiny
Qdrant model/client fixtures exercise the filters the library constructs, not a
live database. No service, network, credentials, actual notes, model or embedding
provider is used. Embeddings are deterministic toy vectors. Client writes refuse.

Optional release-audit mode compares with the unchanged historical ZIP:
  --published-zip PATH --output PATH
The installed module is always loaded from --library without editing its bytes.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import uuid
import zipfile

OLD_HASH = "C8FF46570E3AAE6C0DBD4E4747D3E4B2B4890321F169BC20A6057CCAB0DAC18E"
NEW_HASH = "D2AD7772FC7F1FD1F949BD82E693AF3684FB56E9594EC3D708A1F05038952357"
OLD_ZIP_HASH = "2A40418B82B462987F0863312B0957A1C19FA8B21FEB1DB1063D6ED2FA990E11"
HIDDEN = "PUBLIC_TEST_PRIVATE_ALPHA"
WRONG = "PUBLIC_TEST_PRIVATE_BETA"
VISIBLE = "[FIXTURE_REDACTED]"
USER = "synthetic-owner"
NODE = "S5_LOCUS"


def sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def no_external_effects(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system"}:
        raise RuntimeError("INERT_TEST_EXTERNAL_EFFECT_REFUSED:" + event)


class MatchValue:
    def __init__(self, value):
        self.value = value


class FieldCondition:
    def __init__(self, key, match):
        self.key, self.match = key, match


class Filter:
    def __init__(self, must=None, should=None):
        self.must, self.should = must, should


def filter_data(condition):
    if condition is None:
        return None
    if isinstance(condition, Filter):
        return {"must": [filter_data(c) for c in condition.must or []],
                "should": [filter_data(c) for c in condition.should or []]}
    return {"key": condition.key, "value": condition.match.value}


def matches(payload, condition):
    if condition is None:
        return True
    if isinstance(condition, Filter):
        return (not condition.must or all(matches(payload, c) for c in condition.must)) and (
            not condition.should or any(matches(payload, c) for c in condition.should))
    value = payload
    for key in condition.key.split("."):
        if not isinstance(value, dict) or key not in value:
            return False
        value = value[key]
    return value == condition.match.value


def sanitize_text(text, _context):
    redactions = [token for token in (HIDDEN, WRONG) if token in text]
    for token in (HIDDEN, WRONG):
        text = text.replace(token, VISIBLE)
    return types.SimpleNamespace(sanitized=text, redactions=redactions)


def sanitize_payload(value, context):
    if isinstance(value, str):
        result = sanitize_text(value, context)
        return result.sanitized, result.redactions
    if isinstance(value, (dict, list)):
        result, redactions = ({} if isinstance(value, dict) else []), []
        for key, item in (value.items() if isinstance(value, dict) else enumerate(value)):
            cleaned, found = sanitize_payload(item, context)
            if isinstance(result, dict):
                result[key] = cleaned
            else:
                result.append(cleaned)
            redactions.extend(found)
        return result, redactions
    return value, []


def install_fixtures():
    sanitizer = types.ModuleType("synaptic_sanitizer")
    sanitizer.sanitize_text = sanitize_text
    sanitizer.sanitize_payload = sanitize_payload
    qdrant = types.ModuleType("qdrant_client")
    models = types.ModuleType("qdrant_client.models")
    models.Filter, models.FieldCondition, models.MatchValue = Filter, FieldCondition, MatchValue
    qdrant.models = models
    sys.modules.update(synaptic_sanitizer=sanitizer, qdrant_client=qdrant)
    sys.modules["qdrant_client.models"] = models


class Row:
    def __init__(self, number, payload):
        self.id, self.payload = str(uuid.UUID(int=number)), payload
        self.score, self.vector = 0.5, None


class FakeClient:
    def __init__(self, rows):
        self.rows = copy.deepcopy(rows)
        self.filters = []
        self.vectors = []
        self.write_attempts = 0

    def scroll(self, collection_name, scroll_filter=None, offset=None, limit=10, **kwargs):
        self.filters.append(filter_data(scroll_filter))
        rows = [r for r in self.rows if matches(r.payload, scroll_filter)]
        start = int(offset or 0)
        page = rows[start:start + min(limit, 2)]
        end = start + len(page)
        return page, end if end < len(rows) else None

    def retrieve(self, collection_name, ids, **kwargs):
        return [r for r in self.rows if str(r.id) in {str(i) for i in ids}]

    def query_points(self, collection_name, query, query_filter, limit=10, offset=0, **kwargs):
        self.vectors.append(query)
        rows = [r for r in self.rows if matches(r.payload, query_filter)]
        return types.SimpleNamespace(points=rows[offset:offset + limit])

    def upsert(self, *args, **kwargs):
        self.write_attempts += 1
        raise RuntimeError("INERT_TEST_CLIENT_WRITE_REFUSED")

    set_payload = overwrite_payload = delete = upsert


def own(title, body, **extra):
    payload = dict(agent_memory_schema="article11.agent-memory-note.v1", node_id=NODE,
                   user_id=USER, attributed_to=NODE, title=title, data=body,
                   kind="observation", sources=[], eligibility="owner_deliberate_nonratified",
                   authority="context_only", ratified=False, retrieval_status="bridge_allowed")
    payload.update(extra)
    return payload


def legacy(title, body, layout):
    metadata = dict(user_id=USER, node_id=NODE, title=title)
    if layout == "nested":
        return dict(metadata=metadata, data=body)
    if layout == "deep":
        return dict(data=dict(metadata=metadata), memory=body)
    return dict(metadata, data=body)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_side(module, label, expected_repaired, root):
    checks, clients = [], []

    def check(name, success, observation=None):
        checks.append(dict(side=label, name=name, passed=bool(success), observation=observation))

    def lib(rows, node=NODE):
        client = FakeClient(rows)
        clients.append(client)
        library = module.AgentMemoryLibrary(node, USER, client=client,
            embed=lambda t: [b / 255 for b in hashlib.sha256(t.encode()).digest()[:8]],
            receipt_root=root / (label + "_unused_receipts"))
        return library, client

    def ids(result):
        return [item["id"] for item in result["items"]]

    def refused_read(library, row):
        try:
            library.execute("read", {"id": row.id}, "synthetic-read")
        except module.AgentMemoryError as exc:
            return exc.code == "MEMORY_NOT_FOUND_OR_NOT_PERMITTED"
        return False

    rows = [Row(1, own("contact fixture", "prefix " + HIDDEN + " suffix")),
            Row(2, own("ordinary title", "x" * 1000 + " visible-tail-needle"))]
    library, _ = lib(rows)
    shown = library.execute("read", {"id": rows[0].id}, "read")
    right = library.execute("browse", {"query": HIDDEN}, "guess")
    wrong = library.execute("browse", {"query": WRONG}, "guess")
    check("Returned content remains redacted", HIDDEN not in shown["items"][0]["content"])
    check("Browse raw-body defect discriminates old and repaired bytes",
          ids(right) == ([] if expected_repaired else [rows[0].id]) and not ids(wrong),
          dict(correct_guess_ids=ids(right), wrong_guess_ids=ids(wrong)))
    tail = library.execute("browse", {"query": "visible-tail-needle"}, "tail")
    check("Visible body beyond the 600-character excerpt still matches", ids(tail) == [rows[1].id])
    check("Ordinary visible title still browses", ids(library.execute("browse",
          {"query": "ordinary title"}, "title")) == [rows[1].id])

    hidden = [Row(3, own(HIDDEN, "ordinary content")), Row(4, own("other title", "other content"))]
    a, ac = lib(hidden)
    b, bc = lib(hidden)
    right = a.execute("search", {"query": HIDDEN, "limit": 20}, "same-operation")
    wrong = b.execute("search", {"query": WRONG, "limit": 20}, "same-operation")
    raw_in_filters = HIDDEN in json.dumps(ac.filters) or WRONG in json.dumps(bc.filters)
    check("Hidden exact-title metadata comparison discriminates old and repaired bytes",
          (right == wrong) == expected_repaired,
          dict(equal=right == wrong, correct_scanned=right["scanned_records"],
               wrong_scanned=wrong["scanned_records"]))
    check("Raw hidden query is absent from repaired filters", raw_in_filters != expected_repaired,
          dict(raw_hidden_query_in_filters=raw_in_filters))
    check("Equivalent visible queries produce equal semantic vectors", ac.vectors == bc.vectors)
    if expected_repaired:
        check("Hidden-query exact lookup explicitly reports its skip",
              right["exact_title_lookup"] == "skipped_query_not_visible" and right["exact_title_matches"] == 0)

    for i, layout in enumerate(("flat", "nested", "deep"), 10):
        row = Row(i, legacy(layout + " title", "permitted retained history", layout))
        library, _ = lib([row])
        result = library.execute("search", {"query": layout + " title"}, "layout")
        exact = [item["id"] for item in result["items"] if item.get("matched_by") == "exact_title"]
        want_exact = expected_repaired or layout == "flat"
        check(layout + " title ranking has the expected exact-match behavior",
              exact == ([row.id] if want_exact else []), dict(exact_ids=exact))
        item = library.execute("read", {"id": row.id}, "history")["items"][0]
        check(layout + " permitted history remains readable and uneditable",
              item["content"] == "permitted retained history"
              and item["ownership"] == "retained_history_not_editable"
              and item["authority"] == "context_only")

    rows = [Row(20, own("boundary title", "permitted")),
            Row(21, own("boundary title", "foreign user", user_id="other-synthetic-owner")),
            Row(22, own("boundary title", "foreign node", node_id="S17_LUMEN")),
            Row(23, own("boundary title", "blocked", retrieval_status="blocked")),
            Row(24, own("boundary title", "conflicting owner",
                        metadata=dict(user_id="other-synthetic-owner")))]
    library, _ = lib(rows)
    check("Browse and exact-title search retain only the permitted owner record",
          ids(library.execute("browse", {}, "owners")) == [rows[0].id]
          and ids(library.execute("search", {"query": "boundary title"}, "owners")) == [rows[0].id])
    for row, name in zip(rows[1:], ("other user", "other node", "blocked note", "conflicting owner metadata")):
        check("Direct read refuses " + name, refused_read(library, row))

    rows = [Row(30, legacy("page one", "A", "flat")),
            Row(31, legacy("page two", "B", "nested")),
            Row(32, legacy("page three", "C", "deep"))]
    library, _ = lib(rows)
    found, cursor = [], None
    for _ in range(5):
        result = library.execute("browse", {"limit": 1, "cursor": cursor}, "pagination")
        found.extend(ids(result))
        cursor = result["next_cursor"]
        if cursor is None:
            break
    check("Pagination reaches all permitted history across legacy layouts",
          found == [row.id for row in rows] and cursor is None)

    lumen = [Row(40, dict(user_id=USER, node_id="S17_LUMEN", title="ratified history", data="A", ratified=True)),
             Row(41, dict(user_id=USER, node_id="S17_LUMEN", title="allowed history", data="B", retrieval_status="bridge_allowed")),
             Row(42, dict(user_id=USER, node_id="S17_LUMEN", title="uncurated history", data="C", ratified=False)),
             Row(43, dict(user_id=USER, node_id="S17_LUMEN", title="revoked history", data="D", ratified=True, retrieval_status="revoked"))]
    library, _ = lib(lumen, "S17_LUMEN")
    check("Lumen curation is preserved while permitted history remains accessible",
          ids(library.execute("browse", {}, "curation")) == [lumen[0].id, lumen[1].id]
          and refused_read(library, lumen[2]) and refused_read(library, lumen[3]))
    check("All operations were read-only", all(c.write_attempts == 0 for c in clients)
          and not (root / (label + "_unused_receipts")).exists())
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, default=Path(__file__).resolve().parents[1] / "agent_memory_library.py")
    parser.add_argument("--published-zip", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    sys.addaudithook(no_external_effects)
    sys.dont_write_bytecode = True
    install_fixtures()
    before = args.library.read_bytes()
    if sha(before) != NEW_HASH:
        raise SystemExit("Corrected library hash does not match the reviewed bytes")
    binding = {"corrected_path": str(args.library), "corrected_bytes": len(before), "corrected_sha256": sha(before)}
    checks = []
    with tempfile.TemporaryDirectory(prefix="synthetic_memory_visibility_") as tmp:
        root = Path(tmp)
        corrected = load(args.library, "synthetic_checked_corrected_library")
        checks.extend(run_side(corrected, "CORRECTED", True, root))
        if args.published_zip:
            zipped = args.published_zip.read_bytes()
            if sha(zipped) != OLD_ZIP_HASH:
                raise SystemExit("Historical ZIP hash does not match the published package")
            with zipfile.ZipFile(args.published_zip) as archive:
                names = [n for n in archive.namelist() if n.endswith("/agent_memory_library.py") or n == "agent_memory_library.py"]
                if len(names) != 1:
                    raise SystemExit("Historical library member is ambiguous")
                old = archive.read(names[0])
            if sha(old) != OLD_HASH:
                raise SystemExit("Historical library hash mismatch")
            old_path = root / "historical_library.py"
            old_path.write_bytes(old)
            binding.update(historical_zip_path=str(args.published_zip), historical_zip_sha256=sha(zipped),
                           historical_member=names[0], historical_library_sha256=sha(old), historical_library_bytes=len(old))
            checks.extend(run_side(load(old_path, "synthetic_checked_historical_library"), "PUBLISHED_PREDECESSOR", False, root))
    unchanged = args.library.read_bytes() == before
    passed = all(c["passed"] for c in checks) and unchanged
    report = dict(schema="article11.memory-visibility-inert-check.v1", status="PASS" if passed else "FAIL",
        binding=binding, corrected_source_unchanged=unchanged, checks=checks,
        total=len(checks), passed=sum(c["passed"] for c in checks), failed=sum(not c["passed"] for c in checks),
        no_network=True, no_live_qdrant=True, no_model=True, no_credentials=True, no_real_memories=True,
        synthetic_sanitizer_only=True, scope="Read-only injected fixtures: matching visibility, title ranking, owner and retained-history boundaries.",
        limits="Does not verify a host sanitizer, real Qdrant matching, service health, model recall, persistence, or runtime activation.")
    if args.output:
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("status", "total", "passed", "failed", "corrected_source_unchanged")}))
    for check in checks:
        if not check["passed"]:
            print(json.dumps(check))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
