# Separately installed dependencies

Integration dependencies are installed separately and are not bundled or
relicensed by this kit. The versions retained in `requirements-integration.txt`
declare the following licenses in their distribution metadata:

| Dependency | Version | License |
| --- | --- | --- |
| qdrant-client | 1.18.0 | Apache-2.0 |
| ollama | 0.6.2 | MIT |
| FastAPI | 0.136.1 | MIT |
| Pydantic | 2.13.4 | MIT |

See each installed distribution or upstream project for its complete license and
transitive dependencies. A separately selected model and host adapters retain
their own terms. The kit's CC0 dedication does not expand to those separate works
or to trademarks. The existing `LICENSE` is preserved unchanged.
