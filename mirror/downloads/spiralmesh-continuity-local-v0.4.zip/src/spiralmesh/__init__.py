"""Bundle-only parent package for the portable continuity extension.

The separate legacy SpiralMesh kernel is intentionally not imported or included.
"""
__version__ = "0.4.0-continuity"
__license__ = "Apache-2.0"
