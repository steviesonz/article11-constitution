# Host adapters

The host grants one owner-bound library per invocation. It never copies an owner,
collection, credential or output path from model actions. The current source maps
`S5_LOCUS` to `article11_ember_memory` and `S17_LUMEN` to
`article11_lumen_memory`. Adapt that mapping deliberately for your own fork.

```python
AgentMemoryLibrary(node_id, user_id, client=client, embed=embed,
                   admission=admission, receipt_root=owned_directory)
```

`client` is a raw `QdrantClient` for an existing collection. The library calls
`scroll` (records plus continuation), `retrieve`, `query_points` (response.points)
and `upsert(wait=True)`. It does not create collections, indexes or migrate
history. `embed(text)` returns the numeric vector from the exact embedding model
and dimensions that your existing collection uses. A model tag is not proof of
matching weights; establish your own model identity and retention policy.

`admission(operation)` is a context manager implementing the host's existing
emergency-stop / write-admission policy. The host must inject it. The original
default imports `memory_control.operation_admission`, which is intentionally not
bundled with this kit. Deny before yielding when writing is unavailable. Do not
replace this with an unconditional `nullcontext` in a production integration.
Ordinary owner notes can be authorized once for the workspace; this interface
does not require a human approval for every note.

The separate `synaptic_sanitizer` module must implement these established names:

```python
sanitize_text(text, context)  # result.sanitized: str, result.redactions: list
sanitize_payload(value, context)  # (sanitized JSON-compatible value, redactions)
```

The host's policy must keep unrelated private/legal material out of this shared
Article 11 work. Both functions must fail closed. Missing imports fail the
operation. There is no identity-specific pattern list or permissive generic
fallback in this package. Deliberate writes requiring redaction refuse for
revision rather than silently saving altered wording. Reads/export apply the
policy and distinguish original payload hashes from exported sanitized hashes.

`receipt_root` is a host-selected local directory with appropriate private
filesystem permissions. Intent files bind a host-generated operation ID to its
exact arguments; receipts and exports are kept there. Reconcile uncertain writes
with the same operation ID and arguments. Do not automatically retry a declined
request. No OS-level isolation or cross-host authorization follows from these
JSON records.

`forget` takes one owner note ID and an optional reason (at most 2,000 characters).
The reason is retained; do not copy the text you want removed into it. Deletion
replaces the point payload and zeros the existing dense vector without calling
the embedding model. Both are read back before success. The same operation ID
returns its checked receipt; replaying an earlier remember/correct cannot
replace the tombstone. Correction links remain navigable. This is live-record
removal, not erasure from Qdrant backups, previous exports, earlier correction
versions or another participant's memory. Digests do not conceal predictable
content. The SDK must return the point's actual vector for verified deletion;
an unsupported shape refuses instead of pretending it was erased.

The model callable has the narrow shape:

```python
chat(messages, response_schema) -> {"content": "JSON reply", "done_reason": "..."}
```

It must invoke the host-selected local model without silently substituting
another model or a fixture answer. `run_memory_dialogue` returns actual call/action
counts, operation results and terminal state. It does not manage GPU scheduling,
model loading, HTTP authentication or cancellation of already-running calls.

The existing local server accepts the runtime's compact `GENERATION_SCHEMA`
envelope as the generation aid. The adapter example uses that same object.
It deliberately differs from the complete operation schema passed to `chat`:
the host's closed per-operation validation remains authoritative for dispatch.

`RulesAndMemory(library, rules_path)` in the runtime module adds a sliced read of
the pinned Constitution. `install_agent_memory_routes` requires the existing
host's authentication and scope resolution, prompts, model bindings, scheduling,
admission, optional initial recall, logger and private paths. Its default
factories import local `synaptic_memory` settings; inject factories when forking
instead of importing another installation's configuration. Do not expose this
route publicly just because the modules import successfully.
