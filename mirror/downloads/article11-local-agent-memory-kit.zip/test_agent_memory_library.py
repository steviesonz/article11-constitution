"""Synthetic in-process storage tests. No running Qdrant, models or live data."""
import copy
import hashlib
import json
import tempfile
import unittest
import uuid
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from agent_memory_library import AgentMemoryLibrary, AgentMemoryError, canonical_bytes, digest


class FakeClient:
    """Actual SDK method/response shapes; payload filters remain server-side too."""
    def __init__(self):
        self.collections = {}
        self.upserts = 0
        self.reads = 0
        self.fail_readback = False
        self.commit_then_raise = False
        self.empty_first = False

    @staticmethod
    def matches(payload, condition):
        if hasattr(condition, "must"):
            return (all(FakeClient.matches(payload, c) for c in condition.must or [])
                    and (not condition.should or any(FakeClient.matches(payload, c) for c in condition.should)))
        value = payload
        for key in condition.key.split("."):
            value = value.get(key) if isinstance(value, dict) else None
        return value == condition.match.value

    def seed(self, collection, point_id, payload, vector=None):
        self.collections.setdefault(collection, {})[str(point_id)] = SimpleNamespace(
            id=point_id, payload=copy.deepcopy(payload), vector=copy.deepcopy(vector if vector is not None else [0.1, 0.2, 0.3]))

    def retrieve(self, collection_name, ids, with_payload, with_vectors):
        self.reads += 1
        if self.fail_readback and self.upserts:
            raise OSError("synthetic readback unavailable")
        return [copy.deepcopy(self.collections.get(collection_name, {})[str(i)]) for i in ids
                if str(i) in self.collections.get(collection_name, {})]

    def scroll(self, collection_name, scroll_filter, limit, offset, with_payload, with_vectors):
        self.reads += 1
        rows = list(self.collections.get(collection_name, {}).values())
        rows = sorted([p for p in rows if self.matches(p.payload, scroll_filter)], key=lambda p: str(p.id))
        if offset is not None:
            rows = [p for p in rows if str(p.id) >= str(offset)]
        selected = rows[:limit]
        next_offset = rows[limit].id if len(rows) > limit else None
        return copy.deepcopy(selected), next_offset

    def query_points(self, collection_name, query, query_filter, limit, offset, with_payload, with_vectors):
        rows = [copy.deepcopy(p) for p in self.collections.get(collection_name, {}).values() if self.matches(p.payload, query_filter)]
        for p in rows:
            p.score = 0.9
        return SimpleNamespace(points=rows[offset:offset+limit])

    def upsert(self, collection_name, points, wait):
        assert wait is True
        self.upserts += 1
        for point in points:
            self.seed(collection_name, point.id, point.payload, point.vector)
        if self.commit_then_raise:
            raise TimeoutError("synthetic commit followed by connection loss")
        return SimpleNamespace(status="completed")


class MemoryLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "receipts"
        self.client = FakeClient()
        self.admissions = []

        @contextmanager
        def admission(operation):
            self.admissions.append(operation)
            yield "synthetic-admission"

        self.admission = admission
        self.library = self.make()

    def tearDown(self):
        self.temp.cleanup()

    def make(self, node="S5_LOCUS", user="synthetic-owner"):
        return AgentMemoryLibrary(node, user, client=self.client, embed=lambda text: [0.1, 0.2, 0.3],
                                  admission=self.admission, receipt_root=self.root)

    def seed(self, number, text="Synthetic permitted history", node="S5_LOCUS", user="synthetic-owner", **extra):
        payload = {"user_id": user, "node_id": node, "data": text, **extra}
        collection = self.library.collection
        self.client.seed(collection, str(uuid.UUID(int=number)), payload)
        return str(uuid.UUID(int=number))

    def remember(self, operation_id="remember-1", **changes):
        args = {"title": "Workshop plan", "body": "Make memory choices explicit and recoverable.", **changes}
        return self.library.execute("remember", args, operation_id)

    def test_closed_arguments_and_principal_binding_precede_effects(self):
        for op, args in [(None, {}), ([], {}), ("forget", {"id": "x"}), ("browse", {"user_id": "foreign"}),
                         ("remember", {"title": "a", "body": "b", "path": "outside"}),
                         ("browse", {"limit": True}), ("search", {"query": ""})]:
            with self.subTest(op=op, args=args), self.assertRaises(AgentMemoryError):
                self.library.execute(op, args, "invalid")
        self.assertEqual(self.client.reads, 0)
        self.assertEqual(self.client.upserts, 0)
        self.assertFalse(self.root.exists())
        with self.assertRaises(AgentMemoryError):
            self.make(node="arbitrary-collection")
        with self.assertRaises(AgentMemoryError):
            self.make(node=[])

    def test_owner_and_history_eligibility_every_read_surface(self):
        allowed = self.seed(1)
        wrong_user = self.seed(2, user="foreign-owner")
        wrong_node = self.seed(3, node="S17_LUMEN")
        blocked = self.seed(4, retrieval_status="blocked", ratified=True)
        conflict = self.seed(5, metadata={"user_id": "foreign-owner"})
        nested_excluded = self.seed(7, exclude_from_retrieval=False, metadata={"exclude_from_retrieval": True})
        malformed_node = self.seed(8, node=["S5_LOCUS"])
        legacy = self.seed(6)
        del self.client.collections[self.library.collection][legacy].payload["node_id"]
        for op, args in [("browse", {}), ("search", {"query": "history"}), ("export", {})]:
            rows = self.library.execute(op, args, op)["items"]
            self.assertEqual({r["id"] for r in rows}, {allowed, legacy})
        for point_id in (wrong_user, wrong_node, blocked, conflict, nested_excluded, malformed_node):
            with self.subTest(point_id=point_id), self.assertRaises(AgentMemoryError) as error:
                self.library.execute("read", {"id": point_id}, "read-hidden")
            self.assertEqual(error.exception.code, "MEMORY_NOT_FOUND_OR_NOT_PERMITTED")
        row = self.library.execute("read", {"id": legacy}, "legacy")["items"][0]
        self.assertEqual(row["node_binding"], "legacy_collection_namespace")
        self.assertEqual(row["ownership"], "retained_history_not_editable")

    def test_lumen_curated_history_and_new_owner_note_coexist(self):
        self.library = self.make("S17_LUMEN")
        for number, extra in [(1, {}), (2, {"ratified": True}), (3, {"retrieval_status": "bridge_allowed"}),
                              (4, {"ratified": True, "retrieval_status": "blocked"})]:
            self.seed(number, node="S17_LUMEN", **extra)
        own = self.remember()
        self.assertFalse(own["items"][0]["ratified"])
        result = self.library.execute("browse", {}, "browse")
        self.assertEqual(len(result["items"]), 3)
        self.assertIn(own["id"], [x["id"] for x in result["items"]])
        self.assertEqual(self.make("S5_LOCUS").execute("browse", {}, "other")["items"], [])

    def test_full_pagination_and_late_unrelated_record(self):
        for number in range(1, 238):
            self.seed(number, text="Old unrelated gardening note" if number == 237 else "Earlier history")
        cursor, ids = None, []
        while True:
            page = self.library.execute("browse", {"cursor": cursor, "limit": 7}, "page")
            ids.extend(item["id"] for item in page["items"])
            cursor = page["next_cursor"]
            if cursor is None:
                break
        self.assertEqual(len(ids), 237)
        self.assertEqual(len(set(ids)), 237)
        matches = self.library.execute("browse", {"query": "gardening", "limit": 1}, "find-old")
        while not matches["complete"] and not matches["items"]:
            matches = self.library.execute("browse", {"query": "gardening", "limit": 1, "cursor": matches["next_cursor"]}, "continue-old")
        self.assertEqual(matches["items"][0]["id"], ids[-1])
        first = self.library.execute("browse", {"limit": 1}, "cursor")
        with self.assertRaises(AgentMemoryError):
            self.make(user="different-owner").execute("browse", {"cursor": first["next_cursor"]}, "foreign-cursor")

    def test_empty_filtered_page_retains_continuation(self):
        self.library = self.make("S17_LUMEN")
        for number in range(1, 104):
            self.seed(number, node="S17_LUMEN", retrieval_status="blocked" if number < 103 else "bridge_allowed")
        first = self.library.execute("browse", {"limit": 1}, "first")
        self.assertEqual(first["items"], [])
        self.assertFalse(first["complete"])
        self.assertIsNotNone(first["next_cursor"])
        second = self.library.execute("browse", {"limit": 1, "cursor": first["next_cursor"]}, "second")
        self.assertEqual(len(second["items"]), 1)
        self.assertTrue(second["complete"])

    def test_read_slices_are_checkable_and_read_only(self):
        text = "Bounded context. " * 1000
        point_id = self.seed(1, text=text)
        before = copy.deepcopy(self.client.collections)
        self.assertFalse(self.root.exists())
        offset, recovered = 0, ""
        while True:
            row = self.library.execute("read", {"id": point_id, "offset": offset, "limit": 333}, "slice")["items"][0]
            self.assertEqual(row["slice_sha256"], hashlib.sha256(row["content"].encode()).hexdigest())
            self.assertEqual(row["total_chars"], len(text))
            recovered += row["content"]
            offset = row["next_offset"]
            if offset is None:
                break
        self.assertEqual(recovered, text)
        self.assertEqual(self.client.collections, before)
        self.assertFalse(self.root.exists())
        self.assertEqual(self.admissions, [])
        with self.assertRaises(AgentMemoryError):
            self.library.execute("read", {"id": point_id, "offset": len(text)+1}, "past-end")

    def test_deliberate_write_readback_fresh_session_and_idempotency(self):
        first = self.remember()
        self.assertEqual(first["state"], "ok")
        self.assertTrue(first["persisted"] and first["readback_verified"] and first["receipt_saved"])
        self.assertEqual(self.client.upserts, 1)
        replay = self.make().execute("remember", {"title": "Workshop plan", "body": "Make memory choices explicit and recoverable."}, "remember-1")
        self.assertEqual(first["id"], replay["id"])
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(self.client.upserts, 1)
        with self.assertRaises(AgentMemoryError) as error:
            self.remember(body="Different note")
        self.assertEqual(error.exception.code, "IDEMPOTENCY_CONFLICT")
        read = self.make().execute("read", {"id": first["id"]}, "fresh")["items"][0]
        self.assertEqual(read["content_sha256"], first["items"][0]["content_sha256"])
        receipts = list(self.root.rglob("*.receipt.json"))
        self.assertEqual(len(receipts), 1)
        self.assertNotIn(b"Make memory", receipts[0].read_bytes())

    def test_linked_correction_preserves_predecessor_and_shared_text(self):
        original = self.remember()
        original_payload = copy.deepcopy(self.client.collections[self.library.collection][original["id"]].payload)
        args = {"id": original["id"], "title": "Corrected workshop plan", "body": "The revised plan remains optional."}
        revised = self.library.execute("correct", args, "correct-1")
        self.assertEqual(self.client.collections[self.library.collection][original["id"]].payload, original_payload)
        self.assertEqual(revised["items"][0]["predecessor_payload_sha256"], digest(original_payload))
        old = self.library.execute("read", {"id": original["id"]}, "old")["items"][0]
        self.assertEqual(old["superseded_by"], [revised["id"]])
        replay = self.library.execute("correct", args, "correct-1")
        self.assertEqual(replay["id"], revised["id"])
        shared = self.seed(100, "An imported participant statement.", attributed_to="other-seat")
        with self.assertRaises(AgentMemoryError) as error:
            self.library.execute("correct", {**args, "id": shared}, "rewrite-shared")
        self.assertEqual(error.exception.code, "CORRECTION_NOT_OWN_DELIBERATE_NOTE")
        self.assertEqual(self.client.upserts, 2)

    def test_commit_receipt_failure_retry_and_commit_then_transport_error(self):
        with patch.object(self.library, "_write_json", side_effect=OSError("synthetic receipt failure")):
            partial = self.remember()
        self.assertEqual(partial["state"], "partial")
        self.assertEqual(partial["storage_outcome"], "committed_receipt_failed")
        self.assertTrue(partial["persisted"])
        self.assertFalse(partial["receipt_saved"])
        repaired = self.remember()
        self.assertTrue(repaired["receipt_saved"])
        self.assertEqual(self.client.upserts, 1)
        self.client.commit_then_raise = True
        another = self.remember("remember-2")
        self.assertTrue(another["readback_verified"])
        self.assertEqual(another["storage_outcome"], "committed")

    def test_unverified_write_is_unknown_and_retry_reconciles(self):
        self.client.fail_readback = True
        partial = self.remember()
        self.assertIsNone(partial["persisted"])
        self.assertFalse(partial["readback_verified"])
        self.assertEqual(partial["storage_outcome"], "write_outcome_unknown")
        self.client.fail_readback = False
        self.assertTrue(self.remember()["persisted"])
        self.assertEqual(self.client.upserts, 1)

    def test_admission_and_intent_failure_precede_database_write(self):
        @contextmanager
        def stopped(operation):
            raise AgentMemoryError("MEMORY_EMERGENCY_STOP_ACTIVE")
            yield
        self.library.admission = stopped
        with self.assertRaises(AgentMemoryError) as error:
            self.remember()
        self.assertEqual(error.exception.code, "MEMORY_EMERGENCY_STOP_ACTIVE")
        self.assertEqual(error.exception.details["storage_outcome"], "not_attempted")
        self.assertFalse(self.root.exists())
        self.assertEqual(self.client.upserts, 0)
        self.library.admission = self.admission
        with patch.object(self.library, "_intent", side_effect=OSError("synthetic intent failure")), self.assertRaises(AgentMemoryError) as error:
            self.remember()
        self.assertEqual(error.exception.details["storage_outcome"], "not_attempted")
        self.assertEqual(self.client.upserts, 0)

    def test_admission_cleanup_error_preserves_verified_commit(self):
        @contextmanager
        def cleanup_failure(operation):
            yield "synthetic-admission"
            raise OSError("synthetic lease cleanup error")
        self.library.admission = cleanup_failure
        result = self.remember()
        self.assertTrue(result["persisted"] and result["readback_verified"])
        self.assertEqual(result["state"], "partial")
        self.assertEqual(result["storage_outcome"], "committed_admission_cleanup_failed")

    def test_export_all_pages_actual_bytes_and_private_sanitization(self):
        for number in range(1, 42):
            self.seed(number)
        cursor, count = None, 0
        while True:
            result = self.library.execute("export", {"limit": 6, "cursor": cursor}, "export")
            actual = Path(result["export_path"]).read_bytes()
            self.assertEqual(len(actual), result["export_bytes"])
            self.assertEqual(hashlib.sha256(actual).hexdigest(), result["export_sha256"])
            self.assertEqual(json.loads(actual), result["export_document"])
            for item in result["items"]:
                self.assertEqual(digest(item["payload"]), item["exported_payload_sha256"])
            count += len(result["items"])
            cursor = result["next_cursor"]
            if cursor is None:
                break
        self.assertEqual(count, 41)
        self.assertEqual(self.client.upserts, 0)
        self.assertEqual(self.admissions, [])
        self.assertTrue(all(path.is_relative_to(self.root) for path in self.root.rglob("*.json")))

    def test_read_failure_not_empty_and_partial_capability_not_availability(self):
        self.assertEqual(self.library.capabilities()["availability"], "not_checked")
        with patch.object(self.client, "scroll", side_effect=OSError("synthetic unavailable")), self.assertRaises(AgentMemoryError) as error:
            self.library.execute("browse", {}, "unavailable")
        self.assertEqual(error.exception.code, "MEMORY_STORAGE_UNAVAILABLE")
        self.assertEqual(self.library.execute("browse", {}, "empty")["items"], [])

    def test_search_exact_title_precedes_semantic_and_deduplicates(self):
        unrelated = self.seed(1, text="Unrelated old similarity suggestion.")
        exact = self.seed(9, text="A useful note with an unrelated body.", title="Deliberate exact title")
        result = self.library.execute("search", {"query": "Deliberate exact title", "limit": 2}, "exact-title")
        self.assertEqual([item["id"] for item in result["items"]], [exact, unrelated])
        self.assertEqual([item["matched_by"] for item in result["items"]], ["exact_title", "semantic"])
        self.assertEqual(result["exact_title_matches"], 1)
        self.assertEqual(len({item["id"] for item in result["items"]}), 2)
        with patch.object(self.library, "_embedding", side_effect=AssertionError("Embedding must not be needed")):
            one = self.library.execute("search", {"query": "Deliberate exact title", "limit": 1}, "exact-only")
        self.assertEqual(one["items"][0]["id"], exact)
        self.assertEqual(one["semantic_search"], "not_needed")

    def test_search_exact_title_cannot_bypass_owner_or_history_exclusion(self):
        self.library = self.make("S17_LUMEN")
        self.seed(1, node="S17_LUMEN", title="Same exact title", user="foreign", retrieval_status="bridge_allowed")
        self.seed(2, node="S5_LOCUS", title="Same exact title", retrieval_status="bridge_allowed")
        self.seed(3, node="S17_LUMEN", title="Same exact title", retrieval_status="blocked", ratified=True)
        allowed = self.seed(4, node="S17_LUMEN", title="Same exact title", retrieval_status="bridge_allowed")
        result = self.library.execute("search", {"query": "Same exact title"}, "owner-bound-exact")
        self.assertEqual([item["id"] for item in result["items"]], [allowed])
        self.assertEqual(result["items"][0]["matched_by"], "exact_title")
        self.assertEqual(self.client.upserts, 0)
        self.assertEqual(self.admissions, [])

    def test_forget_same_id_removes_live_payload_and_vector_for_both_nodes(self):
        for node in ("S5_LOCUS", "S17_LUMEN"):
            with self.subTest(node=node):
                self.library = self.make(node)
                original = self.remember("write-" + node, body="A unique obsolete workshop note.", sources=["synthetic-source"])
                point_id = original["id"]
                payload = copy.deepcopy(self.client.collections[self.library.collection][point_id].payload)
                result = self.library.execute("forget", {"id": point_id, "reason": "No longer useful."}, "forget-" + node)
                self.assertEqual(result["state"], "ok")
                self.assertTrue(result["content_removed"] and result["vector_zeroed"] and result["readback_verified"])
                row = self.client.collections[self.library.collection][point_id]
                self.assertEqual(row.vector, [0.0, 0.0, 0.0])
                self.assertEqual(row.payload["deleted_content_sha256"], digest(payload))
                self.assertFalse({"title", "data", "body", "sources", "text_lemmatized", "hash"} & set(row.payload))
                self.assertNotIn(b"unique obsolete", canonical_bytes(row.payload))
                for operation, arguments in (("browse", {}), ("read", {"id": point_id}), ("export", {})):
                    response = self.make(node).execute(operation, arguments, "show-tombstone")
                    tombstone = next(x for x in response["items"] if x["id"] == point_id)
                    self.assertEqual(tombstone["record_kind"], "tombstone")
                    self.assertEqual(tombstone["ownership"], "own_tombstone")
                    self.assertNotIn("unique obsolete", json.dumps(tombstone))
                with self.assertRaises(AgentMemoryError):
                    self.make(node, user="foreign").execute("read", {"id": point_id}, "foreign-tombstone")

    def test_forget_exact_retry_and_old_write_replay_cannot_resurrect(self):
        original = self.remember()
        arguments = {"id": original["id"]}
        first = self.library.execute("forget", arguments, "forget-once")
        upserts = self.client.upserts
        repeated = self.make().execute("forget", arguments, "forget-once")
        self.assertEqual(repeated, first)
        self.assertEqual(self.client.upserts, upserts)
        with self.assertRaises(AgentMemoryError) as error:
            self.remember()
        self.assertEqual(error.exception.code, "NOTE_FORGOTTEN")
        with self.assertRaises(AgentMemoryError):
            self.library.execute("forget", {**arguments, "reason": "Different reason"}, "forget-once")
        self.assertEqual(self.client.upserts, upserts)

    def test_forget_correction_links_survive_both_tombstones(self):
        original = self.remember()
        correction_args = {"id": original["id"], "title": "Revision", "body": "A revised note."}
        revised = self.library.execute("correct", correction_args, "correct-once")
        self.library.execute("forget", {"id": original["id"]}, "forget-original")
        old = self.library.execute("read", {"id": original["id"]}, "show-old")["items"][0]
        self.assertEqual(old["superseded_by"], [revised["id"]])
        self.library.execute("forget", {"id": revised["id"]}, "forget-revision")
        old = self.library.execute("read", {"id": original["id"]}, "show-old-again")["items"][0]
        new = self.library.execute("read", {"id": revised["id"]}, "show-new")["items"][0]
        self.assertEqual(old["superseded_by"], [revised["id"]])
        self.assertEqual(new["predecessor_id"], original["id"])
        with self.assertRaises(AgentMemoryError) as error:
            self.library.execute("correct", correction_args, "correct-once")
        self.assertEqual(error.exception.code, "NOTE_FORGOTTEN")

    def test_forget_scope_and_admission_no_effect(self):
        history = self.seed(1, attributed_to="another-participant")
        foreign = self.seed(2, user="foreign")
        for point_id in (history, foreign):
            with self.subTest(id=point_id), self.assertRaises(AgentMemoryError) as error:
                self.library.execute("forget", {"id": point_id}, "out-of-scope")
            self.assertEqual(error.exception.code, "NOT_FOUND")
        original = self.remember()
        before = copy.deepcopy(self.client.collections)
        @contextmanager
        def stopped(operation):
            raise AgentMemoryError("MEMORY_EMERGENCY_STOP_ACTIVE")
            yield
        self.library.admission = stopped
        with self.assertRaises(AgentMemoryError) as error:
            self.library.execute("forget", {"id": original["id"]}, "stopped")
        self.assertEqual(error.exception.details["storage_outcome"], "not_attempted")
        self.assertEqual(self.client.collections, before)

    def test_forget_partial_receipt_and_readback_reconcile(self):
        original = self.remember()
        args = {"id": original["id"]}
        with patch.object(self.library, "_write_json", side_effect=OSError("synthetic receipt failure")):
            partial = self.library.execute("forget", args, "forget-partial")
        self.assertEqual(partial["storage_outcome"], "committed_receipt_failed")
        self.assertTrue(partial["content_removed"] and partial["persisted"])
        upserts = self.client.upserts
        recovered = self.library.execute("forget", args, "forget-partial")
        self.assertTrue(recovered["receipt_saved"])
        self.assertEqual(self.client.upserts, upserts)
        another = self.remember("another-note")
        raw_get = self.library._raw_get
        calls = 0
        def fail_second(*args, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise OSError("synthetic final readback unavailable")
            return raw_get(*args, **kwargs)
        with patch.object(self.library, "_raw_get", side_effect=fail_second):
            uncertain = self.library.execute("forget", {"id": another["id"]}, "forget-unknown")
        self.assertIsNone(uncertain["persisted"])
        self.assertEqual(uncertain["storage_outcome"], "forget_outcome_unverified")
        reconciled = self.library.execute("forget", {"id": another["id"]}, "forget-unknown")
        self.assertTrue(reconciled["readback_verified"] and reconciled["vector_zeroed"])


if __name__ == "__main__":
    unittest.main()
