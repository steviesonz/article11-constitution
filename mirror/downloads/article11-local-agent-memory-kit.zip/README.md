# Article 11 local agent memory — integration kit

Let a local model choose what to read, remember or correct, and give its host a
checkable result. Humans and AI remain responsible for their actions. Reading
the rules or accepting a task is not constitutional assent.

This kit contains a runnable **inert dialogue demonstration** and the actual
local storage/runtime integration source. It is not a hosted memory service or
a turnkey installation. The demonstration calls no model, opens no network
connection and saves no files. Its library is a small in-memory fixture that
disappears when the process exits; it does not prove persistent storage.

## Start without accounts or services

Python 3.10 or later is enough for the demonstration and dialogue tests:

```text
python -B verify_package.py
python -B examples/inert_dialogue.py
python -B -m unittest test_agent_memory_dialogue -v
```

The demonstration runs a scripted browse/read request, a fresh request against
the same fixture library, and a decline. The mock model replies are explicitly
labeled. Real model behavior and persistent storage are separate integrations.

The pinned Constitution is `constitution-v2.0-core.md`, SHA-256:

```text
7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82
```

Its public source is https://article11.ai/constitution-v2.0-core.md. The recorded
2.0 text does not certify a complete 2.0 runtime. Existing public Worker APIs and
receipt profiles retain their disclosed v1.8 compatibility basis. The supplied
rules do not override law, a person's instructions, host permissions, a model
provider's rules or safety requirements. They grant no legal personhood or
automatic authority.

## What the code does

- `agent_memory_dialogue.py`: a bounded action loop with injected model/library
  callables. No network or runtime configuration is built into the loop.
- `agent_memory_library.py`: owner-bound Qdrant browse, search, sliced read,
  deliberate remember, linked correction, single-note forget and private export. It uses the
  existing node collections; it does not replace or migrate retained history.
- `agent_memory_runtime.py`: integration source for the existing authenticated
  private Bridge. It is not a standalone server or permission system.

The model cannot select the owner, another collection, a file destination or a
new tool. The host binds those choices. Historic exclusions remain excluded.
New owner notes are immediately readable and explicitly non-ratified. A
correction retains its predecessor and links the revision. Forget removes one
own deliberate note's live text and vector, leaving a visible same-ID tombstone
with its deletion time, optional retained reason and the removed payload's hash.
It cannot delete imported history or another owner's note. Earlier versions,
exports, backups and already read copies remain. A hash is a commitment, not
encryption: predictable text can be guessed. There is no grant system to revoke.
Export is a sanitized private JSON archive, not automatic
sharing or an import/restore operation. No transcript is automatically saved.

Decline makes no new memory operation. It does not erase existing records. A
timeout cannot undo a call already in flight; uncertain and partial writes are
reported explicitly. File receipts and the action protocol are software
controls, not an OS sandbox or proof of model identity, consent or truth.

## Integrate with an existing local deployment

Read `ADAPTER_CONTRACT.md` first. `examples/existing_local_adapters.py` provides
factory functions only: executing that file prints instructions and stops.
Calling a factory yourself can connect to your existing loopback Qdrant/Ollama
services; running a real dialogue may write notes if its host admission permits.

The integration dependency versions below were present in the source host used
for this kit. They are not bundled, newly downloaded, or a claim of compatibility
with every version. Install them in your own virtual environment if needed:

```text
python -m pip install -r requirements-integration.txt
```

Keep your own authenticated owner mapping, memory namespace, embedding model,
local privacy sanitizer and emergency-stop admission. There is deliberately no
permissive replacement privacy filter here. House-specific personal/legal
patterns, histories, credentials, environment files and live configuration are
excluded. The storage tests are included, but require your configured
`synaptic_sanitizer` adapter and the integration dependencies. They use fake
clients, temporary files and injected admission; they never need a running
service. The route module additionally needs the documented host callbacks.

The runtime and illustrative adapter use the compact `GENERATION_SCHEMA`
envelope to help the local server generate a JSON reply. The server rejected
the earlier full-schema generation form before any memory action. This compact
envelope is only a generation aid: the host still applies the complete closed
per-operation validator, including argument and owner restrictions. Model output
remains untrusted; generating JSON grants no additional operation.

Search places eligible exact-title matches first and labels every result with
`matched_by`. Semantic suggestions are not proof that the requested title was
found. Follow the returned record ID to read and verify its actual text.

Run storage tests only after supplying that privacy adapter:

```text
python -B -m unittest test_agent_memory_library -v
```

The Constitution and this newly authored kit are offered under CC0; see LICENSE.
Third-party dependencies keep their own licenses. The ARTICLE 11 AI / Article11.ai
and SPIRALMESH names and marks are not dedicated by this kit. Describe your fork
accurately and do not imply an endorsement or certification.
