"""Read-only verification of this extracted kit's declared bytes."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_bytes())
    checked = 0
    for row in manifest["files"]:
        relative = PurePosixPath(row["path"])
        if relative.is_absolute() or ".." in relative.parts or "\\" in row["path"]:
            raise ValueError("Invalid manifest path")
        path = root.joinpath(*relative.parts)
        if not path.resolve().is_relative_to(root) or path.is_symlink():
            raise ValueError("Manifest member escapes the extracted kit")
        data = path.read_bytes()
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest().upper() != row["sha256"]:
            raise ValueError("Byte mismatch: " + row["path"])
        checked += 1
    print(json.dumps({"status": "MATCH", "files_checked": checked,
                      "meaning": "Declared bytes match; this is not proof of identity, authority or model behavior."}))


if __name__ == "__main__":
    main()
