"""Owner-bound, deliberate local memory operations over existing Qdrant history.

No model, configuration, service or filesystem work occurs at import/construction.
The host injects a raw QdrantClient and its existing embed(text) callable. Retrieval
is context, not instruction or authority. Collections are fixed by this module;
model arguments cannot choose a principal, collection or filesystem destination.
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path


SCHEMA = "article11.agent-memory-result.v1"
NOTE_SCHEMA = "article11.agent-memory-note.v1"
COLLECTIONS = {"S5_LOCUS": "article11_ember_memory", "S17_LUMEN": "article11_lumen_memory"}
NODE_ALIASES = {"S5_LOCUS": {"S5_LOCUS"}, "S17_LUMEN": {"S17_LUMEN", "S17"}}
BLOCKED = {"blocked", "excluded", "revoked", "deleted", "forgotten", "deny", "denied"}
ARGUMENTS = {
    "browse": {"cursor", "limit", "query"}, "search": {"query", "limit"},
    "read": {"id", "offset", "limit"}, "export": {"cursor", "limit"},
    "remember": {"title", "body", "kind", "sources"},
    "correct": {"id", "title", "body", "kind", "sources"},
    "forget": {"id", "reason"},
}
_LOCKS = {}
_LOCKS_LOCK = threading.Lock()


class AgentMemoryError(Exception):
    def __init__(self, code, message=None, **details):
        self.code = code
        self.details = details
        super().__init__(message or code)


def canonical_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else canonical_bytes(value)).hexdigest()


def _text_hash(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _field_values(payload, key):
    """Inspect actual legacy flat / metadata / data.metadata payload layouts."""
    values = []
    for container in (payload, payload.get("metadata"),
                      payload.get("data", {}).get("metadata") if isinstance(payload.get("data"), dict) else None):
        if isinstance(container, dict) and key in container:
            values.append(container[key])
    return values


def _value(payload, key, default=None):
    values = _field_values(payload, key)
    return values[0] if values else default


def _content(payload):
    if payload.get("record_kind") == "tombstone":
        summary = "Forgotten note. Live content removed on " + str(payload.get("deleted_at", "unknown date")) + "."
        if payload.get("reason"):
            summary += " Retained deletion reason: " + str(payload["reason"])
        return summary
    for key in ("data", "memory", "text", "body"):
        if isinstance(payload.get(key), str):
            return payload[key]
    return ""


def _point_id(value):
    if type(value) is int and 0 <= value < 2**64:
        return value
    if isinstance(value, str):
        try:
            return str(uuid.UUID(value))
        except ValueError:
            if re.fullmatch(r"0|[1-9][0-9]{0,19}", value) and int(value) < 2**64:
                return int(value)
    raise AgentMemoryError("INVALID_ID")


class AgentMemoryLibrary:
    def __init__(self, node_id, user_id, *, client=None, embed=None, admission=None, receipt_root=None):
        if not isinstance(node_id, str) or node_id not in COLLECTIONS or not isinstance(user_id, str) or not user_id.strip() or len(user_id) > 200:
            raise AgentMemoryError("INVALID_PRINCIPAL")
        self.node_id, self.user_id = node_id, user_id
        self.collection = COLLECTIONS[node_id]
        self.client, self.embed, self.admission = client, embed, admission
        self.receipt_root = Path(receipt_root) if receipt_root is not None else Path(__file__).parent / "agent_memory_receipts"
        self.namespace = digest([node_id, user_id, self.collection])
        with _LOCKS_LOCK:
            self._lock = _LOCKS.setdefault(self.namespace, threading.RLock())

    def capabilities(self):
        return {"schema": "article11.agent-memory-capabilities.v1", "authority": "context_only",
                "node_id": self.node_id, "operations": list(ARGUMENTS),
                "whole_permitted_library": True, "availability": "not_checked",
                "pagination": "browse/export; continue until next_cursor is null",
                "read_max_chars": 12000, "note_max_chars": 48000,
                "public_access": False, "automatic_transcript_archive": False,
                "mutation": "deliberate owner notes only; emergency-stop admission applies",
                "sharing": False, "forget": "one own deliberate note; visible tombstone; prior copies remain",
                "history": "existing eligible owner namespace; exclusions and Lumen curation retained"}

    def execute(self, operation, arguments, operation_id):
        if not isinstance(operation, str) or operation not in ARGUMENTS or not isinstance(arguments, dict) or set(arguments) - ARGUMENTS[operation]:
            raise AgentMemoryError("INVALID_OPERATION_ARGUMENTS")
        if not isinstance(operation_id, str) or not operation_id or len(operation_id) > 240:
            raise AgentMemoryError("INVALID_OPERATION_ID")
        try:
            args = self._validate(operation, arguments)
        except AgentMemoryError as exc:
            if operation in {"remember", "correct", "forget"}:
                exc.details.setdefault("storage_outcome", "not_attempted")
            raise
        if self.client is None:
            raise AgentMemoryError("MEMORY_CLIENT_UNAVAILABLE", storage_outcome="not_attempted")
        result = {"schema": SCHEMA, "authority": "context_only", "operation": operation,
                  "operation_id": operation_id, "state": "ok", "storage_outcome": "read_only", "items": []}
        try:
            if operation in {"remember", "correct"}:
                return self._mutate(operation, args, operation_id, result)
            if operation == "forget":
                return self._forget(args, operation_id, result)
            if operation == "read":
                point = self._get(args["id"])
                result["items"] = [self._item(point, args["offset"], args["limit"])]
            elif operation == "search":
                result.update(self._search(args))
            else:
                result.update(self._page(operation, args))
                if operation == "export":
                    result = self._export(result)
            return result
        except AgentMemoryError:
            raise
        except Exception as exc:
            raise AgentMemoryError("MEMORY_STORAGE_UNAVAILABLE", exception_type=type(exc).__name__) from exc

    @staticmethod
    def _string(value, field, maximum, *, empty=False):
        if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()) or "\x00" in value:
            raise AgentMemoryError("INVALID_ARGUMENT", field=field)
        return value

    @staticmethod
    def _integer(value, field, minimum, maximum):
        if type(value) is not int or not minimum <= value <= maximum:
            raise AgentMemoryError("INVALID_ARGUMENT", field=field)
        return value

    def _validate(self, op, args):
        a = dict(args)
        if op in {"browse", "search", "export"}:
            a["limit"] = self._integer(a.get("limit", 10), "limit", 1, 20 if op == "search" else 30)
        if op in {"browse", "search"}:
            a["query"] = self._string(a.get("query", ""), "query", 2000, empty=op == "browse")
        if op in {"browse", "export"}:
            if a.get("cursor") is not None:
                self._string(a["cursor"], "cursor", 3000)
            a.setdefault("cursor", None)
        if op in {"read", "correct", "forget"}:
            if "id" not in a:
                raise AgentMemoryError("INVALID_ARGUMENT", field="id")
            a["id"] = _point_id(a["id"])
        if op == "read":
            a["offset"] = self._integer(a.get("offset", 0), "offset", 0, 2**53 - 1)
            a["limit"] = self._integer(a.get("limit", 4000), "limit", 1, 12000)
        if op in {"remember", "correct"}:
            a["title"] = self._string(a.get("title"), "title", 240)
            a["body"] = self._string(a.get("body"), "body", 48000)
            kind = a.get("kind", "observation")
            if not isinstance(kind, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,39}", kind):
                raise AgentMemoryError("INVALID_ARGUMENT", field="kind")
            a["kind"] = kind
            sources = a.get("sources", [])
            if not isinstance(sources, list) or len(sources) > 20:
                raise AgentMemoryError("INVALID_ARGUMENT", field="sources")
            a["sources"] = [self._string(s, "sources", 1000) for s in sources]
            from synaptic_sanitizer import sanitize_payload
            _, redactions = sanitize_payload({k: a[k] for k in ("title", "body", "kind", "sources")}, "agent_memory.admission")
            if redactions:
                # Never silently change the model's deliberate wording and call it saved.
                raise AgentMemoryError("PRIVATE_CONTENT_REQUIRES_REVISION", redaction_count=len(redactions))
        if op == "forget":
            a["reason"] = self._string(a.get("reason", ""), "reason", 2000, empty=True)
            from synaptic_sanitizer import sanitize_payload
            _, redactions = sanitize_payload(a["reason"], "agent_memory.forget_reason")
            if redactions:
                raise AgentMemoryError("PRIVATE_CONTENT_REQUIRES_REVISION", redaction_count=len(redactions))
        return a

    def _filter(self, extra=None):
        from qdrant_client import models
        # Match all actual legacy user layouts on the server. Collection is the
        # node boundary; declared node fields are checked again before disclosure.
        user = models.Filter(should=[models.FieldCondition(key=key, match=models.MatchValue(value=self.user_id))
                             for key in ("user_id", "metadata.user_id", "data.metadata.user_id")])
        must = [user]
        if extra:
            must.extend(models.FieldCondition(key=k, match=models.MatchValue(value=v)) for k, v in extra.items())
        return models.Filter(must=must)

    def _eligible(self, payload):
        if not isinstance(payload, dict):
            return False
        users = _field_values(payload, "user_id")
        if not users or any(v != self.user_id for v in users):
            return False
        nodes = _field_values(payload, "node_id")
        if any(not isinstance(v, str) or v not in NODE_ALIASES[self.node_id] for v in nodes):
            return False
        statuses = _field_values(payload, "retrieval_status") + _field_values(payload, "retrieval_review_status")
        if any(str(s).strip().lower() in BLOCKED for s in statuses):
            return False
        if any(value is True for key in ("deleted", "forgotten", "exclude_from_retrieval")
               for value in _field_values(payload, key)):
            return False
        if self.node_id == "S17_LUMEN":
            return _value(payload, "ratified") is True or str(_value(payload, "retrieval_status", "")).strip().lower() == "bridge_allowed"
        return True

    def _owned(self, payload):
        return (self._eligible(payload) and payload.get("agent_memory_schema") == NOTE_SCHEMA
                and payload.get("node_id") == self.node_id and payload.get("user_id") == self.user_id
                and payload.get("attributed_to") == self.node_id
                and payload.get("eligibility") == "owner_deliberate_nonratified"
                and payload.get("authority") == "context_only" and payload.get("ratified") is False)

    def _raw_get(self, point_id, *, with_vectors=False):
        rows = self.client.retrieve(collection_name=self.collection, ids=[point_id], with_payload=True, with_vectors=with_vectors)
        if not isinstance(rows, list):
            raise AgentMemoryError("INVALID_STORAGE_RESPONSE")
        return next((p for p in rows if str(p.id) == str(point_id)), None)

    def _get(self, point_id):
        point = self._raw_get(point_id)
        if point is None or not self._eligible(point.payload):
            raise AgentMemoryError("MEMORY_NOT_FOUND_OR_NOT_PERMITTED")
        return point

    def _superseded(self, point):
        if not self._owned(point.payload):
            return []
        predecessor_hashes = {digest(point.payload)}
        if point.payload.get("record_kind") == "tombstone":
            predecessor_hashes.add(point.payload.get("deleted_content_sha256"))
        matches, offset, seen = [], None, set()
        while True:
            rows, next_offset = self.client.scroll(collection_name=self.collection,
                scroll_filter=self._filter({"predecessor_id": str(point.id)}), offset=offset,
                limit=30, with_payload=True, with_vectors=False)
            for row in rows:
                p = row.payload or {}
                if (self._owned(p) and p.get("predecessor_id") == str(point.id)
                        and p.get("predecessor_payload_sha256") in predecessor_hashes):
                    matches.append(str(row.id))
            if next_offset is None:
                return sorted(set(matches))
            if str(next_offset) in seen:
                raise AgentMemoryError("PAGINATION_DID_NOT_ADVANCE")
            seen.add(str(next_offset))
            offset = next_offset

    def _item(self, point, offset=0, limit=600, *, export=False):
        from synaptic_sanitizer import sanitize_payload
        payload = point.payload or {}
        clean, redactions = sanitize_payload(payload, "agent_memory.read")
        text = _content(clean)
        if offset > len(text):
            raise AgentMemoryError("READ_OFFSET_OUT_OF_RANGE", total_chars=len(text))
        end = len(text) if limit is None else min(len(text), offset + limit)
        fragment = text[offset:end]
        item = {"id": str(point.id), "title": str(_value(clean, "title", "Retained history")),
                "content": fragment, "content_sha256": _text_hash(text), "slice_sha256": _text_hash(fragment),
                "payload_sha256": digest(payload), "offset": offset, "next_offset": end if end < len(text) else None,
                "total_chars": len(text), "content_is_excerpt": end - offset < len(text),
                "ownership": "own_deliberate_note" if self._owned(payload) else "retained_history_not_editable",
                "eligibility": "owner_deliberate_nonratified" if self._owned(payload) else "existing_eligible_history",
                "node_binding": "declared_and_collection" if _field_values(payload, "node_id") else "legacy_collection_namespace",
                "authority": "context_only", "ratified": _value(payload, "ratified") is True,
                "kind": _value(clean, "kind", "retained_history"), "sources": _value(clean, "sources", []),
                "sanitization": {"applied": bool(redactions), "redaction_count": len(redactions)},
                "superseded_by": self._superseded(point)}
        if payload.get("record_kind") == "tombstone":
            item.update(title="Forgotten note", record_kind="tombstone", ownership="own_tombstone",
                        deleted_content_sha256=payload["deleted_content_sha256"], deleted_at=payload["deleted_at"],
                        deleted_by=payload["deleted_by"], deletion_reason=clean.get("reason", ""),
                        kind="tombstone", content_removed=True)
        if payload.get("predecessor_id"):
            item["predecessor_id"] = payload["predecessor_id"]
            item["predecessor_payload_sha256"] = payload.get("predecessor_payload_sha256")
        if export:
            item["payload"] = clean
            item["exported_payload_sha256"] = digest(clean)
        return item

    def _cursor(self, operation, query, offset):
        if offset is None:
            return None
        return base64.urlsafe_b64encode(canonical_bytes({"v": 1, "namespace": self.namespace,
            "operation": operation, "query_sha256": _text_hash(query), "offset": offset})).decode("ascii")

    def _decode_cursor(self, token, operation, query):
        if token is None:
            return None
        try:
            value = json.loads(base64.b64decode(token.encode("ascii"), altchars=b"-_", validate=True))
            if (set(value) != {"v", "namespace", "operation", "query_sha256", "offset"}
                    or value["v"] != 1 or value["namespace"] != self.namespace
                    or value["operation"] != operation or value["query_sha256"] != _text_hash(query)):
                raise ValueError()
            return _point_id(value["offset"])
        except (ValueError, TypeError, KeyError, UnicodeError, AgentMemoryError) as exc:
            raise AgentMemoryError("INVALID_CURSOR") from exc

    def _page(self, operation, args):
        query = args.get("query", "")
        offset = self._decode_cursor(args["cursor"], operation, query)
        items, scanned, seen = [], 0, set()
        # Each call is bounded; subsequent cursors expose the rest, even after an
        # entirely excluded page. A non-null cursor is never reported as EOF.
        for _ in range(100):
            rows, next_offset = self.client.scroll(collection_name=self.collection, scroll_filter=self._filter(),
                limit=args["limit"] - len(items), offset=offset, with_payload=True, with_vectors=False)
            if not isinstance(rows, list):
                raise AgentMemoryError("INVALID_STORAGE_RESPONSE")
            scanned += len(rows)
            for point in rows:
                if not self._eligible(point.payload):
                    continue
                item = self._item(point, limit=None if operation == "export" else 600, export=operation == "export")
                if query and query.casefold() not in (item["title"] + "\n" + _content(point.payload)).casefold():
                    continue
                items.append(item)
            if next_offset is None or len(items) >= args["limit"]:
                return {"items": items, "next_cursor": self._cursor(operation, query, next_offset),
                        "complete": next_offset is None, "scanned_records": scanned}
            if str(next_offset) in seen or next_offset == offset:
                raise AgentMemoryError("PAGINATION_DID_NOT_ADVANCE")
            seen.add(str(next_offset))
            offset = next_offset
        return {"items": items, "next_cursor": self._cursor(operation, query, offset),
                "complete": False, "scanned_records": scanned, "page_scan_limit_reached": True}

    def _embedding(self, text):
        if self.embed is None:
            raise AgentMemoryError("MEMORY_EMBEDDER_UNAVAILABLE")
        try:
            vector = self.embed(text)
            if not isinstance(vector, (list, tuple)) or not vector or any(type(v) not in (int, float) or not math.isfinite(v) for v in vector):
                raise ValueError()
            return [float(v) for v in vector]
        except AgentMemoryError:
            raise
        except Exception as exc:
            raise AgentMemoryError("MEMORY_EMBEDDING_FAILED", exception_type=type(exc).__name__) from exc

    def _search(self, args):
        from synaptic_sanitizer import sanitize_text
        items, offset, scanned, seen_ids = [], None, 0, set()
        seen_offsets = set()
        # Titles are stored separately from the body embedding. An exact title
        # is a deterministic lookup, so it precedes similarity suggestions.
        for _ in range(100):
            rows, next_offset = self.client.scroll(collection_name=self.collection,
                scroll_filter=self._filter({"title": args["query"]}), limit=30, offset=offset,
                with_payload=True, with_vectors=False)
            if not isinstance(rows, list):
                raise AgentMemoryError("INVALID_STORAGE_RESPONSE")
            scanned += len(rows)
            for point in rows:
                if (self._eligible(point.payload) and point.payload.get("title") == args["query"]
                        and str(point.id) not in seen_ids):
                    item = self._item(point)
                    item["matched_by"] = "exact_title"
                    items.append(item)
                    seen_ids.add(str(point.id))
                    if len(items) == args["limit"]:
                        return {"items": items, "search_complete": True, "scanned_records": scanned,
                                "exact_title_matches": len(items), "semantic_search": "not_needed"}
            if next_offset is None:
                break
            if next_offset == offset or str(next_offset) in seen_offsets:
                raise AgentMemoryError("PAGINATION_DID_NOT_ADVANCE")
            seen_offsets.add(str(next_offset))
            offset = next_offset
        exact_count = len(items)
        vector = self._embedding(sanitize_text(args["query"], "agent_memory.search").sanitized)
        offset = 0
        for _ in range(100):
            limit = max(30, args["limit"] - len(items))
            response = self.client.query_points(collection_name=self.collection, query=vector,
                query_filter=self._filter(), limit=limit, offset=offset, with_payload=True, with_vectors=False)
            rows = response.points
            if not isinstance(rows, list):
                raise AgentMemoryError("INVALID_STORAGE_RESPONSE")
            scanned += len(rows)
            for point in rows:
                if self._eligible(point.payload) and str(point.id) not in seen_ids:
                    item = self._item(point)
                    item["score"] = point.score
                    item["matched_by"] = "semantic"
                    items.append(item)
                    seen_ids.add(str(point.id))
                    if len(items) == args["limit"]:
                        return {"items": items, "search_complete": True, "scanned_records": scanned,
                                "exact_title_matches": exact_count, "semantic_search": "performed"}
            if len(rows) < limit:
                return {"items": items, "search_complete": True, "scanned_records": scanned,
                        "exact_title_matches": exact_count, "semantic_search": "performed"}
            offset += len(rows)
        return {"items": items, "search_complete": False, "scanned_records": scanned,
                "exact_title_matches": exact_count, "semantic_search": "performed",
                "search_scan_limit_reached": True, "continuation": "Use browse with query to continue across the complete permitted library."}

    def _admit(self, operation):
        if self.admission is not None:
            return self.admission(operation)
        from memory_control import operation_admission
        return operation_admission(operation)

    @staticmethod
    def _write_json(path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
        try:
            with temp.open("xb") as stream:
                stream.write(canonical_bytes(value))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, path)
        finally:
            if temp.exists():
                temp.unlink()

    def _intent(self, path, identity):
        """Permanent O_EXCL claim prevents differing retries across processes."""
        path.parent.mkdir(parents=True, exist_ok=True)
        new = {**identity, "created_at": datetime.now(timezone.utc).isoformat()}
        try:
            with path.open("xb") as stream:
                stream.write(canonical_bytes(new))
                stream.flush()
                os.fsync(stream.fileno())
            return new
        except FileExistsError:
            try:
                previous = json.loads(path.read_bytes())
            except Exception as exc:
                raise AgentMemoryError("OPERATION_INTENT_UNAVAILABLE") from exc
            if any(previous.get(k) != v for k, v in identity.items()):
                raise AgentMemoryError("IDEMPOTENCY_CONFLICT")
            return previous

    def _mutate(self, operation, args, operation_id, result):
        attempted = False
        operation_key = digest([self.namespace, operation_id])
        point_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "article11-agent-memory:" + operation_key))
        request_hash = digest([operation, args])
        directory = self.receipt_root / self.namespace
        identity = {"schema": "article11.agent-memory-intent.v1", "namespace": self.namespace,
                    "operation_id": operation_id, "operation": operation,
                    "request_sha256": request_hash, "id": point_id}
        try:
            with self._lock, self._admit("agent_memory." + operation + ":" + self.node_id):
                existing = self._raw_get(point_id)
                if existing is not None and self._owned(existing.payload) and existing.payload.get("record_kind") == "tombstone":
                    raise AgentMemoryError("NOTE_FORGOTTEN")
                if existing is not None and (not self._owned(existing.payload)
                        or existing.payload.get("request_sha256") != request_hash
                        or existing.payload.get("operation_id") != operation_id):
                    raise AgentMemoryError("IDEMPOTENCY_CONFLICT")
                predecessor = None
                if operation == "correct":
                    predecessor = self._get(args["id"])
                    if not self._owned(predecessor.payload) or predecessor.payload.get("record_kind") == "tombstone":
                        raise AgentMemoryError("CORRECTION_NOT_OWN_DELIBERATE_NOTE")
                try:
                    intent = self._intent(directory / (operation_key + ".intent.json"), identity)
                except AgentMemoryError:
                    raise
                except Exception as exc:
                    raise AgentMemoryError("OPERATION_INTENT_UNAVAILABLE", exception_type=type(exc).__name__) from exc
                payload = {"agent_memory_schema": NOTE_SCHEMA, "node_id": self.node_id, "user_id": self.user_id,
                    "attributed_to": self.node_id, "title": args["title"], "data": args["body"],
                    "text_lemmatized": args["body"], "kind": args["kind"], "sources": args["sources"],
                    "hash": _text_hash(args["body"]), "created_at": intent["created_at"], "updated_at": intent["created_at"],
                    "retrieval_status": "bridge_allowed", "eligibility": "owner_deliberate_nonratified",
                    "ratified": False, "authority": "context_only", "operation_id": operation_id,
                    "request_sha256": request_hash}
                if predecessor is not None:
                    payload.update(predecessor_id=str(predecessor.id), predecessor_payload_sha256=digest(predecessor.payload))
                if existing is not None and existing.payload != payload:
                    raise AgentMemoryError("IDEMPOTENCY_CONTENT_DRIFT")
                attempted, upsert_error = False, None
                if existing is None:
                    vector = self._embedding(args["body"])
                    from qdrant_client import models
                    point = models.PointStruct(id=point_id, vector=vector, payload=payload)
                    try:
                        attempted = True
                        self.client.upsert(collection_name=self.collection, points=[point], wait=True)
                    except Exception as exc:
                        upsert_error = type(exc).__name__
                try:
                    stored = self._raw_get(point_id)
                except Exception:
                    stored = None
                if stored is None or stored.payload != payload:
                    return {**result, "state": "partial", "storage_outcome": "write_outcome_unknown",
                            "persisted": None, "readback_verified": False, "receipt_saved": False,
                            "id": point_id, "request_sha256": request_hash, "write_attempted": attempted,
                            "upsert_error_type": upsert_error, "retry": "Reconcile using the same operation_id and exact arguments."}
                # The verified payload itself supplies the receipt; avoid another
                # dependency (e.g. a supersession query) after a committed write.
                result.update(storage_outcome="committed", persisted=True, readback_verified=True,
                              receipt_saved=True, id=point_id, request_sha256=request_hash,
                              idempotent_replay=existing is not None, write_attempted=attempted)
                result["items"] = [{"id": point_id, "title": args["title"], "content": args["body"],
                    "content_sha256": payload["hash"], "slice_sha256": payload["hash"],
                    "payload_sha256": digest(payload), "offset": 0, "next_offset": None,
                    "total_chars": len(args["body"]), "content_is_excerpt": False,
                    "ownership": "own_deliberate_note", "eligibility": "owner_deliberate_nonratified",
                    "authority": "context_only", "ratified": False, "kind": args["kind"],
                    "sources": args["sources"], "superseded_by": [],
                    **({"predecessor_id": payload["predecessor_id"], "predecessor_payload_sha256": payload["predecessor_payload_sha256"]} if predecessor else {})}]
                receipt = {k: v for k, v in result.items() if k != "items"}
                receipt["items"] = [{k: v for k, v in item.items() if k not in {"content", "title", "sources"}} for item in result["items"]]
                try:
                    self._write_json(directory / (operation_key + ".receipt.json"), receipt)
                except Exception as exc:
                    result.update(state="partial", storage_outcome="committed_receipt_failed", receipt_saved=False,
                                  receipt_error_type=type(exc).__name__)
                return result
        except AgentMemoryError as exc:
            if result.get("persisted") is True:
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed",
                        "admission_error_code": exc.code}
            exc.details.setdefault("storage_outcome", "write_outcome_unknown" if attempted else "not_attempted")
            raise
        except Exception as exc:
            if result.get("persisted") is True:
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed",
                        "admission_error_type": type(exc).__name__}
            code = getattr(exc, "code", "MEMORY_MUTATION_UNAVAILABLE")
            raise AgentMemoryError(code, exception_type=type(exc).__name__,
                                   storage_outcome="write_outcome_unknown" if attempted else "not_attempted") from exc

    @staticmethod
    def _zero_vector(vector):
        """Preserve actual dense dimensions, including a named dense vector map."""
        if isinstance(vector, list) and vector and all(type(v) in (int, float) and math.isfinite(v) for v in vector):
            return [0.0] * len(vector)
        if isinstance(vector, dict) and vector:
            return {key: AgentMemoryLibrary._zero_vector(value) for key, value in vector.items()}
        raise AgentMemoryError("FORGET_VECTOR_SHAPE_UNAVAILABLE")

    def _forget(self, args, operation_id, result):
        operation_key = digest([self.namespace, operation_id])
        point_id = args["id"]
        request_hash = digest(["forget", args])
        directory = self.receipt_root / self.namespace
        receipt_path = directory / (operation_key + ".receipt.json")
        attempted = False
        try:
            with self._lock, self._admit("agent_memory.forget:" + self.node_id):
                original = self._raw_get(point_id, with_vectors=True)
                if original is None or not self._owned(original.payload):
                    raise AgentMemoryError("NOT_FOUND")
                old = original.payload
                replay = old.get("record_kind") == "tombstone"
                if replay and (old.get("operation_id") != operation_id or old.get("request_sha256") != request_hash):
                    raise AgentMemoryError("NOTE_ALREADY_FORGOTTEN")
                zero = self._zero_vector(getattr(original, "vector", None))
                identity = {"schema": "article11.agent-memory-intent.v1", "namespace": self.namespace,
                            "operation_id": operation_id, "operation": "forget", "request_sha256": request_hash,
                            "id": str(point_id), "deleted_content_sha256": old["deleted_content_sha256"] if replay else digest(old)}
                intent = self._intent(directory / (operation_key + ".intent.json"), identity)
                if replay:
                    tombstone = old
                else:
                    tombstone = {"agent_memory_schema": NOTE_SCHEMA, "record_kind": "tombstone",
                        "node_id": self.node_id, "user_id": self.user_id, "attributed_to": self.node_id,
                        "eligibility": "owner_deliberate_nonratified", "retrieval_status": "bridge_allowed",
                        "ratified": False, "authority": "context_only", "operation_id": operation_id,
                        "request_sha256": request_hash, "deleted_content_sha256": digest(old),
                        "deleted_at": intent["created_at"], "deleted_by": self.node_id, "reason": args["reason"],
                        "supersession_links_preserved": True}
                    if old.get("predecessor_id"):
                        tombstone.update(predecessor_id=old["predecessor_id"],
                                         predecessor_payload_sha256=old["predecessor_payload_sha256"])
                if not replay or original.vector != zero:
                    from qdrant_client import models
                    attempted = True
                    try:
                        self.client.upsert(collection_name=self.collection,
                            points=[models.PointStruct(id=point_id, vector=zero, payload=tombstone)], wait=True)
                    except Exception:
                        # A transport exception does not prove that the deletion failed.
                        pass
                try:
                    stored = self._raw_get(point_id, with_vectors=True)
                    payload_ok = stored is not None and stored.payload == tombstone
                    vector_ok = stored is not None and stored.vector == zero
                except Exception:
                    payload_ok, vector_ok, stored = False, False, None
                if not payload_ok or not vector_ok:
                    return {**result, "state": "partial", "storage_outcome": "forget_outcome_unverified",
                            "persisted": None, "readback_verified": False, "receipt_saved": False,
                            "id": str(point_id), "tombstone_present": stored.payload.get("record_kind") == "tombstone" if stored is not None else None,
                            "content_removed": (stored.payload.get("record_kind") == "tombstone" and not
                                {"title", "data", "body", "memory", "text", "text_lemmatized", "sources"}.intersection(stored.payload)) if stored is not None else None,
                            "tombstone_verified": payload_ok if stored is not None else None,
                            "vector_zeroed": vector_ok if stored is not None else None,
                            "write_attempted": attempted, "retry": "Reconcile this id with the same operation_id and exact arguments."}
                result.update(storage_outcome="committed", persisted=True, readback_verified=True, receipt_saved=True,
                              id=str(point_id), request_sha256=request_hash, content_removed=True, vector_zeroed=True,
                              tombstone_present=True, tombstone_payload_sha256=digest(tombstone),
                              deleted_content_sha256=tombstone["deleted_content_sha256"],
                              retention_limits="Earlier correction versions, exports, backups and other existing copies remain. Hashes are commitments, not encryption; predictable text may be guessed. No grant system is present or revoked.")
                if replay and receipt_path.exists():
                    try:
                        previous = json.loads(receipt_path.read_bytes())
                    except (OSError, ValueError):
                        previous = {}
                    if (previous.get("operation_id") == operation_id and previous.get("request_sha256") == request_hash
                            and previous.get("tombstone_payload_sha256") == digest(tombstone)
                            and previous.get("state") == "ok"):
                        return previous
                # Build directly from the verified tombstone; no dependency on a
                # second query may hide a verified deletion behind a read error.
                content = _content(tombstone)
                result["items"] = [{"id": str(point_id), "record_kind": "tombstone", "title": "Forgotten note",
                    "content": content, "content_sha256": _text_hash(content), "slice_sha256": _text_hash(content),
                    "payload_sha256": digest(tombstone), "offset": 0, "next_offset": None,
                    "total_chars": len(content), "content_is_excerpt": False, "ownership": "own_tombstone",
                    "eligibility": "owner_deliberate_nonratified", "authority": "context_only", "ratified": False,
                    "deleted_content_sha256": tombstone["deleted_content_sha256"], "deleted_at": tombstone["deleted_at"],
                    "deleted_by": self.node_id, "deletion_reason": args["reason"], "content_removed": True,
                    **({"predecessor_id": tombstone["predecessor_id"], "predecessor_payload_sha256": tombstone["predecessor_payload_sha256"]} if tombstone.get("predecessor_id") else {})}]
                try:
                    self._write_json(receipt_path, result)
                except Exception as exc:
                    result.update(state="partial", storage_outcome="committed_receipt_failed", receipt_saved=False,
                                  receipt_error_type=type(exc).__name__)
                return result
        except AgentMemoryError as exc:
            if result.get("persisted") is True:
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed",
                        "admission_error_code": exc.code}
            exc.details.setdefault("storage_outcome", "forget_outcome_unverified" if attempted else "not_attempted")
            raise
        except Exception as exc:
            if result.get("persisted") is True:
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed",
                        "admission_error_type": type(exc).__name__}
            raise AgentMemoryError(getattr(exc, "code", "MEMORY_MUTATION_UNAVAILABLE"),
                                   storage_outcome="forget_outcome_unverified" if attempted else "not_attempted",
                                   exception_type=type(exc).__name__) from exc

    def _export(self, result):
        document = {"schema": "article11.agent-memory-export.v1", "visibility": "local_private",
                    "authority": "context_only", "node_id": self.node_id, "namespace_sha256": self.namespace,
                    "items": result["items"], "next_cursor": result["next_cursor"], "complete": result["complete"],
                    "sanitization": "Existing sanitizer applied; exported_payload_sha256 binds exported payload, payload_sha256 binds retained original."}
        exported = canonical_bytes(document)
        export_hash = digest(exported)
        path = self.receipt_root / self.namespace / "exports" / (export_hash + ".json")
        try:
            self._write_json(path, document)
            if path.read_bytes() != exported:
                raise OSError("export readback mismatch")
        except Exception as exc:
            raise AgentMemoryError("EXPORT_FILE_UNAVAILABLE", export_sha256=export_hash, exception_type=type(exc).__name__) from exc
        result.update(storage_outcome="local_private_export", export_path=str(path), export_sha256=export_hash,
                      export_bytes=len(exported), export_saved=True, export_document=document)
        return result
