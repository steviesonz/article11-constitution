"""INERT FIXTURE: no model, network, credentials, files or durable persistence."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agent_memory_dialogue import run_memory_dialogue


class InMemoryFixture:
    def __init__(self):
        content = "Ask before sharing another person's context."
        self.items = [{"id": "fixture-note-1", "content": content,
            "slice_sha256": hashlib.sha256(content.encode()).hexdigest(),
            "authority": "context_only", "fixture_only": True}]

    def execute(self, operation, arguments, operation_id):
        if operation not in {"read", "browse"}:
            raise ValueError("This deliberately small fixture implements read/browse only")
        if operation == "read" and arguments.get("id") != self.items[0]["id"]:
            raise ValueError("Unknown fixture record")
        return {"schema": "article11.agent-memory-result.v1", "state": "ok",
                "operation": operation, "operation_id": operation_id,
                "storage_outcome": "read_only", "persisted": False,
                "items": list(self.items), "next_cursor": None, "authority": "context_only"}


def scripted(*replies):
    responses = iter(replies)
    def chat(messages, response_schema):
        return {"content": json.dumps(next(responses)), "done_reason": "stop"}
    return chat


def main():
    library = InMemoryFixture()
    planned = {"choice": "accept", "actions": [{"operation": "browse", "arguments": {}}],
        "reply": "Scripted fixture action.", "done": False}
    final = {"choice": "accept", "actions": [], "reply": "The fixture supplied one note; nothing was saved to disk.", "done": True}
    first = run_memory_dialogue(messages=[{"role": "user", "content": "Demonstrate one chosen memory read."}],
        library=library, chat=scripted(planned, final), request_id="inert-first")
    browse = {"choice": "accept", "actions": [{"operation": "read", "arguments": {"id": "fixture-note-1"}}],
              "reply": "Read the same fixture in a fresh request.", "done": False}
    fresh = run_memory_dialogue(messages=[{"role": "user", "content": "What does the fixture contain?"}],
        library=library, chat=scripted(browse, {**final, "reply": "One fixture note is available in this process."}),
        request_id="inert-fresh")
    before = list(library.items)
    declined = run_memory_dialogue(messages=[{"role": "user", "content": "You can decline this demonstration."}],
        library=library, chat=scripted({"choice": "decline", "actions": [], "reply": "No thanks.", "done": True}),
        request_id="inert-decline")
    assert first["state"] == fresh["state"] == "completed"
    assert declined["state"] == "declined" and library.items == before
    print(json.dumps({"label": "INERT SCRIPTED DEMONSTRATION; NO REAL MODEL OR PERSISTENT STORE",
        "first_request": first["state"], "fresh_request": fresh["state"],
        "decline": declined["state"], "fixture_notes": len(library.items),
        "real_model_calls": 0, "network_calls": 0, "filesystem_writes": 0}, indent=2))


if __name__ == "__main__":
    main()
