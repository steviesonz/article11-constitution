"""Integration example. Importing/running this file calls no service.

Calling the factories is a separate deliberate host action against your existing
loopback services. Read ADAPTER_CONTRACT.md and supply your own privacy/admission.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def build_library(*, node_id, user_id, embedding_model, admission, receipt_root):
    # Fail at setup if the owner's privacy adapter is missing. No fallback.
    from synaptic_sanitizer import sanitize_text, sanitize_payload
    from qdrant_client import QdrantClient
    from ollama import Client
    from agent_memory_library import AgentMemoryLibrary
    if not callable(admission):
        raise TypeError("Supply the host's write-admission context manager")
    client = QdrantClient(url="http://127.0.0.1:6333", timeout=10)
    local = Client(host="http://127.0.0.1:11434", timeout=20)
    def embed(text):
        return local.embed(model=embedding_model, input=text)["embeddings"][0]
    return AgentMemoryLibrary(node_id, user_id, client=client, embed=embed,
                              admission=admission, receipt_root=receipt_root)


def build_chat(*, model):
    from ollama import Client
    from agent_memory_runtime import GENERATION_SCHEMA
    local = Client(host="http://127.0.0.1:11434", timeout=45)
    def chat(messages, response_schema):
        # The host still validates the full response_schema before dispatch.
        response = local.chat(model=model, messages=messages, format=GENERATION_SCHEMA,
                              options={"temperature": 0.2, "num_predict": 1400})
        return {"content": response["message"]["content"], "done_reason": response.get("done_reason")}
    return chat


if __name__ == "__main__":
    print("Adapter functions only. No services called. Read ADAPTER_CONTRACT.md before importing these factories.")
