#!/usr/bin/env python3
"""Check this extracted bundle locally; no network, writes or model calls."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

CORE = 'src/spiralmesh/continuity/constitution-v2.0-core.md'
CORE_BYTES = 45649
CORE_SHA = '7e6d12e1025a46cc3a860d6147d79e2362c4d88cb727ce9423854b5008be4c82'
FILES = ['LICENSE', 'LICENSE-CONSTITUTION.txt', 'OPEN_CLAUDE_MEMORY.cmd', 'OPEN_CODEX_MEMORY.cmd', 'START_HERE.md', 'docs/CONTINUITY_QUICKSTART.md', 'src/spiralmesh/__init__.py', 'src/spiralmesh/continuity/__init__.py', 'src/spiralmesh/continuity/cli.py', 'src/spiralmesh/continuity/codex_transport.py', 'src/spiralmesh/continuity/constitution-v2.0-core.md', 'src/spiralmesh/continuity/mcp.py', 'src/spiralmesh/continuity/runner.py', 'src/spiralmesh/continuity/store.py', 'tests/test_continuity.py', 'tests/test_continuity_codex_transport.py', 'tests/test_continuity_mcp.py', 'tests/test_continuity_resume.py', 'tests/test_continuity_resume_launcher.py', 'tests/test_continuity_runner.py', 'tests/test_open_memory_status.py', 'tools/open_memory.py', 'verify_bundle.py']


def safe_name(name):
    return (isinstance(name, str) and name and "\\" not in name and ":" not in name
            and not PurePosixPath(name).is_absolute()
            and all(p not in ("", ".", "..") for p in name.split("/")))


def main():
    base = Path(__file__).resolve().parent
    errors = []
    checked = 0
    try:
        manifest_path = base / "manifest.json"
        manifest_attrs = manifest_path.lstat()
        if (not stat.S_ISREG(manifest_attrs.st_mode) or manifest_path.is_symlink()
                or getattr(manifest_attrs, "st_file_attributes", 0) & 0x400):
            raise ValueError("UNSAFE_MANIFEST")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("schema") != "spiralmesh.continuity.bundle.v1":
            raise ValueError("INVALID_MANIFEST_SCHEMA")
        entries = manifest["files"]
        if not isinstance(entries, list):
            raise ValueError("INVALID_MANIFEST_FILES")
        rows = {}
        for row in entries:
            name = row["path"]
            if not safe_name(name) or name in rows:
                raise ValueError("UNSAFE_OR_DUPLICATE_PATH")
            if type(row["bytes"]) is not int or row["bytes"] < 0 or not isinstance(row["sha256"], str):
                raise ValueError("INVALID_MANIFEST_ENTRY")
            rows[name] = row
        if set(rows) != set(FILES):
            raise ValueError("MANIFEST_ALLOWLIST_MISMATCH")
        present = set()
        allowed_dirs = {parent.as_posix() for name in FILES
                        for parent in PurePosixPath(name).parents if parent.as_posix() != "."}
        for current, directories, filenames in os.walk(base, followlinks=False):
            here = Path(current)
            for name in list(directories):
                p = here / name
                attrs = p.lstat()
                if p.is_symlink() or getattr(attrs, "st_file_attributes", 0) & 0x400:
                    errors.append({"path": p.relative_to(base).as_posix(), "error": "LINK_OR_REPARSE_REFUSED"})
                    directories.remove(name)
                elif p.relative_to(base).as_posix() not in allowed_dirs:
                    errors.append({"path": p.relative_to(base).as_posix(), "error": "UNEXPECTED_DIRECTORY"})
                    directories.remove(name)
            for name in filenames:
                p = here / name
                rel = p.relative_to(base).as_posix()
                attrs = p.lstat()
                if not stat.S_ISREG(attrs.st_mode) or p.is_symlink() or getattr(attrs, "st_file_attributes", 0) & 0x400:
                    errors.append({"path": rel, "error": "NON_REGULAR_FILE_REFUSED"})
                    continue
                present.add(rel)
        for name in sorted(present - set(FILES) - {"manifest.json"}):
            errors.append({"path": name, "error": "UNEXPECTED_FILE"})
        for name in FILES:
            if name not in present:
                errors.append({"path": name, "error": "MISSING_OR_UNSAFE_FILE"})
                continue
            raw = (base / name).read_bytes()
            actual = hashlib.sha256(raw).hexdigest()
            if len(raw) != rows[name]["bytes"] or actual != rows[name]["sha256"]:
                errors.append({"path": name, "error": "CONTENT_MISMATCH"})
            if name == CORE and (len(raw) != CORE_BYTES or actual != CORE_SHA):
                errors.append({"path": name, "error": "CORE_PIN_MISMATCH"})
            checked += 1
    except (OSError, ValueError, KeyError, TypeError):
        errors.append({"error": "INVALID_OR_UNREADABLE_BUNDLE"})
    result = {"ok": not errors, "status": "VERIFIED" if not errors else "FAILED",
              "files_checked": checked, "core_sha256": CORE_SHA,
              "network_used": False, "identity_authenticated": False, "errors": errors}
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
