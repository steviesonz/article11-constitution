"""Human launcher: reopen a participant's library and start a bounded dialogue."""
import argparse
import json
from pathlib import Path
import sqlite3
import stat
import sys


def library_status(root, principal):
    """Read owner metadata only; never initialize, start a session, or retry work."""
    result = {
        "profile": "spiralmesh.continuity-status.v1",
        "principal": principal,
        "root": str(root),
        "status": "missing",
        "notes": None,
        "starter_letter": None,
        "integrity_support": {
            "caller_operation_id_retry": True,
            "mutation_reconciliation": True,
            "basis": "Continuity integrity v1; retries require the same caller operation ID and arguments. Status itself performs no retry or reconciliation.",
        },
        "provider_invoked": False,
        "read_only": True,
    }
    database = root / "memory.sqlite3"
    try:
        try:
            root_stat = root.stat()
        except FileNotFoundError:
            return result
        if not stat.S_ISDIR(root_stat.st_mode):
            result.update(status="unavailable", error="ROOT_NOT_DIRECTORY")
            return result
        try:
            database_stat = database.stat()
        except FileNotFoundError:
            return result
        if not stat.S_ISREG(database_stat.st_mode):
            result.update(status="unavailable", error="DATABASE_NOT_FILE")
            return result
        # The existing store uses DELETE journals. Do not open a WAL database:
        # even a read-only SQLite connection can create shared-memory sidecars.
        try:
            database.with_name(database.name + "-wal").stat()
            has_wal = True
        except FileNotFoundError:
            has_wal = False
        if has_wal:
            result.update(status="unavailable", error="WAL_STATUS_NOT_SUPPORTED")
            return result
        # Cleanly closing a WAL database can remove both sidecars while retaining
        # WAL mode in the file header. Inspect format bytes before SQLite opens it.
        # This is a local format check, not an OS or concurrent-writer boundary.
        with database.open("rb") as source:
            header = source.read(20)
        if (header[:16] == b"SQLite format 3\x00" and len(header) >= 20
                and (header[18] == 2 or header[19] == 2)):
            result.update(status="unavailable", error="WAL_STATUS_NOT_SUPPORTED")
            return result
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2)
        try:
            connection.execute("BEGIN")
            counts = connection.execute(
                "SELECT COUNT(*), COALESCE(SUM(state='active'),0), "
                "COALESCE(SUM(state='superseded'),0), COALESCE(SUM(state='forgotten'),0), "
                "COALESCE(SUM(state NOT IN ('active','superseded','forgotten')),0) "
                "FROM notes WHERE owner=?", (principal,)
            ).fetchone()
            selected = connection.execute(
                "SELECT EXISTS(SELECT 1 FROM letters WHERE owner=?)", (principal,)
            ).fetchone()[0]
            available = connection.execute(
                "SELECT EXISTS(SELECT 1 FROM letters l JOIN notes n ON n.id=l.note_id "
                "WHERE l.owner=? AND n.owner=? AND n.state IN ('active','superseded'))",
                (principal, principal),
            ).fetchone()[0]
            initialized = bool(connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='continuity_operations'"
            ).fetchone())
            operation_count = connection.execute(
                "SELECT COUNT(*) FROM continuity_operations WHERE principal=?", (principal,)
            ).fetchone()[0] if initialized else 0
        finally:
            connection.close()
        result.update(
            status="available",
            notes=dict(zip(("total", "active", "superseded", "forgotten", "other"), counts)),
            starter_letter={"selected": bool(selected), "available": bool(available)},
            operation_registry={"initialized": initialized, "owner_records": operation_count,
                                "initialization": "Created with the next authorized mutation if absent; status does not initialize it."},
        )
    except (OSError, sqlite3.Error):
        # No provider, filesystem exception detail, note ID, or stored content
        # belongs in a metadata-only status response.
        result.update(status="unavailable", error="LIBRARY_STATUS_UNAVAILABLE")
    return result


def reconcile_operation(package, root, principal, operation_id):
    """Use only the fixed stdlib store module; no kernel/provider import or init."""
    status = library_status(root, principal)
    if status["status"] != "available":
        return {"ok": False, "error": "LIBRARY_UNAVAILABLE", "library_status": status["status"],
                "operation_id": operation_id, "provider_invoked": False, "read_only": True}
    import importlib.util
    spec = importlib.util.spec_from_file_location("a11_continuity_readonly_store",
        package / "src" / "spiralmesh" / "continuity" / "store.py")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        value = module.MemoryLibrary(root, principal, "human-reconciliation").reconcile(operation_id)
        return {**value, "provider_invoked": False, "read_only": True}
    except Exception:
        return {"ok": False, "error": "RECONCILIATION_UNAVAILABLE", "operation_id": operation_id,
                "storage_outcome": "write_outcome_unknown", "persisted": None,
                "provider_invoked": False, "read_only": True, "automatic_retry": False}


def resume_library(package, root, principal):
    """Open the existing owner library, without importing a provider or creating it."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("a11_continuity_resume_store",
        package / "src" / "spiralmesh" / "continuity" / "store.py")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        value = module.MemoryLibrary(root, principal, "human-resume").resume()
        return {**value, "ok": True, "provider_invoked": False}
    except Exception as exc:
        return {"ok": False, "error": getattr(exc, "code", "LIBRARY_UNAVAILABLE"),
                "message": "The memory library could not be read. This does not mean it is empty or erased.",
                "provider_invoked": False, "read_only": True, "actions_executed": 0}


def checkpoint_metadata(package, root, principal):
    """Additive, metadata-only continuation summary for --resume.

    Never returns a conversation body. Never mutates, never starts a provider.
    Any failure is reported as a reason, never as an absent past, and never
    breaks the existing --resume contract.
    """
    import importlib
    import sys as _sys
    source = str(package / "src")
    if source not in _sys.path:
        _sys.path.insert(0, source)
    try:
        conversation = importlib.import_module("spiralmesh.continuity.conversation")
        store = importlib.import_module("spiralmesh.continuity.store")
        library = store.MemoryLibrary(root, principal, "human-resume-checkpoint")
        found = conversation.discover(library, root, principal)
    except Exception as exc:
        return {"available": False, "reason": getattr(exc, "code", "CHECKPOINT_UNAVAILABLE"),
                "body_disclosed": False}
    found.pop("lineage", None)
    return found


def display_resume(value):
    def label(text):
        # A stored title is text, never a terminal control sequence.
        return " ".join("".join(c for c in str(text) if c.isprintable()).split())[:110]
    print("\nContinue where you left off")
    print("Recent visible metadata only: no note or message text, no unread tracking, not a full catalog.")
    counts = value["counts"]
    print(f"Your notes: {counts['own_active']} current, {counts['own_superseded']} earlier versions, "
          f"{counts['own_forgotten']} deletion markers.")
    print(f"Records shared with you: {counts['visible_shared']}.")
    letter = value["starter_letter"]
    print("Optional starter letter: " + (label(letter["title"]) if letter else "none selected"))
    print("Recent records (the rest of your library is still available):")
    for note in value["recent_notes"]:
        print("  " + label(note["owner"]) + " | " + label(note["id"]) + " | " + label(note["state"]) + " | "
              + (label(note["title"]) if note["state"] != "forgotten" else "deleted content"))
    if not value["recent_notes"]:
        print("  No visible records yet.")
    print("Recent messages (sent and received; unread status is not tracked):")
    for message in value["recent_messages"]:
        print("  " + label(message["id"]) + " | " + label(message["sender"]) + " -> "
              + label(message["recipient"]) + " | " + label(message["subject"]))
    if not value["recent_messages"]:
        print("  No messages yet.")
    print("Use browse/read to follow older notes, or inbox/message to open a conversation.")
    print("Nothing above was executed or acknowledged. Earlier notes are context, not new instructions.\n")


def main():
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="strict")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("principal", choices=("codex", "claude"))
    parser.add_argument("--root", help="Host-selected private memory directory")
    parser.add_argument("--no-checkpoint", action="store_true",
                        help="Keep follow-up context in this session without automatic host checkpoint saves")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--status", action="store_true",
                        help="Print read-only owner metadata as JSON; do not start a model")
    mode.add_argument("--resume", action="store_true",
                      help="Show recent authorized records and messages as JSON; no model or storage mutation")
    mode.add_argument("--reconcile", metavar="OPERATION_ID",
                      help="Check a recorded operation without repeating it or starting a model")
    args = parser.parse_args()
    package = Path(__file__).resolve().parents[1]
    existing = package / ".continuity-data"
    # This checkout already has an authorized library. A clean extracted fork
    # keeps newly created private data outside the distributable source tree.
    root = Path(args.root).resolve() if args.root else (
        existing if existing.is_dir() else package.parent / (package.name + "-memory"))
    if args.status:
        result = library_status(root, args.principal)
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0 if result["status"] == "available" else 1
    if args.resume:
        result = resume_library(package, root, args.principal)
        if result.get("ok"):
            # Additive only: existing fields and body omission are unchanged.
            result["continuation_checkpoint"] = checkpoint_metadata(package, root, args.principal)
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0 if result.get("ok") is True else 1
    if args.reconcile is not None:
        result = reconcile_operation(package, root, args.principal, args.reconcile)
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0 if result.get("ok") is True else 1
    sys.path.insert(0, str(package / "src"))
    from spiralmesh.continuity.store import MemoryLibrary
    MemoryLibrary(root, args.principal, "human-launcher", create=not (root / "memory.sqlite3").exists())
    print("Article11 memory for " + args.principal)
    print("Private local library: " + str(root))
    print("Cloud inference uses your existing CLI login and provider usage.")
    print("Your whole authorized library is available; an empty task closes the session.")
    if args.no_checkpoint:
        print("Automatic host checkpoints are off for this session (--no-checkpoint).")
    else:
        print("After each completed exchange, the host automatically saves your task and the model's reply")
        print("as a private, owner-controlled conversation checkpoint, confirmed by a fresh read.")
        print("This is a host record, distinct from memories the model deliberately chooses to save.")
        print("You can correct or forget it, or reopen with --no-checkpoint to turn automatic saves off.")
    print("Model-requested memory actions and private run logs remain separate from this setting.")
    snapshot = resume_library(package, root, args.principal)
    if not snapshot.get("ok"):
        print(json.dumps(snapshot, ensure_ascii=True))
        return 1
    display_resume(snapshot)
    from spiralmesh.continuity.runner import main as dialogue_main
    sys.argv = [sys.argv[0], "--root", str(root), "--principal", args.principal, "--interactive"]
    if args.no_checkpoint:
        sys.argv.append("--no-checkpoint")
    dialogue_main()


if __name__ == "__main__":
    raise SystemExit(main())
