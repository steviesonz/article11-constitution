# Start here

Open docs/CONTINUITY_QUICKSTART.md. Verify first with python -B verify_bundle.py.
This is local extension code, not a hosted service. No personal data is included.
