"""Conversation checkpoint tests: synthetic temporary libraries only.

No real participant library, no provider, no network, no subprocess to a model.
Every root here is a fresh tempfile directory; `.continuity-data` is never opened.
"""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from spiralmesh.continuity import conversation
from spiralmesh.continuity.store import MemoryError, MemoryLibrary


CANARY = "SYNTHETIC-CANARY-4f2a9c"


def exchange(human="What did we choose?", reply="We chose the blue path.", status="completed"):
    return conversation.make_exchange(human, reply, status=status)


class ConversationCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="spiralmesh-conversation-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "memory"
        self.library = MemoryLibrary(self.root, "claude", "setup", create=True)

    def save(self, exchanges=None, **kwargs):
        return conversation.save_checkpoint(
            self.library, self.root, "claude", "conv_test", exchanges or [exchange()], **kwargs)

    # ---------------------------------------------------------------- saving

    def test_save_is_only_called_saved_after_a_verified_fresh_read(self):
        status = self.save()
        self.assertTrue(status["saved"])
        self.assertTrue(status["readback_verified"])
        stored = self.library.read(status["note_id"])
        self.assertEqual(stored["kind"], "journal")
        self.assertEqual(stored["content_sha256"], status["content_sha256"])
        document = json.loads(stored["body"])
        self.assertEqual(document["origin"], "host_retained_conversation_record")
        self.assertIn("did not choose to write this record", document["origin_note"])
        self.assertEqual(document["authority"], "context_only")
        self.assertFalse(document["is_recall_boundary"])

    def test_body_carries_no_actions_results_or_logs(self):
        status = self.save()
        body = self.library.read(status["note_id"])["body"]
        for forbidden in ("actions", "arguments_json", "bind", "operation_results",
                          "stdout", "stderr", "prompt.txt"):
            self.assertNotIn(forbidden, body)

    def test_uncertain_save_reports_the_id_and_does_not_write_again_or_publish(self):
        with patch.object(MemoryLibrary, "remember",
                          return_value={"ok": False, "storage_outcome": "unknown",
                                        "operation_id": "op_x"}):
            status = self.save()
        self.assertFalse(status["saved"])
        self.assertFalse(status["pointer_published"])
        self.assertFalse(status["automatic_retry"])
        self.assertTrue(status["reconcile_operation_id"])
        self.assertIsNone(conversation.read_pointer(self.root, "claude"))

    def test_readback_failure_is_not_promoted_to_a_usable_shortcut(self):
        with patch.object(MemoryLibrary, "read", side_effect=MemoryError("NOT_FOUND")):
            status = self.save()
        self.assertFalse(status["saved"])
        self.assertFalse(status["pointer_published"])
        self.assertIsNone(conversation.read_pointer(self.root, "claude"))

    def test_confirmed_note_with_failed_pointer_reports_shortcut_unavailable_only(self):
        with patch.object(conversation, "write_pointer", side_effect=OSError("disk")):
            status = self.save()
        self.assertTrue(status["saved"])          # the note really is saved
        self.assertFalse(status["pointer_published"])
        self.assertEqual(status["message"], "note saved; continuation shortcut unavailable")
        # exactly one note was written; the failure did not cause a second write
        rows = [r for r in self.library.browse(limit=50)["records"] if r["kind"] == "journal"]
        self.assertEqual(len(rows), 1)

    def test_declining_or_failed_exchanges_are_never_offered_as_checkpoints(self):
        with self.assertRaises(MemoryError):
            conversation.build_body("claude", "conv_test", [])

    # ---------------------------------------------------------------- context budget

    def test_over_budget_window_is_explicitly_partial_and_never_mid_truncated(self):
        many = [exchange("Question %d %s" % (i, "é中文" * 200), "Reply %d" % i)
                for i in range(12)]
        body, document = conversation.build_body("claude", "conv_test", many, budget=4000)
        self.assertFalse(document["window_complete"])
        self.assertGreater(document["earlier_exchanges_omitted"], 0)
        self.assertIn("PARTIAL", document["window_note"])
        json.loads(body)  # still valid JSON, not a severed string
        for kept in document["exchanges"]:
            self.assertIn(kept, many)  # whole exchanges only

    def test_unicode_survives_the_round_trip(self):
        text = "中文 éàü \U0001F300 " + CANARY
        status = self.save([exchange(text, text)])
        document = json.loads(self.library.read(status["note_id"])["body"])
        self.assertEqual(document["exchanges"][0]["human"], text)

    def test_control_characters_in_a_title_cannot_reach_the_console(self):
        self.assertEqual(conversation.safe_label("ab\r\nc[31m"), "abc[31m")

    # ---------------------------------------------------------------- lineage

    def test_correction_resolves_forward_to_the_current_body(self):
        status = self.save([exchange("First", "Original reply")])
        corrected = self.library.correct(status["note_id"], "Conversation checkpoint conv_test",
                                         conversation.build_body(
                                             "claude", "conv_test",
                                             [exchange("First", "CORRECTED reply")])[0],
                                         kind="journal")
        document, record, lineage = conversation.load_checkpoint(
            self.library, status["note_id"], principal="claude")
        self.assertTrue(lineage["corrected"])
        self.assertEqual(record["id"], corrected["note_id"])
        self.assertEqual(document["exchanges"][0]["model_reply"], "CORRECTED reply")

    def test_multi_step_lineage_resolves_and_a_cycle_or_fork_refuses(self):
        status = self.save([exchange("a", "v1")])
        current = status["note_id"]
        for version in ("v2", "v3"):
            body = conversation.build_body("claude", "conv_test", [exchange("a", version)])[0]
            current = self.library.correct(current, "Conversation checkpoint conv_test",
                                           body, kind="journal")["note_id"]
        document, record, lineage = conversation.load_checkpoint(
            self.library, status["note_id"], principal="claude")
        self.assertEqual(document["exchanges"][0]["model_reply"], "v3")
        self.assertEqual(len(lineage["lineage_steps"]), 2)

        with patch.object(MemoryLibrary, "successors", return_value=["a", "b"]):
            with self.assertRaises(MemoryError) as caught:
                conversation.load_checkpoint(self.library, status["note_id"], principal="claude")
            self.assertEqual(str(caught.exception), "CHECKPOINT_LINEAGE_AMBIGUOUS")
        with patch.object(MemoryLibrary, "successors", return_value=[]):
            with self.assertRaises(MemoryError) as caught:
                conversation.load_checkpoint(self.library, status["note_id"], principal="claude")
            self.assertEqual(str(caught.exception), "CHECKPOINT_LINEAGE_BROKEN")

    def test_malformed_corrected_body_refuses_rather_than_using_the_old_one(self):
        status = self.save([exchange("a", "good")])
        self.library.correct(status["note_id"], "Conversation checkpoint conv_test",
                             "not json at all", kind="journal")
        with self.assertRaises(MemoryError):
            conversation.load_checkpoint(self.library, status["note_id"], principal="claude")

    # ---------------------------------------------------------------- forgetting

    def test_forgotten_checkpoint_refuses_and_leaks_no_canary(self):
        status = self.save([exchange("secret " + CANARY, "reply " + CANARY)])
        self.library.forget(status["note_id"])
        with self.assertRaises(MemoryError) as caught:
            conversation.load_checkpoint(self.library, status["note_id"], principal="claude")
        self.assertEqual(str(caught.exception), "CHECKPOINT_FORGOTTEN")
        found = conversation.discover(self.library, self.root, "claude")
        self.assertFalse(found["available"])
        self.assertNotIn(CANARY, json.dumps(found))

    # ---------------------------------------------------------------- owner isolation

    def test_each_principal_sees_only_its_own_checkpoint(self):
        self.save([exchange("claude side", "claude reply")])
        codex = MemoryLibrary(self.root, "codex", "setup-codex", create=True)
        conversation.save_checkpoint(codex, self.root, "codex", "conv_codex",
                                     [exchange("codex side", "codex reply")])
        mine = conversation.discover(self.library, self.root, "claude")
        theirs = conversation.discover(codex, self.root, "codex")
        self.assertTrue(mine["available"] and theirs["available"])
        self.assertNotEqual(mine["note_id"], theirs["note_id"])
        self.assertEqual(mine["conversation_id"], "conv_test")
        self.assertEqual(theirs["conversation_id"], "conv_codex")

    def test_a_shared_peer_note_is_not_an_owned_checkpoint(self):
        codex = MemoryLibrary(self.root, "codex", "setup-codex", create=True)
        theirs = conversation.save_checkpoint(codex, self.root, "codex", "conv_codex",
                                              [exchange("theirs", "theirs")])
        codex.share(theirs["note_id"], "claude")
        # ordinary shared recall still works
        self.assertTrue(self.library.read(theirs["note_id"])["body"])
        # but it is not a continuation checkpoint for claude
        with self.assertRaises(MemoryError) as caught:
            conversation.load_checkpoint(self.library, theirs["note_id"], principal="claude")
        self.assertEqual(str(caught.exception), "CHECKPOINT_NOT_OWNED")

    def test_pointer_from_another_root_or_owner_refuses(self):
        status = self.save()
        entry = conversation.read_pointer(self.root, "claude")
        self.assertEqual(entry["note_id"], status["note_id"])

        moved = dict(entry, library_root=str(Path(self.temp.name) / "elsewhere"))
        raw = json.loads(conversation.pointer_path(self.root).read_text(encoding="utf-8"))
        raw["participants"]["claude"] = moved
        conversation.pointer_path(self.root).write_text(json.dumps(raw), encoding="utf-8")
        self.assertEqual(conversation.read_pointer(self.root, "claude")["reason"],
                         "POINTER_ROOT_MISMATCH")

        swapped = dict(entry, principal="codex")
        raw["participants"]["claude"] = swapped
        conversation.pointer_path(self.root).write_text(json.dumps(raw), encoding="utf-8")
        self.assertEqual(conversation.read_pointer(self.root, "claude")["reason"],
                         "POINTER_PRINCIPAL_MISMATCH")

    def test_pointer_holds_references_not_a_second_copy_of_the_body(self):
        self.save([exchange("body text " + CANARY, "reply " + CANARY)])
        raw = conversation.pointer_path(self.root).read_text(encoding="utf-8")
        self.assertNotIn(CANARY, raw)
        self.assertIn('"body_included":false', raw.replace(" ", ""))

    # ---------------------------------------------------------------- discovery

    def test_discovery_is_metadata_only_and_mutates_nothing(self):
        self.save([exchange("hidden " + CANARY, "hidden " + CANARY)])
        before = self.library.path.read_bytes()
        found = conversation.discover(self.library, self.root, "claude")
        self.assertTrue(found["available"])
        self.assertFalse(found["body_disclosed"])
        self.assertNotIn(CANARY, json.dumps(found))
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_missing_checkpoint_is_not_called_an_empty_past(self):
        found = conversation.discover(self.library, self.root, "claude")
        self.assertFalse(found["available"])
        self.assertEqual(found["reason"], "NO_CHECKPOINT_RECORDED")
        self.assertFalse(conversation.pointer_path(self.root).exists())

    def test_corrupt_pointer_is_an_error_not_an_absence(self):
        conversation.pointer_path(self.root).write_text("{oops", encoding="utf-8")
        found = conversation.discover(self.library, self.root, "claude")
        self.assertFalse(found["available"])
        self.assertEqual(found["reason"], "POINTER_MALFORMED")
        self.assertIn("not an empty past", found["note"])


    # ---------------------------------------------------------------- repaired binding and limits

    def test_digest_is_recomputed_over_all_four_content_fields(self):
        saved = self.save()
        original = self.library.read(saved["note_id"])
        changes = {
            "title": "Unbound title", "sources": ["unbound source"],
            "body": conversation.build_body("claude", "conv_test",
                                               [exchange("Changed", "Changed")])[0],
        }
        for field, value in changes.items():
            with self.subTest(field=field):
                changed = dict(original, **{field: value})
                with patch.object(MemoryLibrary, "read", return_value=changed):
                    with self.assertRaisesRegex(MemoryError, "CHECKPOINT_DIGEST_MISMATCH"):
                        conversation.load_checkpoint(self.library, saved["note_id"], principal="claude")

    def test_save_readback_does_not_trust_a_stale_declared_digest(self):
        real_read = self.library.read

        def altered(note_id):
            record = real_read(note_id)
            record["body"] = conversation.build_body("claude", "conv_test",
                                                       [exchange("unbound", "body")])[0]
            return record

        with patch.object(self.library, "read", side_effect=altered):
            status = self.save()
        self.assertFalse(status["saved"])
        self.assertFalse(status["pointer_published"])
        self.assertTrue(status["reconcile_operation_id"])

    def test_save_requires_explicit_committed_persisted_readback_proof(self):
        good = {"ok": True, "persisted": True, "readback_verified": True,
                "storage_outcome": "committed", "note_id": "synthetic-note"}
        for field, value in (("ok", 1), ("persisted", "true"), ("readback_verified", None),
                             ("storage_outcome", "unknown"), ("note_id", 12)):
            with self.subTest(field=field):
                with patch.object(self.library, "remember", return_value=dict(good, **{field: value})) as write:
                    with patch.object(self.library, "read") as read:
                        status = self.save()
                self.assertFalse(status["saved"])
                self.assertFalse(status["pointer_published"])
                write.assert_called_once()
                read.assert_not_called()
        self.assertIsNone(conversation.read_pointer(self.root, "claude"))

    def test_partial_omissions_survive_two_resumes_and_save(self):
        turns = [exchange(str(i), "r" * 4) for i in range(5)]
        _, first = conversation.build_body("claude", "conv_test", turns, budget=10)
        self.assertEqual(first["earlier_exchanges_omitted"], 3)
        kept, omitted = conversation.select_window(first["exchanges"] + [exchange("5", "rrrr")],
                                                   budget=10, earlier_omitted=3)
        self.assertEqual(omitted, 4)
        status = self.save(kept, budget=10, earlier_omitted=omitted)
        self.assertTrue(status["saved"])
        self.assertFalse(status["window_complete"])
        doc, _, _ = conversation.load_checkpoint(self.library, status["note_id"], principal="claude")
        self.assertEqual(doc["earlier_exchanges_omitted"], 4)
        self.assertEqual(doc["exchanges"], turns[-1:] + [exchange("5", "rrrr")])

    def test_newest_oversized_exchange_refuses_before_any_effect(self):
        for turns in ([exchange("x" * 25_000, "")],
                      [exchange("small", "reply"), exchange("x", "y" * 24_000)]):
            with self.subTest(turns=len(turns)):
                with patch.object(self.library, "remember") as write:
                    with self.assertRaisesRegex(MemoryError, "CHECKPOINT_EXCHANGE_EXCEEDS_BUDGET"):
                        self.save(turns)
                write.assert_not_called()
        self.assertFalse(conversation.pointer_path(self.root).exists())

    def test_window_retains_contiguous_whole_exchanges_and_maximum_count(self):
        turns = [exchange("a", "b"), exchange("older-too-large", ""), exchange("c", "d")]
        kept, omitted = conversation.select_window(turns, budget=4, earlier_omitted=7)
        self.assertEqual(kept, turns[-1:])
        self.assertEqual(omitted, 9)
        kept, omitted = conversation.select_window([exchange(str(i), "x") for i in range(44)])
        self.assertEqual(len(kept), 40)
        self.assertEqual(omitted, 4)

    def test_window_parameters_are_finite_integers(self):
        for value in (True, 0, -1, 4.0, float("inf"), "4000", None):
            with self.subTest(budget=value):
                with self.assertRaisesRegex(MemoryError, "INVALID_CHECKPOINT_BUDGET"):
                    conversation.select_window([exchange()], budget=value)
        for value in (True, -1, 1.0, None):
            with self.subTest(earlier_omitted=value):
                with self.assertRaisesRegex(MemoryError, "INVALID_EARLIER_OMITTED"):
                    conversation.select_window([exchange()], earlier_omitted=value)

    def test_exchange_schema_rejects_actions_even_in_an_omitted_turn(self):
        invalid = [dict(exchange(), actions=[]), dict(exchange(), prior_operation_ids="op_x"),
                   dict(exchange(), prior_operation_ids=[1]),
                   dict(exchange(), prior_operation_ids=["op_x"] * 13),
                   dict(exchange(), model_reply=None), dict(exchange(), host_run_status={}),
                   dict(exchange(), human=" ")]
        for value in invalid:
            with self.subTest(value=value):
                with self.assertRaises(MemoryError):
                    conversation.select_window([value, exchange("q", "a")], budget=2)

    def test_checkpoint_schema_rejects_extra_fields_counts_and_context_changes(self):
        _, good = conversation.build_body("claude", "conv_test", [exchange("q", "a")])
        mutations = [("actions", []), ("exchange_count", True), ("exchange_count", 2),
                     ("window_complete", 1), ("window_complete", False),
                     ("earlier_exchanges_omitted", -1), ("earlier_exchanges_omitted", True),
                     ("authority", "execute"), ("is_recall_boundary", 0),
                     ("origin_note", "model-authored"), ("identity_claim", "same instance"),
                     ("replay_semantics", "retry"), ("budget_chars", 1),
                     ("window_note", "not actually partial"), ("conversation_id", 1)]
        for field, value in mutations:
            with self.subTest(field=field, value=value):
                document = dict(good, **{field: value})
                with self.assertRaises(MemoryError):
                    conversation.parse_body(json.dumps(document), principal="claude")
        for document in (dict(good, exchanges=[dict(good["exchanges"][0], actions=[])]),
                         dict(good, exchanges=good["exchanges"] * 41, exchange_count=41)):
            with self.assertRaises(MemoryError):
                conversation.parse_body(json.dumps(document), principal="claude")

    def test_partial_marker_and_duplicate_json_keys_are_checked(self):
        body, partial = conversation.build_body("claude", "conv_test", [exchange()], earlier_omitted=2)
        self.assertEqual(conversation.parse_body(body, principal="claude"), partial)
        for value in (None, "Everything included"):
            changed = dict(partial)
            if value is None:
                del changed["window_note"]
            else:
                changed["window_note"] = value
            with self.assertRaises(MemoryError):
                conversation.parse_body(json.dumps(changed), principal="claude")
        for body in ('{"profile":"a","profile":"b"}', '{"budget_chars":NaN}'):
            with self.assertRaisesRegex(MemoryError, "CHECKPOINT_BODY_MALFORMED"):
                conversation.parse_body(body, principal="claude")

    def test_malformed_pointer_shapes_are_never_missing_history(self):
        self.save()
        path = conversation.pointer_path(self.root)
        good = json.loads(path.read_text(encoding="utf-8"))
        malformed = []
        for value in ([], None, "claude"):
            malformed.append(dict(good, participants=value))
        for value in ([], None, {}):
            malformed.append(dict(good, participants={"claude": value}))
        for field, value in (("exchange_count", True), ("window_complete", 1),
                             ("body_included", 0), ("note_id", 7), ("content_sha256", "fake")):
            changed = deepcopy(good)
            changed["participants"]["claude"][field] = value
            malformed.append(changed)
        for raw in malformed:
            with self.subTest(raw=raw):
                path.write_text(json.dumps(raw), encoding="utf-8")
                found = conversation.discover(self.library, self.root, "claude")
                self.assertFalse(found["available"])
                self.assertNotEqual(found["reason"], "NO_CHECKPOINT_RECORDED")

    def test_pointer_read_failure_is_distinct_from_missing_and_bad_encoding(self):
        with patch.object(Path, "read_text", side_effect=PermissionError("synthetic denied")):
            found = conversation.discover(self.library, self.root, "claude")
        self.assertEqual(found["reason"], "POINTER_READ_FAILED")
        conversation.pointer_path(self.root).write_bytes(b"\xff")
        self.assertEqual(conversation.read_pointer(self.root, "claude")["reason"], "POINTER_MALFORMED")

    def test_locked_pointer_preserves_existing_bytes_and_saved_note(self):
        self.save()
        path = conversation.pointer_path(self.root)
        before = path.read_bytes()
        lock = path.with_name(conversation.POINTER_NAME + ".lock")
        lock.write_text("other writer", encoding="utf-8")
        status = self.save([exchange("second", "reply")])
        self.assertTrue(status["saved"])
        self.assertFalse(status["pointer_published"])
        self.assertEqual(status["pointer_error"], "POINTER_LOCKED")
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(lock.read_text(encoding="utf-8"), "other writer")

    def test_corrupt_existing_pointer_is_not_overwritten_after_saving(self):
        path = conversation.pointer_path(self.root)
        path.write_bytes(b"{unreadable history")
        status = self.save()
        self.assertTrue(status["saved"])
        self.assertFalse(status["pointer_published"])
        self.assertEqual(status["pointer_error"], "POINTER_MALFORMED")
        self.assertEqual(path.read_bytes(), b"{unreadable history")
        self.assertFalse(path.with_name(conversation.POINTER_NAME + ".lock").exists())

    def test_pointer_merge_is_locked_and_failed_replace_cleans_own_temporary(self):
        self.save()
        path = conversation.pointer_path(self.root)
        before = path.read_bytes()
        entry = conversation.read_pointer(self.root, "claude")
        pending_seen = []

        def competing_replace(source, target):
            pending_seen.append(Path(source))
            with self.assertRaisesRegex(MemoryError, "POINTER_LOCKED"):
                conversation.write_pointer(self.root, "claude", entry)
            self.assertEqual(Path(source).read_bytes(), before)
            raise OSError("synthetic replace failure")

        for _ in range(2):
            with patch.object(conversation.os, "replace", side_effect=competing_replace):
                with self.assertRaises(OSError):
                    conversation.write_pointer(self.root, "claude", entry)
            self.assertEqual(path.read_bytes(), before)
            self.assertFalse(path.with_name(conversation.POINTER_NAME + ".lock").exists())
            self.assertFalse(pending_seen[-1].exists())
        self.assertNotEqual(pending_seen[0], pending_seen[1])


if __name__ == "__main__":
    unittest.main()
