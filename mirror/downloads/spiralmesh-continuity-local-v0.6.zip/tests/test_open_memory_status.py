"""Metadata-only launcher checks; synthetic temp stores, no models or private data."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


BASE = Path(__file__).resolve().parents[1]
LAUNCHER = BASE / "tools" / "open_memory.py"


def load_source(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


STORE = load_source("status_fixture_store", BASE / "src/spiralmesh/continuity/store.py")
OPEN = load_source("status_fixture_launcher", LAUNCHER)


class OpenMemoryStatusTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="status test with spaces ")
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.root = self.home / "private fixture"
        settings = patch.dict(os.environ, {"ARTICLE11_CONFIG_DIR": str(self.home / "synthetic settings")})
        settings.start()
        self.addCleanup(settings.stop)

    def snapshot(self):
        return {str(p.relative_to(self.home)): p.read_bytes() if p.is_file() else None
                for p in self.home.rglob("*")}

    def call(self, principal="codex", launcher=LAUNCHER, explicit_root=True):
        # Exercise the actual executable branch, in a fresh stdlib-only process.
        # A status path must not import any continuity/kernel/provider module.
        script = """
import runpy, sys
def guard(event, args):
    if event in ('socket.connect', 'socket.bind', 'subprocess.Popen', 'os.system'):
        raise AssertionError('Unexpected effect: ' + event)
    if event == 'import' and args[0].startswith('spiralmesh'):
        raise AssertionError('Unexpected application import')
sys.addaudithook(guard)
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
"""
        args = [sys.executable, "-B", "-S", "-c", script, str(launcher), principal, "--status"]
        if explicit_root:
            args += ["--root", str(self.root)]
        result = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", timeout=10)
        self.assertEqual(result.stderr, "")
        return result.returncode, json.loads(result.stdout)

    def test_missing_explicit_root_never_creates_storage(self):
        before = self.snapshot()
        code, result = self.call()
        self.assertEqual(code, 1)
        self.assertEqual(result["status"], "missing")
        self.assertIsNone(result["notes"])
        self.assertEqual(result["root"], str(self.root.resolve()))
        self.assertEqual(self.snapshot(), before)
        self.assertTrue(result["integrity_support"]["caller_operation_id_retry"])
        self.assertTrue(result["integrity_support"]["mutation_reconciliation"])

    def test_default_root_lookup_does_not_initialize_clean_fork(self):
        package = self.home / "clean fork"
        launcher = package / "tools/open_memory.py"
        launcher.parent.mkdir(parents=True)
        launcher.write_bytes(LAUNCHER.read_bytes())
        (launcher.parent / "library_choice.py").write_bytes(
            (BASE / "tools/library_choice.py").read_bytes())
        before = self.snapshot()
        _, result = self.call(launcher=launcher, explicit_root=False)
        self.assertEqual(result["status"], "missing")
        self.assertEqual(result["error"], "LIBRARY_CHOICE_REQUIRED")
        self.assertFalse((self.home / "clean fork-memory").exists())
        self.assertEqual(self.snapshot(), before)

    def test_available_status_is_owner_metadata_only_and_byte_read_only(self):
        codex = STORE.MemoryLibrary(self.root, "codex", "synthetic", create=True)
        claude = STORE.MemoryLibrary(self.root, "claude", "synthetic")
        old = codex.remember("PRIVATE-TITLE-CODEX", "PRIVATE-BODY-CODEX")["note_id"]
        new = codex.correct(old, "PRIVATE-NEW-TITLE", "PRIVATE-NEW-BODY")["note_id"]
        codex.set_letter(new)
        forgotten = codex.remember("REMOVED-TITLE", "REMOVED-BODY")["note_id"]
        codex.forget(forgotten)
        foreign = claude.remember("FOREIGN-PRIVATE-TITLE", "FOREIGN-PRIVATE-BODY")["note_id"]
        claude.share(foreign)
        claude.set_letter(foreign)
        before = self.snapshot()
        code, result = self.call()
        self.assertEqual(code, 0)
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["notes"], {"total": 3, "active": 1, "superseded": 1, "forgotten": 1, "other": 0})
        self.assertEqual(result["starter_letter"], {"selected": True, "available": True})
        self.assertEqual(result["principal"], "codex")
        self.assertFalse(result["provider_invoked"])
        serialized = json.dumps(result)
        for forbidden in (old, new, foreign, "PRIVATE-", "FOREIGN-", "REMOVED-", "claude"):
            self.assertNotIn(forbidden, serialized)
        _, other = self.call("claude")
        self.assertEqual(other["notes"], {"total": 1, "active": 1, "superseded": 0, "forgotten": 0, "other": 0})
        self.assertEqual(other["starter_letter"], {"selected": True, "available": True})
        self.assertEqual(self.snapshot(), before)

    def test_empty_available_owner_is_distinct_from_missing_and_letter_is_owner_bound(self):
        STORE.MemoryLibrary(self.root, "codex", create=True)
        claude = STORE.MemoryLibrary(self.root, "claude")
        foreign = claude.remember("FOREIGN-TITLE", "FOREIGN-BODY")["note_id"]
        with contextlib.closing(sqlite3.connect(self.root / "memory.sqlite3")) as db:
            db.execute("INSERT INTO letters VALUES(?,?)", ("codex", foreign))
            db.commit()
        before = self.snapshot()
        _, result = self.call()
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["notes"]["total"], 0)
        self.assertEqual(result["starter_letter"], {"selected": True, "available": False})
        self.assertEqual(self.snapshot(), before)

    def test_unreadable_schema_and_wal_are_unavailable_not_empty(self):
        self.root.mkdir()
        database = self.root / "memory.sqlite3"
        database.write_bytes(b"synthetic invalid sqlite bytes")
        before = self.snapshot()
        _, result = self.call()
        self.assertEqual(result["status"], "unavailable")
        self.assertIsNone(result["notes"])
        self.assertEqual(result["error"], "LIBRARY_STATUS_UNAVAILABLE")
        self.assertEqual(self.snapshot(), before)
        database.with_name(database.name + "-wal").write_bytes(b"synthetic sidecar")
        before = self.snapshot()
        _, result = self.call()
        self.assertEqual(result["error"], "WAL_STATUS_NOT_SUPPORTED")
        self.assertEqual(self.snapshot(), before)

    def test_normal_launcher_still_initializes_then_opens_existing_dialogue(self):
        calls = []
        store = types.ModuleType("spiralmesh.continuity.store")
        def initialize(*args, **kwargs):
            calls.append(("library", args, kwargs))
            return STORE.MemoryLibrary(*args, **kwargs)
        store.MemoryLibrary = initialize
        runner = types.ModuleType("spiralmesh.continuity.runner")
        runner.main = lambda: calls.append(("dialogue", list(sys.argv)))
        modules = {"spiralmesh": types.ModuleType("spiralmesh"),
                   "spiralmesh.continuity": types.ModuleType("spiralmesh.continuity"),
                   store.__name__: store, runner.__name__: runner}
        with patch.dict(sys.modules, modules), patch.object(sys, "path", list(sys.path)), \
             patch.object(sys, "argv", [str(LAUNCHER), "codex", "--root", str(self.root)]), \
             contextlib.redirect_stdout(io.StringIO()):
            OPEN.main()
        self.assertEqual(calls[0], ("library", (self.root.resolve(), "codex", "human-launcher"), {"create": True}))
        self.assertEqual(calls[1][0], "dialogue")
        self.assertEqual(calls[1][1][1:], ["--root", str(self.root.resolve()), "--principal", "codex", "--interactive"])
        self.assertTrue((self.root / "memory.sqlite3").is_file())
        self.assertEqual(STORE.MemoryLibrary(self.root, "codex").boot()["own_record_count"], 0)
        self.assertFalse((self.root / "runs").exists())

    def test_inaccessible_root_is_unavailable_not_missing(self):
        with patch.object(Path, "stat", side_effect=PermissionError("synthetic denial")):
            result = OPEN.library_status(self.root, "codex")
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["error"], "LIBRARY_STATUS_UNAVAILABLE")
        self.assertIsNone(result["notes"])
        self.assertNotIn("synthetic denial", json.dumps(result))

    def test_closed_wal_header_refuses_without_creating_sidecars(self):
        STORE.MemoryLibrary(self.root, "codex", create=True)
        database = self.root / "memory.sqlite3"
        with contextlib.closing(sqlite3.connect(database)) as db:
            self.assertEqual(db.execute("PRAGMA journal_mode=WAL").fetchone()[0], "wal")
        self.assertFalse(database.with_name(database.name + "-wal").exists())
        self.assertFalse(database.with_name(database.name + "-shm").exists())
        self.assertEqual(database.read_bytes()[18:20], bytes((2, 2)))
        before = self.snapshot()
        _, result = self.call()
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["error"], "WAL_STATUS_NOT_SUPPORTED")
        self.assertEqual(self.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
