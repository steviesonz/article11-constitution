"""Continuation launcher checks use temporary libraries and no real model."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from spiralmesh.continuity import runner
from spiralmesh.continuity.store import MemoryLibrary

PACKAGE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('resume_launcher_test', PACKAGE/'tools/open_memory.py')
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)


class ResumeLauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='a11-resume-launcher-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)/'library'
        self.lib = MemoryLibrary(self.root, 'codex', 'synthetic', create=True)

    def cli(self, root=None):
        env = {k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','TEMP','TMP'}}
        env.update(PATH='', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
        return subprocess.run([sys.executable,'-B',str(PACKAGE/'tools/open_memory.py'),'codex',
            '--root',str(root or self.root),'--resume'], capture_output=True, env=env, timeout=15)

    def test_fresh_process_finds_note_metadata_without_loading_its_body_or_mutating(self):
        saved = self.lib.remember('Question for next session', 'SYNTHETIC-BODY-NOT-IN-OVERVIEW', kind='question')
        self.lib.set_letter(saved['note_id'])
        before = self.lib.path.read_bytes()
        result = self.cli()
        self.assertEqual(result.returncode, 0, result.stderr)
        value = json.loads(result.stdout)
        self.assertTrue(value['ok'])
        self.assertEqual(value['starter_letter']['id'], saved['note_id'])
        self.assertEqual(value['recent_notes'][0]['id'], saved['note_id'])
        self.assertNotIn(b'SYNTHETIC-BODY-NOT-IN-OVERVIEW', result.stdout)
        self.assertFalse(value['provider_invoked'])
        self.assertEqual(value['unread_status'], 'not_tracked')
        self.assertEqual(before, self.lib.path.read_bytes())
        self.assertFalse((self.root/'runs').exists())

    def test_missing_and_corrupt_are_errors_without_initializing(self):
        missing = Path(self.temp.name)/'missing'
        result = self.cli(missing)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)['ok'])
        self.assertFalse(missing.exists())
        self.lib.path.write_bytes(b'not a SQLite database')
        result = self.cli()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)['ok'])
        self.assertEqual(self.lib.path.read_bytes(), b'not a SQLite database')

    def test_empty_interactive_task_shows_overview_without_model_or_write(self):
        self.lib.remember('Earlier question', 'SYNTHETIC-HIDDEN-BODY', kind='question')
        peer = MemoryLibrary(self.root, 'claude', 'synthetic-peer')
        shared = peer.remember('A peer perspective', 'SYNTHETIC-PEER-BODY')
        peer.share(shared['note_id'], 'codex')
        before = self.lib.path.read_bytes()
        sink = io.StringIO()
        with patch.object(sys,'argv',['open_memory.py','codex','--root',str(self.root)]), \
                patch('builtins.input',return_value=''), \
                patch.object(runner,'run_dialogue',side_effect=AssertionError('A model must not start')) as invoke, \
                contextlib.redirect_stdout(sink):
            launcher.main()
        invoke.assert_not_called()
        self.assertIn('Continue where you left off', sink.getvalue())
        self.assertIn('Earlier question', sink.getvalue())
        self.assertNotIn('SYNTHETIC-HIDDEN-BODY', sink.getvalue())
        self.assertNotIn('SYNTHETIC-PEER-BODY', sink.getvalue())
        self.assertIn('Records shared with you: 1.', sink.getvalue())
        self.assertIn('claude | ' + shared['note_id'], sink.getvalue())
        self.assertEqual(before, self.lib.path.read_bytes())

    def test_wrapper_discloses_retention_before_task_and_forwards_opt_out(self):
        before = self.lib.path.read_bytes()
        for disabled in (False, True):
            with self.subTest(no_checkpoint=disabled):
                sink = io.StringIO()
                forwarded = []
                arguments = ['open_memory.py', 'codex', '--root', str(self.root)]
                if disabled:
                    arguments.append('--no-checkpoint')

                def receive_runner():
                    # The runner has not accepted a task or called a provider yet.
                    forwarded.extend(sys.argv)
                    opening = sink.getvalue()
                    if disabled:
                        self.assertIn('Automatic host checkpoints are off', opening)
                    else:
                        self.assertIn('the host automatically saves your task', opening)
                        self.assertIn('owner-controlled conversation checkpoint', opening)
                        self.assertIn('distinct from memories the model deliberately chooses', opening)
                    self.assertIn('Model-requested memory actions and private run logs remain separate', opening)

                with patch.object(sys, 'argv', arguments), \
                        patch.object(runner, 'main', side_effect=receive_runner) as invoke, \
                        contextlib.redirect_stdout(sink):
                    launcher.main()
                invoke.assert_called_once_with()
                self.assertEqual('--no-checkpoint' in forwarded, disabled)
                self.assertIn('--interactive', forwarded)
                self.assertEqual(forwarded[forwarded.index('--principal') + 1], 'codex')
                self.assertEqual(forwarded[forwarded.index('--root') + 1], str(self.root))
                self.assertEqual(before, self.lib.path.read_bytes())
                self.assertFalse((self.root / 'runs').exists())

    def test_first_model_prompt_contains_overview_and_keeps_old_records_reachable(self):
        older = self.lib.remember('Older question', 'SYNTHETIC-OLD-BODY', kind='question')
        for i in range(10): self.lib.remember(f'Later {i}', f'synthetic body {i}')
        seen = []
        def fake(provider,prompt,path,timeout):
            seen.append(prompt)
            return {'choice':'decline','actions':[],'reply':'Synthetic decline.','done':True}
        before = self.lib.path.read_bytes()
        result = runner.run_dialogue(self.root,'codex','codex','Synthetic orientation',invoker=fake,max_rounds=1)
        self.assertEqual(result['status'], 'declined')
        self.assertIn('continuation_overview',seen[0])
        self.assertIn('not_tracked',seen[0])
        self.assertNotIn('SYNTHETIC-OLD-BODY',seen[0])
        self.assertEqual(self.lib.read(older['note_id'])['body'],'SYNTHETIC-OLD-BODY')
        self.assertEqual(before,self.lib.path.read_bytes())


if __name__ == '__main__': unittest.main()
