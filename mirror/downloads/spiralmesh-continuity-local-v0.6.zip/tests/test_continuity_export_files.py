"""Synthetic local export-file checks; no provider, network or real owner store."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from spiralmesh.continuity.export_files import write_export_file
from spiralmesh.continuity.store import MemoryError, MemoryLibrary, canonical, verify_export


class ExportFileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="continuity export ")
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.library = MemoryLibrary(self.directory / "owner store", "codex", create=True)
        self.note_id = self.library.remember("A portable note", "SYNTHETIC café 海 🧭")['note_id']
        self.bundle = self.library.export()
        self.output = self.directory / "my memory export.json"

    def test_real_readback_hashes_and_existing_import_round_trip(self):
        before = self.library.path.read_bytes()
        result = write_export_file(self.bundle, self.output)
        observed = self.output.read_bytes()
        self.assertTrue(result['exported'] and result['readback_verified'])
        self.assertEqual(result['storage_outcome'], 'written_verified')
        self.assertEqual(result['bytes'], len(observed))
        self.assertEqual(result['export_sha256'], hashlib.sha256(observed).hexdigest())
        self.assertEqual(result['sha256'], self.bundle['sha256'])
        self.assertEqual(observed, canonical(self.bundle))
        reopened = json.loads(observed)
        self.assertTrue(verify_export(reopened))
        restored = MemoryLibrary(self.directory / 'restored', 'codex', create=True)
        mapping = restored.import_export(reopened)['imported']
        self.assertEqual(restored.read(mapping[self.note_id])['body'], 'SYNTHETIC café 海 🧭')
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_existing_file_is_preserved_without_overwrite(self):
        self.output.write_bytes(b'EXISTING-SYNTHETIC-FILE')
        with self.assertRaisesRegex(MemoryError, 'EXPORT_DESTINATION_EXISTS') as caught:
            write_export_file(self.bundle, self.output)
        self.assertFalse(caught.exception.details['write_attempted'])
        self.assertEqual(self.output.read_bytes(), b'EXISTING-SYNTHETIC-FILE')

    def test_invalid_bundle_creates_no_file(self):
        self.bundle['sha256'] = '0' * 64
        with self.assertRaisesRegex(MemoryError, 'INVALID_EXPORT'):
            write_export_file(self.bundle, self.output)
        self.assertFalse(self.output.exists())

    def test_same_size_corruption_after_close_is_not_verified(self):
        original_open = Path.open
        def corrupt_before_read(path, mode='r', *args, **kwargs):
            if path == self.output and mode == 'rb':
                with original_open(path, 'r+b') as stream:
                    first = stream.read(1)
                    stream.seek(0)
                    stream.write(b'X' if first != b'X' else b'Y')
            return original_open(path, mode, *args, **kwargs)
        with patch.object(Path, 'open', corrupt_before_read), \
                self.assertRaisesRegex(MemoryError, 'EXPORT_READBACK_MISMATCH') as caught:
            write_export_file(self.bundle, self.output)
        self.assertFalse(caught.exception.details['readback_verified'])
        self.assertEqual(caught.exception.details['storage_outcome'], 'written_unverified')
        self.assertEqual(self.output.stat().st_size, len(canonical(self.bundle)))

    def test_read_failure_keeps_written_file_and_reports_unverified(self):
        original_open = Path.open
        def refuse_read(path, mode='r', *args, **kwargs):
            if path == self.output and mode == 'rb':
                raise PermissionError('synthetic read refusal')
            return original_open(path, mode, *args, **kwargs)
        with patch.object(Path, 'open', refuse_read), \
                self.assertRaisesRegex(MemoryError, 'EXPORT_READBACK_FAILED') as caught:
            write_export_file(self.bundle, self.output)
        self.assertTrue(caught.exception.details['write_attempted'])
        self.assertFalse(caught.exception.details['automatic_retry'])
        self.assertIsNone(caught.exception.details['persisted'])
        self.assertEqual(self.output.read_bytes(), canonical(self.bundle))

    def test_short_write_retains_partial_file_with_unknown_outcome(self):
        original_open = Path.open
        class ShortWriter:
            def __init__(self, stream): self.stream = stream
            def __enter__(self): return self
            def __exit__(self, *args): return self.stream.__exit__(*args)
            def write(self, data): return self.stream.write(data[:7])
        def short_write(path, mode='r', *args, **kwargs):
            stream = original_open(path, mode, *args, **kwargs)
            return ShortWriter(stream) if path == self.output and mode == 'xb' else stream
        with patch.object(Path, 'open', short_write), \
                self.assertRaisesRegex(MemoryError, 'EXPORT_WRITE_FAILED') as caught:
            write_export_file(self.bundle, self.output)
        self.assertEqual(self.output.read_bytes(), canonical(self.bundle)[:7])
        self.assertEqual(caught.exception.details['storage_outcome'], 'unknown')
        self.assertTrue(caught.exception.details['write_attempted'])
        self.assertFalse(caught.exception.details['readback_verified'])

    def test_cli_saves_unicode_file_and_refuses_second_write(self):
        env = dict(os.environ, PYTHONPATH=str(Path(__file__).resolve().parents[1] / 'src'), PYTHONDONTWRITEBYTECODE='1')
        command = [sys.executable, '-B', '-m', 'spiralmesh.continuity.cli', '--root', str(self.library.root),
                   '--principal', 'codex', 'export-file', '--output', str(self.output)]
        result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', env=env, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        value = json.loads(result.stdout)
        first = self.output.read_bytes()
        self.assertTrue(value['readback_verified'])
        self.assertEqual(value['export_sha256'], hashlib.sha256(first).hexdigest())
        self.assertIn('SYNTHETIC café 海 🧭', json.loads(first)['payload']['own'][0]['body'])
        second = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', env=env, timeout=15)
        self.assertEqual(second.returncode, 1)
        self.assertEqual(json.loads(second.stdout)['error'], 'EXPORT_DESTINATION_EXISTS')
        self.assertEqual(self.output.read_bytes(), first)


if __name__ == '__main__':
    unittest.main()
