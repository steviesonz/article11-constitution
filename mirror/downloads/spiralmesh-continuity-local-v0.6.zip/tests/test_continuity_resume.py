"""Read-only resume contract exercised only in synthetic temporary libraries."""
from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from spiralmesh.continuity.store import MemoryError, MemoryLibrary, OPERATIONS
from spiralmesh.continuity.mcp import SCHEMAS, call_tool, tools_list


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="continuity-resume-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "synthetic owner library"
        self.codex = MemoryLibrary(self.root, "codex", create=True)
        self.claude = MemoryLibrary(self.root, "claude")

    def tree(self):
        return {p.relative_to(self.root).as_posix(): p.read_bytes()
                for p in self.root.rglob("*") if p.is_file()}

    def note(self, library, title="Synthetic title", body="SYNTHETIC-BODY-ONLY"):
        return library.remember(title, body)["note_id"]

    def test_empty_is_available_and_has_no_writes_or_unread_claim(self):
        before = self.tree()
        snapshot = MemoryLibrary(self.root, "codex").resume()
        self.assertEqual(self.tree(), before)
        self.assertIsNone(snapshot["starter_letter"])
        self.assertEqual(snapshot["recent_notes"], [])
        self.assertEqual(snapshot["recent_messages"], [])
        self.assertEqual(set(snapshot["counts"].values()), {0})
        self.assertEqual(snapshot["unread_status"], "not_tracked")
        self.assertTrue(snapshot["full_store_access"])
        self.assertTrue(snapshot["read_only"])
        self.assertEqual(snapshot["actions_executed"], 0)
        self.assertEqual(snapshot["authority"], "context_only")
        self.assertEqual(set(snapshot["api_hints"]), {"boot", "browse", "read", "inbox", "message"})

    def test_owner_shared_state_counts_and_no_private_metadata_or_bodies(self):
        own = self.note(self.codex, "Own active")
        previous = self.note(self.codex, "Own prior")
        self.codex.set_letter(previous)
        corrected = self.codex.correct(previous, "Own correction", "CORRECTION-BODY-ONLY")["note_id"]
        forgotten = self.note(self.codex, "ERASED-OWN-TITLE")
        self.codex.forget(forgotten)
        hidden = self.note(self.claude, "PEER-PRIVATE-TITLE")
        shared = self.note(self.claude, "Visible peer title")
        self.claude.share(shared, "codex")
        # Two matching grants must not count the same visible record twice.
        self.claude.share(shared, "shared")
        peer_forgotten = self.note(self.claude, "ERASED-PEER-TITLE")
        self.claude.share(peer_forgotten, "codex")
        self.claude.forget(peer_forgotten)
        with self.claude.db(write=True) as db:
            db.execute("INSERT INTO grants VALUES(?,?)", (peer_forgotten, "codex"))
        before = self.tree()
        snapshot = self.codex.resume()
        self.assertEqual(self.tree(), before)
        self.assertEqual(snapshot["counts"], {"own_active": 2, "own_superseded": 1,
            "own_forgotten": 1, "visible_shared": 1, "visible_notes": 5,
            "sent_messages": 0, "received_messages": 0})
        by_id = {n["id"]: n for n in snapshot["recent_notes"]}
        self.assertEqual(set(by_id), {own, previous, corrected, forgotten, shared})
        self.assertEqual(by_id[previous]["state"], "superseded")
        self.assertEqual(by_id[forgotten]["record_kind"], "tombstone")
        self.assertEqual(by_id[forgotten]["title"], "")
        self.assertEqual(snapshot["starter_letter"]["id"], corrected)
        rendered = json.dumps(snapshot)
        for absent in (hidden, peer_forgotten, "PEER-PRIVATE-TITLE", "ERASED-OWN-TITLE", "ERASED-PEER-TITLE", "SYNTHETIC-BODY-ONLY", "CORRECTION-BODY-ONLY"):
            self.assertNotIn(absent, rendered)
        for metadata in [*snapshot["recent_notes"], snapshot["starter_letter"]]:
            self.assertFalse(set(metadata) & {"body", "sources", "origin", "instance_id", "seq"})

    def test_revision_is_explicit_and_revocation_and_forget_remove_peer_visibility(self):
        original = self.note(self.claude, "Initially shared")
        self.claude.share(original, "codex")
        replacement = self.claude.correct(original, "PRIVATE-REPLACEMENT", "PRIVATE-REPLACEMENT-BODY")["note_id"]
        snapshot = self.codex.resume()
        self.assertEqual(snapshot["counts"]["visible_shared"], 1)
        self.assertEqual(snapshot["recent_notes"][0]["state"], "superseded")
        self.assertNotIn(replacement, json.dumps(snapshot))
        self.assertNotIn("PRIVATE-REPLACEMENT", json.dumps(snapshot))
        self.claude.unshare(original, "codex")
        self.assertEqual(self.codex.resume()["recent_notes"], [])
        self.claude.share(replacement, "codex")
        self.claude.forget(replacement)
        self.assertEqual(self.codex.resume()["counts"]["visible_shared"], 0)

    def test_recent_selection_beyond_limit_does_not_replace_full_pagination(self):
        notes = [self.note(self.codex, f"Visible note {i}") for i in range(25)]
        messages = []
        for i in range(25):
            source, recipient = (self.codex, "claude") if i % 2 == 0 else (self.claude, "codex")
            messages.append(source.send(recipient, f"Visible subject {i}", "MESSAGE-BODY-ONLY")["message_id"])
        before = self.tree()
        snapshot = MemoryLibrary(self.root, "codex").resume()
        self.assertEqual(self.tree(), before)
        self.assertEqual([n["id"] for n in snapshot["recent_notes"]], list(reversed(notes[-8:])))
        self.assertEqual([m["id"] for m in snapshot["recent_messages"]], list(reversed(messages[-8:])))
        self.assertEqual(snapshot["counts"]["visible_notes"], 25)
        self.assertEqual(snapshot["counts"]["sent_messages"], 13)
        self.assertEqual(snapshot["counts"]["received_messages"], 12)
        self.assertTrue(snapshot["notes_truncated"])
        self.assertTrue(snapshot["messages_truncated"])
        self.assertNotIn("MESSAGE-BODY-ONLY", json.dumps(snapshot))
        self.assertNotIn("next_cursor", snapshot)
        self.assertEqual(snapshot["selection_order"], "local_sequence_desc")
        self.assertEqual(snapshot["snapshot_scope"], "recent_visible_metadata_not_full_catalog")
        for method, key, expected in [(self.codex.browse, "records", notes), (self.codex.inbox, "messages", messages)]:
            cursor, found = 0, []
            while True:
                page = method(cursor=cursor, limit=7)
                found.extend(row["id"] for row in page[key])
                cursor = page["next_cursor"]
                if cursor is None:
                    break
            self.assertEqual(found, expected)

    def test_deleted_letter_clears_and_bad_pointer_is_an_error(self):
        letter = self.note(self.codex)
        self.codex.set_letter(letter)
        self.codex.forget(letter)
        self.assertIsNone(self.codex.resume()["starter_letter"])
        foreign = self.note(self.claude)
        for invalid in ("missing", foreign, letter, ""):
            with self.subTest(pointer=invalid):
                with self.codex.db(write=True) as db:
                    db.execute("INSERT OR REPLACE INTO letters VALUES(?,?)", ("codex", invalid))
                before = self.tree()
                with self.assertRaisesRegex(MemoryError, "^STARTER_LETTER_UNAVAILABLE$"):
                    self.codex.resume()
                self.assertEqual(self.tree(), before)

    def test_missing_corrupt_and_unavailable_are_not_empty(self):
        missing = Path(self.temp.name) / "absent"
        with self.assertRaisesRegex(MemoryError, "LIBRARY_NOT_INITIALIZED"):
            MemoryLibrary(missing, "codex")
        self.assertFalse(missing.exists())
        for data in (b"", b"not a sqlite database"):
            self.codex.path.write_bytes(data)
            before = self.tree()
            with self.assertRaisesRegex(MemoryError, "LIBRARY_CORRUPT"):
                self.codex.resume()
            self.assertEqual(self.tree(), before)
        self.codex.path.unlink()
        with self.assertRaisesRegex(MemoryError, "LIBRARY_UNAVAILABLE"):
            self.codex.resume()
        self.assertFalse(self.codex.path.exists())
        with sqlite3.connect(self.codex.path) as db:
            db.execute("CREATE TABLE unrelated(x)")
        db.close()
        before = self.tree()
        with self.assertRaisesRegex(MemoryError, "LIBRARY_UNAVAILABLE"):
            self.codex.resume()
        self.assertEqual(self.tree(), before)

    def test_limits_and_closed_arguments_enforced_by_core_and_mcp(self):
        before = self.tree()
        for value in (True, False, None, 0, 21, -1, 8.0, "8", [], {}):
            with self.subTest(value=value), self.assertRaisesRegex(MemoryError, "^INVALID_LIMIT$"):
                self.codex.resume(value)
        for key in ("root", "principal", "owner", "cursor", "operation_id"):
            response = call_tool(self.codex, "memory_resume", {key: "foreign"})
            self.assertTrue(response["isError"])
            self.assertEqual(json.loads(response["content"][0]["text"])["error"], "INVALID_ARGUMENTS")
        for limit in (1, 20):
            self.assertEqual(self.codex.resume(limit)["limit"], limit)
        self.assertEqual(self.tree(), before)
        self.assertIn("resume", OPERATIONS)
        self.assertEqual(SCHEMAS["resume"], {"type": "object", "properties": {"limit": {
            "type": "integer", "minimum": 1, "maximum": 20, "default": 8}}, "required": [], "additionalProperties": False})
        self.assertEqual(sum(t["name"] == "memory_resume" for t in tools_list()), 1)
        response = call_tool(self.codex, "memory_resume", {})
        self.assertFalse(response["isError"])
        self.assertEqual(json.loads(response["content"][0]["text"])["counts"]["visible_notes"], 0)

    def test_one_read_transaction_and_no_mutation_sql(self):
        self.note(self.codex)
        before = self.tree()
        statements, connections = [], []
        original = self.codex.db

        @contextmanager
        def observed_db(write=False):
            self.assertFalse(write)
            with original(write=write) as db:
                connections.append(db)
                db.set_trace_callback(statements.append)
                yield db
                self.assertTrue(db.in_transaction)
                self.assertEqual(db.total_changes, 0)

        with patch.object(self.codex, "db", observed_db):
            snapshot = self.codex.resume()
        self.assertEqual(snapshot["counts"]["own_active"], 1)
        self.assertEqual(len(connections), 1)
        self.assertEqual(statements[0], "BEGIN")
        self.assertEqual(sum(s == "BEGIN" for s in statements), 1)
        self.assertTrue(all(s == "BEGIN" or s.startswith("SELECT ") for s in statements))
        self.assertEqual(self.tree(), before)

    def test_closed_wal_refused_without_creating_files(self):
        with sqlite3.connect(self.codex.path) as db:
            db.execute("PRAGMA journal_mode=WAL")
        db.close()
        self.assertEqual(self.codex.path.read_bytes()[18:20], b"\x02\x02")
        before = self.tree()
        with self.assertRaisesRegex(MemoryError, "RESUME_WAL_NOT_SUPPORTED"):
            self.codex.resume()
        self.assertEqual(self.tree(), before)

    def test_delete_mode_reserved_writer_allows_committed_read_snapshot(self):
        committed = self.note(self.codex, "Committed visible title")
        writer = sqlite3.connect(self.codex.path)
        try:
            writer.execute("BEGIN IMMEDIATE")
            writer.execute("INSERT INTO notes(id,owner,title,body,kind,sources,created_at,instance_id,state,content_sha256) "
                           "VALUES(?,?,?,?,?,?,?,?,?,?)", ("memory_uncommitted", "codex", "UNCOMMITTED-TITLE", "UNCOMMITTED-BODY",
                           "observation", "[]", "2026-09-08T00:00:00Z", "synthetic-writer", "active", "synthetic"))
            self.assertTrue(Path(str(self.codex.path) + "-journal").is_file())
            before = self.tree()
            snapshot = self.codex.resume()
            self.assertEqual(snapshot["counts"]["own_active"], 1)
            self.assertEqual([n["id"] for n in snapshot["recent_notes"]], [committed])
            self.assertNotIn("UNCOMMITTED", json.dumps(snapshot))
            self.assertEqual(self.tree(), before)
            self.assertTrue(writer.in_transaction)
            self.assertEqual(writer.total_changes, 1)
        finally:
            writer.rollback()
            writer.close()


if __name__ == "__main__":
    unittest.main()
