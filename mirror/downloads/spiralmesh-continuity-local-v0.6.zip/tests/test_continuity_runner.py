"""Cloud-dialogue protocol tests: injected responses and fake subprocesses only."""
import json
import hashlib
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch

from spiralmesh.continuity import runner
from spiralmesh.continuity.store import MemoryError, MemoryLibrary


def action(operation, arguments=None, bind="result"):
    return {"operation": operation, "arguments_json": json.dumps(arguments or {}), "bind": bind}


def answer(actions=None, choice="accept", done=True, reply="Synthetic response"):
    return {"choice": choice, "actions": actions or [], "reply": reply, "done": done}


class ContinuityRunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="spiralmesh-runner-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "memory"
        self.library = MemoryLibrary(self.root, "codex", "setup", create=True)

    def dialogue(self, response, principal="codex", **kwargs):
        invoker = Mock(return_value=response)
        receipt = runner.run_dialogue(self.root, principal, principal, "Synthetic Article11 task",
                                      invoker=invoker, **kwargs)
        return receipt, invoker

    def run_receipts(self):
        return [json.loads(p.read_text(encoding="utf-8"))
                for p in self.root.glob("runs/*/*/RUN_RECEIPT.json")]

    def test_unknown_actor_or_provider_mismatch_never_invokes_or_writes_memory(self):
        before = self.library.path.read_bytes()
        invoker = Mock()
        for principal, provider in (("unknown", "unknown"), ("codex", "claude")):
            with self.subTest(principal=principal, provider=provider), self.assertRaises(MemoryError):
                runner.run_dialogue(self.root, principal, provider, "Synthetic", invoker=invoker)
        invoker.assert_not_called()
        self.assertEqual(self.library.path.read_bytes(), before)
        self.assertFalse((self.root / "runs").exists())

    def test_unknown_operation_is_rejected_before_an_earlier_valid_write(self):
        before = self.library.path.read_bytes()
        responses = answer([
            action("remember", {"title": "Must not persist", "body": "SYNTHETIC-NO-WRITE"}, "note"),
            action("read_arbitrary_file", {"path": "outside.txt"}, "escape"),
        ])
        invoker = Mock(return_value=responses)
        with self.assertRaises(MemoryError):
            runner.run_dialogue(self.root, "codex", "codex", "Synthetic", invoker=invoker)
        invoker.assert_called_once()
        self.assertEqual(self.library.path.read_bytes(), before)
        self.assertEqual(self.run_receipts()[0]["status"], "failed_no_retry")

    def test_replacement_actor_in_action_is_a_failed_operation_without_memory_write(self):
        before = self.library.path.read_bytes()
        receipt, invoker = self.dialogue(answer([action("remember", {
            "title": "Wrong actor", "body": "SYNTHETIC-DENIED", "principal": "claude"})]))
        invoker.assert_called_once()
        self.assertEqual(receipt["status"], "failed_operation")
        self.assertFalse(receipt["rounds"][0]["operations"][0]["ok"])
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_decline_with_actions_refuses_before_any_memory_effect(self):
        before = self.library.path.read_bytes()
        invoker = Mock(return_value=answer([action("remember", {
            "title": "Not a valid decline", "body": "SYNTHETIC-NO-WRITE"})], choice="decline"))
        with self.assertRaisesRegex(MemoryError, "DECLINE_WITH_ACTIONS"):
            runner.run_dialogue(self.root, "codex", "codex", "Synthetic", invoker=invoker)
        invoker.assert_called_once()
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_valid_decline_is_terminal_even_with_done_false_and_keeps_memory_unchanged(self):
        before = self.library.path.read_bytes()
        receipt, invoker = self.dialogue(answer(choice="decline", done=False, reply="I decline."))
        invoker.assert_called_once()
        self.assertEqual(receipt["status"], "declined")
        self.assertEqual(receipt["rounds"][0]["operations"], [])
        self.assertEqual(self.library.path.read_bytes(), before)
        self.assertTrue(receipt["provider_egress"])
        self.assertIn("no OS-level read-isolation claim", receipt["isolation"])

    def test_timeout_receipt_records_unknown_outcome_and_does_not_retry(self):
        before = self.library.path.read_bytes()
        with patch.object(runner.shutil, "which", return_value="synthetic-claude.exe"), \
                patch.object(runner.subprocess, "run", side_effect=subprocess.TimeoutExpired("synthetic", 3)) as process:
            with self.assertRaisesRegex(MemoryError, "PROVIDER_TIMEOUT_OUTCOME_UNKNOWN"):
                runner.run_dialogue(self.root, "claude", "claude", "Synthetic timeout",
                                    timeout=3, invoker=runner.invoke)
        process.assert_called_once()
        self.assertIs(process.call_args.kwargs["shell"], False)
        self.assertEqual(self.library.path.read_bytes(), before)
        receipt = self.run_receipts()[0]
        self.assertEqual(receipt["status"], "failed_no_retry")
        invocation_file = next(self.root.glob("runs/claude/*/round-01/invocation.json"))
        invocation = json.loads(invocation_file.read_text(encoding="utf-8"))
        self.assertEqual(invocation["status"], "outcome_unknown_timeout_no_retry")
        self.assertEqual(invocation["os_read_isolation"], "not_claimed")
        self.assertTrue(invocation["provider_egress"])

    def test_dependent_bindings_and_next_round_results_use_actual_saved_ids(self):
        responses = [answer([
            action("remember", {"title": "Synthetic letter", "body": "SYNTHETIC-BOUND-CONTEXT"}, "note"),
            action("set_letter", {"note_id": "$note.note_id"}, "letter"),
            action("read", {"note_id": "$note.note_id"}, "readback"),
        ], done=False), answer(reply="Read back the saved synthetic note.")]
        invoker = Mock(side_effect=responses)
        receipt = runner.run_dialogue(self.root, "codex", "codex", "Synthetic dependencies", invoker=invoker)
        self.assertEqual(invoker.call_count, 2)
        self.assertEqual(receipt["status"], "completed")
        operations = receipt["rounds"][0]["operations"]
        note_id = operations[0]["result"]["note_id"]
        self.assertEqual(operations[1]["result"]["letter"], note_id)
        self.assertEqual(operations[2]["result"]["id"], note_id)
        self.assertEqual(operations[2]["result"]["body"], "SYNTHETIC-BOUND-CONTEXT")
        self.assertIn(note_id, invoker.call_args_list[1].args[1])
        self.assertEqual(self.library.boot()["offer"]["id"], note_id)

    def test_fresh_provider_sessions_keep_distinct_owner_memories_in_same_store(self):
        receipts = {}
        for principal in ("codex", "claude"):
            response = answer([
                action("remember", {"title": principal + " letter", "body": "SYNTHETIC-" + principal}, "note"),
                action("set_letter", {"note_id": "$note.note_id"}, "letter"),
            ])
            receipts[principal], _ = self.dialogue(response, principal)
        for principal in ("codex", "claude"):
            with self.subTest(principal=principal):
                next_receipt, invoker = self.dialogue(answer([action("boot", bind="startup")]), principal)
                self.assertNotEqual(receipts[principal]["instance_id"], next_receipt["instance_id"])
                boot = next_receipt["rounds"][0]["operations"][0]["result"]
                self.assertEqual(boot["offer"]["body"], "SYNTHETIC-" + principal)
                self.assertEqual(boot["own_record_count"], 1)
                other = "claude" if principal == "codex" else "codex"
                self.assertNotIn("SYNTHETIC-" + other, invoker.call_args.args[1])

    def test_done_true_cannot_turn_a_failed_read_into_completed(self):
        receipt, invoker = self.dialogue(answer([
            action("read", {"note_id": "memory_synthetic_absent"}, "missing"),
            action("remember", {"title": "Must not execute", "body": "SYNTHETIC-AFTER-ERROR"}, "later"),
        ], reply="Claimed completion is not proof."))
        invoker.assert_called_once()
        self.assertEqual(receipt["status"], "failed_operation")
        self.assertEqual(len(receipt["rounds"][0]["operations"]), 1)
        self.assertEqual(receipt["rounds"][0]["operations"][0]["error"], "NOT_FOUND")
        self.assertEqual(self.library.browse()["records"], [])

    def test_export_uses_host_filename_and_traversal_binding_refuses(self):
        self.library.remember("Export sample", "SYNTHETIC-EXPORT")
        receipt, _ = self.dialogue(answer([action("export", bind="portable")]))
        result = receipt["rounds"][0]["operations"][0]["result"]
        self.assertEqual(result["local_file"], "export-portable.json")
        run_dir = Path(receipt["receipt_path"]).parent
        bundle = json.loads((run_dir / result["local_file"]).read_text(encoding="utf-8"))
        self.assertEqual(bundle["sha256"], result["sha256"])
        self.assertTrue(result["readback_verified"])
        self.assertEqual(result["export_sha256"], hashlib.sha256((run_dir / result["local_file"]).read_bytes()).hexdigest())
        self.assertIn("SYNTHETIC-EXPORT", json.dumps(bundle))
        for binding in ("../escape", "..\\escape", "/absolute", "C:\\escape", "name.json"):
            with self.subTest(binding=binding):
                invoker = Mock(return_value=answer([action("export", bind=binding)]))
                with self.assertRaisesRegex(MemoryError, "INVALID_BINDING"):
                    runner.run_dialogue(self.root, "codex", "codex", "Synthetic export", invoker=invoker)
        self.assertEqual([p.name for p in Path(self.temp.name).rglob("export-*.json")], ["export-portable.json"])

    def test_export_readback_failure_stops_later_memory_action(self):
        before = self.library.path.read_bytes()
        original_open = Path.open
        def unreadable(path, mode='r', *args, **kwargs):
            if path.name == 'export-portable.json' and mode == 'rb':
                raise PermissionError('synthetic export readback failure')
            return original_open(path, mode, *args, **kwargs)
        with patch.object(Path, 'open', unreadable):
            receipt, invoker = self.dialogue(answer([
                action('export', bind='portable'),
                action('remember', {'title': 'Do not save', 'body': 'SYNTHETIC-AFTER-FAILED-EXPORT'}, 'later')]))
        invoker.assert_called_once()
        self.assertEqual(receipt['status'], 'failed_operation')
        operations = receipt['rounds'][0]['operations']
        self.assertEqual(len(operations), 1)
        self.assertEqual(operations[0]['error'], 'EXPORT_READBACK_FAILED')
        self.assertFalse(operations[0]['ok'] or operations[0]['readback_verified'])
        self.assertEqual(operations[0]['storage_outcome'], 'written_unverified')
        self.assertEqual(self.library.path.read_bytes(), before)
        exported = Path(receipt['receipt_path']).parent / 'export-portable.json'
        self.assertTrue(exported.is_file())

    def test_verified_export_keeps_existing_bundle_binding_for_dependent_import(self):
        self.library.remember('Synthetic original', 'SYNTHETIC-EXPORT-BINDING')
        receipt, _ = self.dialogue(answer([
            action('export', bind='portable'),
            action('import_export', {'bundle': {'payload': '$portable.payload',
                'sha256': '$portable.sha256', 'verification_limit': '$portable.verification_limit'}}, 'imported')]))
        self.assertEqual(receipt['status'], 'completed')
        self.assertTrue(all(operation['ok'] for operation in receipt['rounds'][0]['operations']))

    def test_claude_command_disables_native_tools_without_bypass_flags(self):
        directory = Path(self.temp.name) / "synthetic round with spaces"
        claude = runner.commands("claude", "synthetic-claude.exe", directory)
        self.assertIn("--safe-mode", claude)
        self.assertEqual(claude[claude.index("--tools") + 1], "")
        self.assertEqual(claude[claude.index("--permission-mode") + 1], "dontAsk")
        self.assertEqual(claude[claude.index("--mcp-config") + 1], '{"mcpServers":{}}')
        self.assertIn("--no-session-persistence", claude)
        self.assertIsInstance(claude, list)
        for forbidden in ("--dangerously-bypass-approvals-and-sandbox", "--dangerously-skip-permissions",
                          "--yolo", "--full-auto", "bypassPermissions"):
            self.assertNotIn(forbidden, claude)

    def test_codex_invocation_delegates_once_with_schema_and_timeout(self):
        response = answer(choice="decline", reply="Synthetic transport answer.")
        run_dir = self.root / "synthetic-codex-round"
        before = self.library.path.read_bytes()
        with patch("spiralmesh.continuity.codex_transport.invoke_codex", return_value=response) as transport, \
                patch.object(runner.subprocess, "run") as generic_process:
            observed = runner.invoke("codex", "Synthetic routing prompt", run_dir, timeout=23)
        self.assertEqual(observed, response)
        transport.assert_called_once_with("Synthetic routing prompt", run_dir, runner.RESPONSE_SCHEMA, 23)
        generic_process.assert_not_called()
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_codex_transport_rejection_refuses_before_memory_actions(self):
        before = self.library.path.read_bytes()
        with patch("spiralmesh.continuity.codex_transport.invoke_codex",
                      side_effect=MemoryError("SYNTHETIC_TRANSPORT_REFUSAL")) as transport, \
                patch.object(runner.subprocess, "run") as generic_process:
            with self.assertRaisesRegex(MemoryError, "SYNTHETIC_TRANSPORT_REFUSAL"):
                runner.run_dialogue(self.root, "codex", "codex", "Synthetic rejection", invoker=runner.invoke)
        transport.assert_called_once()
        generic_process.assert_not_called()
        self.assertEqual(self.library.path.read_bytes(), before)
        receipt = self.run_receipts()[0]
        self.assertEqual(receipt["status"], "failed_no_retry")
        self.assertEqual(receipt["rounds"], [])


if __name__ == "__main__":
    unittest.main()
