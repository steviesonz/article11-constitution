"""No provider, filesystem tool, connector, or authentication calls."""
import io
import json
from pathlib import Path
import queue
import tempfile
import unittest
from unittest.mock import patch

from spiralmesh.continuity import codex_transport as transport
from spiralmesh.continuity.store import MemoryError


ANSWER = {"choice": "accept", "actions": [], "reply": "Synthetic", "done": True}
SCHEMA = {"type": "object"}


class Lines:
    def __init__(self):
        self.queue = queue.Queue()

    def put(self, event):
        self.queue.put(json.dumps(event) + "\n" if event is not None else "")

    def readline(self, size):
        return self.queue.get()

    def close(self):
        self.put(None)


class Input:
    def __init__(self, owner):
        self.owner = owner

    def write(self, line):
        self.owner.received(json.loads(line))

    def flush(self):
        pass

    def close(self):
        pass


class FakeProcess:
    def __init__(self, *, inventory=None, event_kind="agentMessage", silence=None,
                 completed="completed", rpc_error=None, server_request=False):
        self.stdin, self.stdout, self.stderr = Input(self), Lines(), io.StringIO("")
        self.inventory = [] if inventory is None else inventory
        self.event_kind, self.silence, self.completed = event_kind, silence, completed
        self.rpc_error, self.server_request = rpc_error, server_request
        self.calls, self.returncode, self.terminated = [], None, False

    def received(self, message):
        self.calls.append(message)
        method = message.get("method")
        if "id" not in message or "method" not in message or method == self.silence:
            return
        if method == self.rpc_error:
            self.stdout.put({"id": message["id"], "error": {"code": -32602}})
            return
        results = {"initialize": {"userAgent": "synthetic"},
                   "thread/start": {"thread": {"id": "thread-test"}, "model": "configured-model"},
                   "mcpServerStatus/list": {"data": self.inventory, "nextCursor": None},
                   "turn/start": {"turn": {"id": "turn-test"}}}
        self.stdout.put({"id": message["id"], "result": results[method]})
        if method == "turn/start":
            if self.server_request:
                self.stdout.put({"id": "approval-request", "method": "item/commandExecution/requestApproval",
                                 "params": {"command": "must never execute"}})
                return
            self.stdout.put({"method": "thread/tokenUsage/updated", "params": {
                "threadId": "thread-test", "tokenUsage": {"total": {"totalTokens": 15}}}})
            self.stdout.put({"method": "item/completed", "params": {
                "threadId": "thread-test", "turnId": "turn-test", "item": {
                    "id": "answer", "type": self.event_kind, "text": json.dumps(ANSWER)}}})
            self.stdout.put({"method": "turn/completed", "params": {
                "threadId": "thread-test", "turn": {"id": "turn-test", "status": self.completed}}})

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated = True
        self.returncode = 0
        self.stdout.put(None)

    def wait(self, timeout=None):
        return self.returncode

    def kill(self):
        self.terminate()


class CodexTransportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.run_dir = Path(self.temp.name) / "run"

    def invoke(self, fake, timeout=1):
        with patch.object(transport, "configuration_paths", return_value=[]), \
             patch.object(transport, "resolve_executable", return_value=("synthetic-codex.exe", "0.153.4")), \
             patch.object(transport.subprocess, "Popen", return_value=fake) as launch:
            try:
                return transport.invoke_codex("Synthetic prompt", self.run_dir, SCHEMA,
                                              timeout, executable="synthetic-codex.exe")
            finally:
                self.assertEqual(launch.call_count, 1)
                self.assertFalse(launch.call_args.kwargs["shell"])

    def receipt(self):
        return json.loads((self.run_dir / "invocation.json").read_text(encoding="utf-8"))

    def test_success_binds_no_environment_schema_usage_and_cleanup(self):
        fake = FakeProcess()
        self.assertEqual(self.invoke(fake), ANSWER)
        calls = {x["method"]: x.get("params") for x in fake.calls if "method" in x}
        self.assertTrue(calls["initialize"]["capabilities"]["experimentalApi"])
        self.assertEqual(calls["thread/start"]["environments"], [])
        self.assertEqual(calls["thread/start"]["dynamicTools"], [])
        self.assertTrue(calls["thread/start"]["ephemeral"])
        self.assertEqual(calls["thread/start"]["baseInstructions"], transport.BASE_INSTRUCTIONS)
        self.assertEqual(calls["thread/start"]["developerInstructions"], transport.DEVELOPER_INSTRUCTIONS)
        self.assertNotIn("environments", calls["turn/start"])
        self.assertNotIn("model", calls["thread/start"])
        self.assertEqual(calls["turn/start"]["outputSchema"], SCHEMA)
        self.assertTrue(fake.terminated)
        self.assertEqual(self.receipt()["status"], "parsed_response")
        self.assertEqual(self.receipt()["thread_id"], "thread-test")
        self.assertEqual(self.receipt()["cli_version"], "0.153.4")
        self.assertEqual(self.receipt()["usage_events"][0]["total"]["totalTokens"], 15)

    def test_inherited_mcp_refuses_before_model_turn(self):
        fake = FakeProcess(inventory=[{"name": "unexpected"}])
        with self.assertRaisesRegex(MemoryError, "INHERITED_MCP_NOT_EMPTY"):
            self.invoke(fake)
        self.assertNotIn("turn/start", [x.get("method") for x in fake.calls])
        self.assertFalse(self.receipt()["provider_egress"])

    def test_configured_disabled_mcp_entries_are_accepted_without_claiming_absence(self):
        entry = {"name": "known", "tools": {}, "resources": [],
                 "resourceTemplates": [], "serverInfo": None, "authStatus": "unsupported"}
        result = transport.verify_mcp_inventory({"data": [entry], "nextCursor": None}, ["known"])
        self.assertEqual(result[0]["name"], "known")
        self.assertTrue(result[0]["explicitly_disabled"])
        self.assertEqual(result[0]["tool_count"], 0)
        for field, value in [("name", "unknown"), ("tools", {"tool": {}}),
                             ("resources", [{}]), ("resourceTemplates", [{}]),
                             ("serverInfo", {}), ("authStatus", "oAuth")]:
            with self.subTest(field=field), self.assertRaises(MemoryError):
                transport.verify_mcp_inventory({"data": [{**entry, field: value}]}, ["known"])
        with self.assertRaises(MemoryError):
            transport.verify_mcp_inventory({"data": [entry], "nextCursor": "more"}, ["known"])

    def test_native_tool_event_never_returns_actions(self):
        for kind in ("commandExecution", "fileChange", "mcpToolCall", "webSearch", "imageView"):
            with self.subTest(kind=kind):
                self.run_dir = Path(self.temp.name) / kind
                with self.assertRaisesRegex(MemoryError, "UNEXPECTED_NATIVE_TOOL_USE"):
                    self.invoke(FakeProcess(event_kind=kind))
                self.assertFalse((self.run_dir / "answer.json").exists())

    def test_approval_request_is_explicitly_rejected_and_stops_process(self):
        fake = FakeProcess(server_request=True)
        with self.assertRaisesRegex(MemoryError, "UNEXPECTED_SERVER_REQUEST"):
            self.invoke(fake)
        rejection = [c for c in fake.calls if c.get("id") == "approval-request"][0]
        self.assertEqual(rejection["error"]["code"], -32601)
        self.assertTrue(fake.terminated)

    def test_timeout_has_unknown_outcome_and_no_retry(self):
        fake = FakeProcess(silence="turn/start")
        with self.assertRaisesRegex(MemoryError, "PROVIDER_TIMEOUT_OUTCOME_UNKNOWN"):
            self.invoke(fake, timeout=0.02)
        self.assertEqual(self.receipt()["status"], "outcome_unknown_timeout_no_retry")
        self.assertTrue(fake.terminated)

    def test_rpc_error_and_failed_turn_do_not_accept_answer(self):
        for name, fake in [("rpc", FakeProcess(rpc_error="thread/start")),
                           ("turn", FakeProcess(completed="failed"))]:
            self.run_dir = Path(self.temp.name) / name
            with self.assertRaises(MemoryError):
                self.invoke(fake)
            self.assertFalse((self.run_dir / "answer.json").exists())

    def test_header_only_inventory_handles_quoted_names_and_ignores_values(self):
        config = Path(self.temp.name) / "config.toml"
        config.write_text('[mcp_servers.alpha]\ncommand="private-value"\n'
                          '[mcp_servers."with.dot".env]\nKEY="secret-not-returned"\n'
                          "[profiles.work.mcp_servers.'third-server']\n", encoding="utf-8")
        names = transport.mcp_names_from_headers([config])
        self.assertEqual(names, ["alpha", "third-server", "with.dot"])
        args = transport.command("codex", transport.configuration(names))
        self.assertIn('mcp_servers={"alpha"={"enabled"=false},"third-server"={"enabled"=false},"with.dot"={"enabled"=false}}', args)
        self.assertNotIn("secret-not-returned", str(args))
        self.assertNotIn("tools.view_image", str(args))
        self.assertIn("--strict-config", args)

    def test_inline_mcp_configuration_refuses_without_parsing_values(self):
        config = Path(self.temp.name) / "config.toml"
        config.write_text('mcp_servers = { hidden = { command="private-value" } }', encoding="utf-8")
        with self.assertRaisesRegex(MemoryError, "MCP_INLINE_CONFIG_UNSUPPORTED"):
            transport.mcp_names_from_headers([config])

    def test_private_diagnostics_keep_actionable_error_and_remove_credentials(self):
        value = {"error": {"message": "Unsupported schema. Authorization: Bearer synthetic-sensitive "
                          "api_key=synthetic-api-key sk-test-key eyJabc.def.ghi",
                          "code": "invalid_request", "status": 400},
                 "access_token": "must-not-retain"}
        redacted = transport.redact_diagnostic(value)
        self.assertEqual(redacted["error"]["code"], "invalid_request")
        self.assertEqual(redacted["error"]["status"], 400)
        self.assertIn("Unsupported schema", redacted["error"]["message"])
        for secret in ("synthetic-sensitive", "synthetic-api-key", "sk-test-key", "eyJabc.def.ghi", "must-not-retain"):
            self.assertNotIn(secret, json.dumps(redacted))

    def test_provider_json_encoded_error_exposes_type_status_and_message(self):
        value = {"error": {"message": json.dumps({"status": 400, "error": {
            "type": "invalid_request_error", "message": "A newer CLI is required."}})}}
        details = transport.provider_error_details(value)
        self.assertEqual(details["status"], 400)
        self.assertEqual(details["type"], "invalid_request_error")
        self.assertEqual(details["message"], "A newer CLI is required.")

    def test_resolver_selects_highest_version_and_skips_failed_version_probe(self):
        def version(path, env):
            if path == "bad":
                raise MemoryError("CLI_VERSION_UNRECOGNIZED")
            return transport._version_key("codex-cli " + {"old": "0.145.0", "new": "0.153.4"}[path])
        with patch.object(transport, "_path_candidates", return_value=["old", "bad", "new"]), \
             patch.object(transport, "_probe_version", side_effect=version) as probe:
            self.assertEqual(transport.resolve_executable(environ={}), ("new", "0.153.4"))
        self.assertEqual(probe.call_count, 3)

    def test_explicit_executable_precedes_environment_override_without_fallback(self):
        first = Path(self.temp.name) / "explicit.exe"
        second = Path(self.temp.name) / "environment.exe"
        first.touch(); second.touch()
        with patch.object(transport, "_probe_version", return_value=transport._version_key("codex-cli 0.145.0")) as probe, \
             patch.object(transport, "_path_candidates") as candidates:
            result = transport.resolve_executable(first, {"SPIRALMESH_CODEX_EXECUTABLE": str(second)})
            self.assertEqual(result, (str(first.resolve()), "0.145.0"))
            probe.assert_called_once()
            candidates.assert_not_called()
        with patch.object(transport, "_probe_version", side_effect=MemoryError("CLI_VERSION_PROBE_FAILED")), \
             patch.object(transport, "_path_candidates") as candidates:
            with self.assertRaisesRegex(MemoryError, "CLI_VERSION_PROBE_FAILED"):
                transport.resolve_executable(environ={"SPIRALMESH_CODEX_EXECUTABLE": str(second)})
            candidates.assert_not_called()

    def test_resolver_uses_environment_override_without_path_search(self):
        chosen = Path(self.temp.name) / "selected.exe"
        chosen.touch()
        with patch.object(transport, "_probe_version", return_value=transport._version_key("codex-cli 0.153.4")), \
             patch.object(transport, "_path_candidates") as candidates:
            self.assertEqual(transport.resolve_executable(environ={"SPIRALMESH_CODEX_EXECUTABLE": str(chosen)}),
                             (str(chosen.resolve()), "0.153.4"))
            candidates.assert_not_called()


if __name__ == "__main__":
    unittest.main()
