"""Trusted launcher CLI for local participant memory; JSON in, JSON out."""
from __future__ import annotations

import argparse
import json
import sys

from .mcp import MAX_INPUT, error_payload, result_ok, serve
from .store import MemoryError, MemoryLibrary, OPERATIONS, PRINCIPALS
from .export_files import write_export_file


def write(value):
    sys.stdout.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")
    sys.stdout.flush()


def main(argv=None):
    # Windows redirected stdio otherwise inherits a legacy code page. Reconfigure
    # only actual text streams; injected test streams need no special handling.
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="strict")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, help="Storage directory chosen by the trusted host")
    parser.add_argument("--principal", required=True, choices=sorted(PRINCIPALS))
    parser.add_argument("--instance-id", default="host")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init", help="Explicitly initialize this local storage directory")
    commands.add_parser("serve", help="Serve MCP on stdio; the database must already exist")
    call = commands.add_parser("call", help="Call one operation using JSON arguments from stdin")
    call.add_argument("operation", choices=OPERATIONS)
    export_file = commands.add_parser("export-file", help="Save a private export to a new host-selected file and verify its readback")
    export_file.add_argument("--output", required=True, help="New file in an existing directory; never overwritten")
    args = parser.parse_args(argv)
    try:
        library = MemoryLibrary(args.root, args.principal, args.instance_id,
                                create=args.command == "init")
        if args.command == "init":
            write({"ok": True, "status": "INITIALIZED", "principal": args.principal,
                   "origin": "local_launcher_asserted"})
            return 0
        if args.command == "serve":
            return serve(library)
        if args.command == "export-file":
            write(write_export_file(library.export(), args.output))
            return 0
        raw = sys.stdin.read(MAX_INPUT + 1)
        if len(raw) > MAX_INPUT or len(raw.encode("utf-8")) > MAX_INPUT:
            raise MemoryError("REQUEST_TOO_LARGE")
        try:
            arguments = json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (ValueError, TypeError):
            raise MemoryError("INVALID_JSON") from None
        # Exports are serialized here directly to UTF-8 stdout. No operation
        # accepts an export path or can rebind the launcher's principal/root.
        value = library.dispatch(args.operation, arguments)
        write(value)
        return 0 if result_ok(args.operation, value) else 1
    except Exception as error:
        write(error_payload(error))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
