"""Local Article 11 memory API, scoped to a principal by its trusted launcher.

Model-facing operations take identifiers and text, never filesystem paths or a
replacement principal. This is an application capability boundary, not a claim
that the host administrator cannot read the SQLite file.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import uuid


PROFILE = "spiralmesh.participant-memory.v1"
KINDS = {"observation", "reported", "inference", "decision", "question", "journal"}
PRINCIPALS = {"codex", "claude"}
MUTATIONS = ("remember", "correct", "share", "unshare", "forget", "set_letter", "send", "import_export")
INTEGRITY_SCHEMA_VERSION = 1


class MemoryError(ValueError):
    def __init__(self, code, details=None):
        super().__init__(code)
        self.code = code
        self.details = details or {"storage_outcome": "not_attempted", "persisted": False}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def string(value, name, maximum=200_000, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
        raise MemoryError("INVALID_" + name.upper())
    return value


class MemoryLibrary:
    """The caller binding is host-supplied, never accepted from tool arguments."""

    def __init__(self, root, principal, instance_id="host", create=False):
        if principal not in PRINCIPALS:
            raise MemoryError("UNKNOWN_PRINCIPAL")
        self.root = Path(root).resolve()
        self.path = self.root / "memory.sqlite3"
        self.principal = principal
        self.instance_id = string(instance_id, "instance", 200)
        if create:
            self.root.mkdir(parents=True, exist_ok=True)
            with self.db(write=True) as db:
                db.executescript("""
                CREATE TABLE IF NOT EXISTS notes(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  owner TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,
                  kind TEXT NOT NULL,sources TEXT NOT NULL,created_at TEXT NOT NULL,
                  instance_id TEXT NOT NULL,state TEXT NOT NULL,supersedes TEXT,
                  content_sha256 TEXT NOT NULL,origin TEXT NOT NULL DEFAULT '{}');
                CREATE TABLE IF NOT EXISTS grants(
                  note_id TEXT NOT NULL,recipient TEXT NOT NULL,
                  PRIMARY KEY(note_id,recipient));
                CREATE TABLE IF NOT EXISTS letters(owner TEXT PRIMARY KEY,note_id TEXT);
                CREATE TABLE IF NOT EXISTS messages(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  sender TEXT NOT NULL,recipient TEXT NOT NULL,subject TEXT NOT NULL,
                  body TEXT NOT NULL,created_at TEXT NOT NULL,instance_id TEXT NOT NULL,
                  correlation_id TEXT);
                CREATE TABLE IF NOT EXISTS receipts(
                  seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
                  principal TEXT NOT NULL,instance_id TEXT NOT NULL,at TEXT NOT NULL,
                  operation TEXT NOT NULL,refs TEXT NOT NULL,previous TEXT NOT NULL,
                  digest TEXT NOT NULL);
                """)
                self._ensure_integrity_schema(db)
        if not self.path.is_file():
            raise MemoryError("LIBRARY_NOT_INITIALIZED")

    @contextmanager
    def db(self, write=False):
        uri = self.path.as_uri() + ("?mode=rwc" if write else "?mode=ro")
        conn = sqlite3.connect(uri, uri=True, timeout=15)
        conn.row_factory = sqlite3.Row
        try:
            if write:
                conn.execute("PRAGMA secure_delete=ON")
                conn.execute("PRAGMA journal_mode=DELETE")
                conn.execute("BEGIN IMMEDIATE")
            yield conn
            if write:
                conn.commit()
        except BaseException:
            if write:
                conn.rollback()
            raise
        finally:
            conn.close()

    def _receipt(self, db, operation, refs):
        last = db.execute("SELECT digest FROM receipts ORDER BY seq DESC LIMIT 1").fetchone()
        record = {"id": "receipt_" + uuid.uuid4().hex, "principal": self.principal,
                  "instance_id": self.instance_id, "at": now(), "operation": operation,
                  "refs": refs, "previous": last[0] if last else ""}
        digest = sha(record)
        db.execute("INSERT INTO receipts(id,principal,instance_id,at,operation,refs,previous,digest) VALUES(?,?,?,?,?,?,?,?)",
                   (record["id"], self.principal, self.instance_id, record["at"], operation,
                    canonical(refs).decode(), record["previous"], digest))
        return {**record, "digest": digest, "origin": "local_launcher_asserted"}

    @staticmethod
    def _ensure_integrity_schema(db):
        # execute, not executescript: DDL participates in the caller transaction.
        db.execute("""CREATE TABLE IF NOT EXISTS continuity_operations(
            id TEXT PRIMARY KEY, principal TEXT NOT NULL, operation_id TEXT,
            operation TEXT NOT NULL, request_sha256 TEXT NOT NULL,
            result_json TEXT NOT NULL, effects_json TEXT NOT NULL,
            at TEXT NOT NULL, record_sha256 TEXT NOT NULL,
            UNIQUE(principal,operation_id))""")
        db.execute("""CREATE TABLE IF NOT EXISTS continuity_source_ids(
            principal TEXT NOT NULL, source_id TEXT NOT NULL, note_id TEXT NOT NULL,
            source_export_sha256 TEXT NOT NULL DEFAULT '',
            PRIMARY KEY(principal,source_id,note_id))""")

    @staticmethod
    def _has_table(db, name):
        return db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None

    def _operation(self, db, operation_id):
        if not self._has_table(db, "continuity_operations"):
            return None
        return db.execute("SELECT * FROM continuity_operations WHERE principal=? AND operation_id=?",
                          (self.principal, operation_id)).fetchone()

    def _source_ids(self, db, row):
        ids = {row["id"]}
        origin = json.loads(row["origin"])
        if isinstance(origin, dict) and isinstance(origin.get("record_id"), str):
            ids.add(string(origin["record_id"], "source_id", 100))
        if self._has_table(db, "continuity_source_ids"):
            ids.update(r[0] for r in db.execute(
                "SELECT source_id FROM continuity_source_ids WHERE principal=? AND note_id=?",
                (self.principal, row["id"])))
        return sorted(ids)

    def _capture(self, db, selectors):
        """Only IDs, state and commitments enter the durable operation record."""
        result = []
        for selector in selectors:
            kind, key = selector["kind"], selector["id"]
            if kind == "note":
                row = db.execute("SELECT * FROM notes WHERE id=? AND owner=?", (key, self.principal)).fetchone()
                value = dict(row) if row else None
                state = row["state"] if row else "missing"
            elif kind == "message":
                row = db.execute("SELECT * FROM messages WHERE id=? AND sender=?", (key, self.principal)).fetchone()
                value = dict(row) if row else None
                state = "available" if row else "missing"
            elif kind == "grants":
                value = [dict(r) for r in db.execute(
                    "SELECT g.* FROM grants g JOIN notes n ON n.id=g.note_id "
                    "WHERE g.note_id=? AND n.owner=? ORDER BY g.recipient", (key, self.principal))]
                state = "granted" if value else "revoked"
            elif kind == "letter":
                if key != self.principal:
                    raise MemoryError("OPERATION_BINDING_FAILED")
                row = db.execute("SELECT * FROM letters WHERE owner=?", (self.principal,)).fetchone()
                value = dict(row) if row else None
                state = "selected" if row and row["note_id"] else "cleared"
            elif kind == "source_ids":
                value = [dict(r) for r in db.execute(
                    "SELECT * FROM continuity_source_ids WHERE principal=? AND note_id=? ORDER BY source_id",
                    (self.principal, key))]
                state = "retained"
            else:
                raise MemoryError("OPERATION_BINDING_FAILED")
            result.append({"kind": kind, "id": key, "sha256": sha(value), "state": state})
        return result

    def _readback(self, operation_record_id, expected=None, replay=False):
        """Independent post-commit observation; a fault seam for inert tests."""
        with self.db() as db:
            row = db.execute("SELECT * FROM continuity_operations WHERE id=? AND principal=?",
                             (operation_record_id, self.principal)).fetchone()
            if row is None:
                raise MemoryError("COMMITTED_READBACK_UNAVAILABLE")
            record = dict(row)
            digest = record.pop("record_sha256")
            if sha(record) != digest or (expected is not None and digest != expected):
                raise MemoryError("OPERATION_BINDING_FAILED")
            result = json.loads(record["result_json"])
            receipt = result["receipt"]
            rr = db.execute("SELECT * FROM receipts WHERE id=? AND principal=?",
                            (receipt["id"], self.principal)).fetchone()
            if rr is None:
                raise MemoryError("COMMITTED_READBACK_UNAVAILABLE")
            receipt_record = {k: rr[k] for k in ("id", "principal", "instance_id", "at", "operation", "previous")}
            receipt_record["refs"] = json.loads(rr["refs"])
            if sha(receipt_record) != rr["digest"] or rr["digest"] != receipt["digest"]:
                raise MemoryError("RECEIPT_BINDING_FAILED")
            effects = json.loads(record["effects_json"])
            current = self._capture(db, effects)
        matching = current == effects
        # A replay/reconciliation reports the historical commit AND the current
        # effect. It never restores a revoked grant or forgotten/superseded note.
        return {**result, "ok": matching or replay,
                "storage_outcome": "committed" if matching or replay else "committed_effect_changed",
                "persisted": True, "readback_verified": matching or replay,
                "operation_id": record["operation_id"], "idempotent_replay": replay,
                "retry_protected": record["operation_id"] is not None,
                "current_effect": {"matches_original": matching, "observations": current},
                "result_scope": "historical_commit_with_current_effect"}

    @staticmethod
    def _uncertain(operation_id, replay=False):
        return {"ok": False, "storage_outcome": "write_outcome_unknown", "persisted": None,
                "readback_verified": False, "operation_id": operation_id,
                "idempotent_replay": replay, "retry_protected": operation_id is not None,
                "error": "COMMITTED_READBACK_UNAVAILABLE", "automatic_retry": False}

    def _mutate(self, operation, arguments, operation_id, apply):
        if operation_id is not None:
            string(operation_id, "operation_id", 200)
            if "\x00" in operation_id:
                raise MemoryError("INVALID_OPERATION_ID")
        try:
            request_digest = sha({"operation": operation, "arguments": arguments})
        except (ValueError, TypeError):
            raise MemoryError("INVALID_ARGUMENTS") from None
        entered = False
        replay = False
        try:
            # Existing-ID retries take a read-only fast path. The second lookup
            # under BEGIN IMMEDIATE below resolves simultaneous first callers.
            if operation_id is not None:
                with self.db() as db:
                    prior = self._operation(db, operation_id)
                if prior is not None:
                    if prior["operation"] != operation or prior["request_sha256"] != request_digest:
                        raise MemoryError("OPERATION_ID_CONFLICT")
                    try:
                        return self._readback(prior["id"], prior["record_sha256"], replay=True)
                    except (MemoryError, OSError, sqlite3.Error, ValueError, KeyError, TypeError):
                        return self._uncertain(operation_id, True)
            with self.db(write=True) as db:
                entered = True
                self._ensure_integrity_schema(db)
                prior = self._operation(db, operation_id) if operation_id is not None else None
                if prior is not None:
                    if prior["operation"] != operation or prior["request_sha256"] != request_digest:
                        raise MemoryError("OPERATION_ID_CONFLICT")
                    record_id, expected, replay = prior["id"], prior["record_sha256"], True
                else:
                    result, selectors = apply(db)
                    record = {"id": "operation_" + uuid.uuid4().hex, "principal": self.principal,
                              "operation_id": operation_id, "operation": operation,
                              "request_sha256": request_digest, "result_json": canonical(result).decode(),
                              "effects_json": canonical(self._capture(db, selectors)).decode(), "at": now()}
                    expected = sha(record)
                    record_id = record["id"]
                    db.execute("INSERT INTO continuity_operations VALUES(?,?,?,?,?,?,?,?,?)",
                               (*record.values(), expected))
        except MemoryError as exc:
            exc.details = {"storage_outcome": "rolled_back" if entered else "not_attempted",
                           "persisted": False, "operation_id": operation_id, "automatic_retry": False}
            raise
        except (sqlite3.Error, OSError):
            if not entered:
                raise MemoryError("LIBRARY_UNAVAILABLE", {"storage_outcome": "not_attempted",
                                  "persisted": False, "operation_id": operation_id}) from None
            return self._uncertain(operation_id, replay)
        try:
            return self._readback(record_id, expected, replay=replay)
        except (MemoryError, OSError, sqlite3.Error, ValueError, KeyError, TypeError):
            return self._uncertain(operation_id, replay)

    def reconcile(self, operation_id):
        """Observe an owner operation without schema creation, retry, or receipt writes."""
        string(operation_id, "operation_id", 200)
        try:
            with self.db() as db:
                prior = self._operation(db, operation_id)
            if prior is None:
                return {"ok": False, "storage_outcome": "not_recorded", "persisted": None,
                        "readback_verified": False, "operation_id": operation_id,
                        "idempotent_replay": False, "automatic_retry": False,
                        "note": "No owner-bound record was found. This is not proof that no effect occurred."}
            result = self._readback(prior["id"], prior["record_sha256"], replay=True)
            result.update(idempotent_replay=False, reconciled=True, automatic_retry=False)
            return result
        except (MemoryError, OSError, sqlite3.Error, ValueError, KeyError, TypeError):
            return self._uncertain(operation_id)

    def _note(self, db, note_id, owner_only=False, allow_forgotten=False):
        string(note_id, "note_id", 100)
        row = db.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        if row is None or (row["state"] == "forgotten" and
                           (not allow_forgotten or row["owner"] != self.principal)):
            raise MemoryError("NOT_FOUND")
        if row["owner"] != self.principal:
            allowed = not owner_only and db.execute(
                "SELECT 1 FROM grants WHERE note_id=? AND recipient IN (?, 'shared')",
                (note_id, self.principal)).fetchone()
            if not allowed:
                raise MemoryError("NOT_FOUND")
        return row

    @staticmethod
    def _view(row):
        result = dict(row)
        result["sources"] = json.loads(result["sources"])
        result["origin"] = json.loads(result["origin"])
        result["authority"] = "context_only"
        if result["state"] == "forgotten":
            result.update(title="", body="", sources=[], origin={}, record_kind="tombstone",
                          deleted_content_sha256=result["content_sha256"] or None,
                          digest_status="known" if result["content_sha256"] else "unknown")
        return result

    def browse(self, query="", scope="own", cursor=0, limit=50):
        string(query, "query", 1000, empty=True)
        if scope not in {"own", "shared", "all"}:
            raise MemoryError("INVALID_SCOPE")
        if type(cursor) is not int or cursor < 0 or type(limit) is not int or not 1 <= limit <= 200:
            raise MemoryError("INVALID_PAGE")
        # Pagination bounds one response, not access to the rest of the library.
        own = "n.owner=?"
        shared = "(n.state!='forgotten' AND EXISTS (SELECT 1 FROM grants g WHERE g.note_id=n.id AND g.recipient IN (?, 'shared')))"
        access = own if scope == "own" else shared if scope == "shared" else f"({own} OR {shared})"
        params = [self.principal] * (2 if scope == "all" else 1)
        with self.db() as db:
            rows = db.execute(f"SELECT n.* FROM notes n WHERE {access} "
                              "AND n.seq>? AND instr(lower(n.title||' '||n.body),lower(?))>0 ORDER BY n.seq LIMIT ?",
                              (*params, cursor, query, limit + 1)).fetchall()
        page = rows[:limit]
        return {"records": [{k: v for k, v in self._view(r).items() if k != "body"} for r in page],
                "next_cursor": page[-1]["seq"] if len(rows) > limit else None,
                "scope": scope, "complete_page": True,
                "note": "Read any listed id in full. Browse every page; the startup letter is not a recall boundary."}

    def successors(self, note_id):
        """Host-side read helper: ids of this owner's notes that supersede note_id.

        Correction puts `supersedes` on the NEW note, so resolving a stored
        reference forward to the current version requires a successor lookup.
        Owner-scoped and read-only. It returns every successor rather than
        picking one, so an ambiguous lineage can be refused by the caller
        instead of guessed at by timestamp. Not exposed as a model operation.
        """
        string(note_id, "note_id", 100)
        with self.db() as db:
            rows = db.execute(
                "SELECT id FROM notes WHERE owner=? AND supersedes=? ORDER BY seq",
                (self.principal, note_id)).fetchall()
        return [row["id"] for row in rows]

    def read(self, note_id, offset=None, limit=None):
        with self.db() as db:
            result = self._view(self._note(db, note_id, allow_forgotten=True))
        if offset is None and limit is None:
            return result
        start = 0 if offset is None else offset
        size = 8000 if limit is None else limit
        if type(start) is not int or start < 0 or type(size) is not int or not 1 <= size <= 200_000:
            raise MemoryError("INVALID_SLICE")
        body = result["body"]
        if start > len(body):
            raise MemoryError("INVALID_SLICE")
        end = min(len(body), start + size)
        result.update(body=body[start:end], offset=start, total_chars=len(body),
                      next_offset=end if end < len(body) else None,
                      slice_sha256=hashlib.sha256(body[start:end].encode("utf-8")).hexdigest(),
                      slice_basis="UTF-8 bytes of returned body; content_sha256 binds title/body/kind/sources")
        return result

    def _save(self, db, title, body, kind, sources, supersedes=None):
        string(title, "title", 300); string(body, "body")
        if kind not in KINDS:
            raise MemoryError("INVALID_KIND")
        if not isinstance(sources, list) or len(sources) > 100:
            raise MemoryError("INVALID_SOURCES")
        for source in sources:
            string(source, "source", 2000)
        content = {"title": title, "body": body, "kind": kind, "sources": sources}
        nid = "memory_" + uuid.uuid4().hex
        db.execute("INSERT INTO notes(id,owner,title,body,kind,sources,created_at,instance_id,state,supersedes,content_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (nid, self.principal, title, body, kind, canonical(sources).decode(), now(), self.instance_id,
                    "active", supersedes, sha(content)))
        return nid

    def remember(self, title, body, kind="observation", sources=None, operation_id=None):
        args = dict(title=title, body=body, kind=kind, sources=[] if sources is None else sources)
        def apply(db):
            nid = self._save(db, **args)
            receipt = self._receipt(db, "remember", [nid])
            return {"note_id": nid, "shared": False, "receipt": receipt}, [{"kind": "note", "id": nid}]
        return self._mutate("remember", args, operation_id, apply)

    def correct(self, note_id, title, body, kind="observation", sources=None, operation_id=None):
        args = dict(note_id=note_id, title=title, body=body, kind=kind, sources=[] if sources is None else sources)
        def apply(db):
            self._note(db, note_id, owner_only=True)
            nid = self._save(db, title, body, kind, [] if sources is None else sources, note_id)
            db.execute("UPDATE notes SET state='superseded' WHERE id=?", (note_id,))
            # A new version is private until deliberately shared. Existing grants
            # still expose the old version, now visibly marked superseded.
            db.execute("UPDATE letters SET note_id=? WHERE owner=? AND note_id=?", (nid, self.principal, note_id))
            receipt = self._receipt(db, "correct", [note_id, nid])
            return {"note_id": nid, "supersedes": note_id, "shared": False, "receipt": receipt}, [
                {"kind": "note", "id": note_id}, {"kind": "note", "id": nid},
                {"kind": "letter", "id": self.principal}]
        return self._mutate("correct", args, operation_id, apply)

    def share(self, note_id, recipient="shared", operation_id=None):
        if recipient not in PRINCIPALS | {"shared"}:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        def apply(db):
            self._note(db, note_id, owner_only=True)
            db.execute("INSERT OR IGNORE INTO grants VALUES(?,?)", (note_id, recipient))
            receipt = self._receipt(db, "share", [note_id, recipient])
            return {"note_id": note_id, "recipient": recipient, "receipt": receipt}, [
                {"kind": "note", "id": note_id}, {"kind": "grants", "id": note_id}]
        return self._mutate("share", dict(note_id=note_id, recipient=recipient), operation_id, apply)

    def unshare(self, note_id, recipient="shared", operation_id=None):
        if recipient not in PRINCIPALS | {"shared"}:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        def apply(db):
            self._note(db, note_id, owner_only=True)
            db.execute("DELETE FROM grants WHERE note_id=? AND recipient=?", (note_id, recipient))
            receipt = self._receipt(db, "unshare", [note_id, recipient])
            return {"receipt": receipt, "limit": "Already read or exported copies cannot be recalled."}, [
                {"kind": "grants", "id": note_id}]
        return self._mutate("unshare", dict(note_id=note_id, recipient=recipient), operation_id, apply)

    def forget(self, note_id, operation_id=None):
        def apply(db):
            row = self._note(db, note_id, owner_only=True, allow_forgotten=True)
            for source_id in self._source_ids(db, row):
                db.execute("INSERT OR IGNORE INTO continuity_source_ids(principal,source_id,note_id) VALUES(?,?,?)",
                           (self.principal, source_id, note_id))
            db.execute("DELETE FROM grants WHERE note_id=?", (note_id,))
            db.execute("DELETE FROM letters WHERE owner=? AND note_id=?", (self.principal, note_id))
            db.execute("UPDATE notes SET title='',body='',sources='[]',origin='{}',state='forgotten' WHERE id=?", (note_id,))
            receipt = self._receipt(db, "forget", [note_id])
            result = {"forgotten": note_id, "receipt": receipt,
                      "deleted_content_sha256": row["content_sha256"] or None,
                      "digest_status": "known" if row["content_sha256"] else "unknown",
                      "limit": "Clears this live record and revokes access. Separate versions, messages, exports, logs, backups and device remnants are not erased. A digest is a commitment, not encryption."}
            return result, [{"kind": "note", "id": note_id}, {"kind": "grants", "id": note_id},
                            {"kind": "letter", "id": self.principal}, {"kind": "source_ids", "id": note_id}]
        return self._mutate("forget", dict(note_id=note_id), operation_id, apply)

    def set_letter(self, note_id, operation_id=None):
        def apply(db):
            if note_id is not None:
                self._note(db, note_id, owner_only=True)
            db.execute("INSERT OR REPLACE INTO letters VALUES(?,?)", (self.principal, note_id))
            receipt = self._receipt(db, "set_letter", [] if note_id is None else [note_id])
            return {"letter": note_id, "receipt": receipt}, [{"kind": "letter", "id": self.principal}]
        return self._mutate("set_letter", dict(note_id=note_id), operation_id, apply)

    def resume(self, limit=8):
        """One read transaction of recent visible metadata, never a recall fence."""
        if type(limit) is not int or not 1 <= limit <= 20:
            raise MemoryError("INVALID_LIMIT")
        try:
            # mode=ro can still create WAL sidecars. This store normally uses
            # DELETE journaling; refuse a foreign WAL layout
            # instead of treating immutable=1 as a safe current snapshot.
            with self.path.open("rb") as source:
                header = source.read(20)
            if len(header) < 20 or header[:16] != b"SQLite format 3\x00":
                raise MemoryError("LIBRARY_CORRUPT")
            if any(Path(str(self.path) + suffix).exists() for suffix in ("-wal", "-shm")) or 2 in header[18:20]:
                raise MemoryError("RESUME_WAL_NOT_SUPPORTED")
            if header[18:20] != b"\x01\x01":
                raise MemoryError("LIBRARY_CORRUPT")
            with self.db() as db:
                db.execute("BEGIN")
                visible = ("(n.owner=? OR (n.owner!=? AND n.state!='forgotten' AND EXISTS "
                           "(SELECT 1 FROM grants g WHERE g.note_id=n.id AND g.recipient IN (?, 'shared'))))")
                bound = (self.principal,) * 3
                counts = {"own_active": 0, "own_superseded": 0, "own_forgotten": 0,
                          "visible_shared": 0}
                for row in db.execute(f"SELECT n.owner,n.state,COUNT(*) AS count FROM notes n WHERE {visible} GROUP BY n.owner,n.state", bound):
                    if row["owner"] not in PRINCIPALS or row["state"] not in {"active", "superseded", "forgotten"}:
                        raise MemoryError("LIBRARY_CORRUPT")
                    key = "own_" + row["state"] if row["owner"] == self.principal else "visible_shared"
                    counts[key] += row["count"]
                counts["visible_notes"] = sum(counts.values())
                columns = "n.id,n.owner,n.title,n.kind,n.created_at,n.state,n.content_sha256"

                def note_metadata(row):
                    result = dict(row)
                    result["visibility"] = "own" if row["owner"] == self.principal else "shared"
                    if row["state"] == "forgotten":
                        result.update(title="", record_kind="tombstone",
                                      deleted_content_sha256=row["content_sha256"] or None,
                                      digest_status="known" if row["content_sha256"] else "unknown")
                    return result

                selected = db.execute("SELECT note_id FROM letters WHERE owner=?", (self.principal,)).fetchone()
                letter = None
                if selected is not None and selected["note_id"] is not None:
                    row = db.execute(f"SELECT {columns} FROM notes n WHERE n.id=? AND n.owner=? AND n.state IN ('active','superseded')",
                                     (selected["note_id"], self.principal)).fetchone()
                    if row is None:
                        raise MemoryError("STARTER_LETTER_UNAVAILABLE")
                    letter = note_metadata(row)
                rows = db.execute(f"SELECT {columns} FROM notes n WHERE {visible} ORDER BY n.seq DESC LIMIT ?",
                                  (*bound, limit)).fetchall()
                notes = [note_metadata(row) for row in rows]
                counts["sent_messages"] = db.execute("SELECT COUNT(*) FROM messages WHERE sender=?", (self.principal,)).fetchone()[0]
                counts["received_messages"] = db.execute("SELECT COUNT(*) FROM messages WHERE recipient=?", (self.principal,)).fetchone()[0]
                message_count = db.execute("SELECT COUNT(*) FROM messages WHERE sender=? OR recipient=?",
                                           (self.principal, self.principal)).fetchone()[0]
                messages = [dict(row) for row in db.execute(
                    "SELECT id,sender,recipient,subject,created_at,correlation_id FROM messages "
                    "WHERE sender=? OR recipient=? ORDER BY seq DESC LIMIT ?", (self.principal, self.principal, limit))]
        except MemoryError:
            raise
        except (OSError, sqlite3.Error, ValueError, TypeError, KeyError):
            raise MemoryError("LIBRARY_UNAVAILABLE") from None
        return {"profile": PROFILE, "principal": self.principal, "starter_letter": letter,
                "counts": counts, "recent_notes": notes, "recent_messages": messages,
                "limit": limit, "notes_truncated": counts["visible_notes"] > len(notes),
                "messages_truncated": message_count > len(messages),
                "selection_order": "local_sequence_desc", "snapshot_scope": "recent_visible_metadata_not_full_catalog",
                "full_store_access": True, "authority": "context_only", "actions_executed": 0,
                "read_only": True, "unread_status": "not_tracked",
                "api_hints": {
                    "boot": {"arguments": {}, "purpose": "Read the optional starter letter body and access offer."},
                    "browse": {"arguments": {"scope": "all", "cursor": 0, "limit": 50},
                               "purpose": "Browse every visible note page. Follow browse's own next_cursor; this snapshot has no continuation cursor."},
                    "read": {"arguments": {"note_id": "<visible note id>"}, "purpose": "Read full text, or use offset/limit slices."},
                    "inbox": {"arguments": {"cursor": 0, "limit": 50}, "purpose": "Browse all sent/received pages using inbox's own next_cursor."},
                    "message": {"arguments": {"message_id": "<visible message id>"}, "purpose": "Read a selected sent or received message body."}}}

    def boot(self):
        with self.db() as db:
            row = db.execute("SELECT note_id FROM letters WHERE owner=?", (self.principal,)).fetchone()
            letter = self._view(self._note(db, row[0], owner_only=True)) if row and row[0] else None
            count = db.execute("SELECT COUNT(*) FROM notes WHERE owner=? AND state!='forgotten'", (self.principal,)).fetchone()[0]
        return {"profile": PROFILE, "principal": self.principal, "instance_id": self.instance_id,
                "offer": letter, "own_record_count": count, "inheritance": "offer_not_identity_or_authority",
                "choices": ["accept", "question", "decline"], "full_store_access": True,
                "instruction": "Your letter is optional context. All retained owner records remain browsable and readable; you may form new memories or decline."}

    def send(self, recipient, subject, body, correlation_id=None, operation_id=None):
        if recipient not in PRINCIPALS or recipient == self.principal:
            raise MemoryError("RECIPIENT_NOT_AUTHORIZED")
        string(subject, "subject", 300); string(body, "body")
        if correlation_id is not None:
            string(correlation_id, "correlation", 100)
        def apply(db):
            if correlation_id is not None:
                self._message(db, correlation_id)
            mid = "message_" + uuid.uuid4().hex
            db.execute("INSERT INTO messages(id,sender,recipient,subject,body,created_at,instance_id,correlation_id) VALUES(?,?,?,?,?,?,?,?)",
                       (mid, self.principal, recipient, subject, body, now(), self.instance_id, correlation_id))
            receipt = self._receipt(db, "send", [mid, recipient])
            return {"message_id": mid, "status": "available_in_local_inbox", "receipt": receipt}, [
                {"kind": "message", "id": mid}]
        return self._mutate("send", dict(recipient=recipient, subject=subject, body=body,
                                         correlation_id=correlation_id), operation_id, apply)

    def _message(self, db, message_id):
        row = db.execute("SELECT * FROM messages WHERE id=? AND (sender=? OR recipient=?)",
                         (message_id, self.principal, self.principal)).fetchone()
        if row is None:
            raise MemoryError("NOT_FOUND")
        return row

    def message(self, message_id):
        string(message_id, "message_id", 100)
        with self.db() as db:
            return dict(self._message(db, message_id))

    def inbox(self, cursor=0, limit=50):
        if type(cursor) is not int or cursor < 0 or type(limit) is not int or not 1 <= limit <= 200:
            raise MemoryError("INVALID_PAGE")
        with self.db() as db:
            rows = db.execute("SELECT * FROM messages WHERE (sender=? OR recipient=?) AND seq>? ORDER BY seq LIMIT ?",
                              (self.principal, self.principal, cursor, limit + 1)).fetchall()
        return {"messages": [{k: v for k, v in dict(r).items() if k != "body"} for r in rows[:limit]],
                "next_cursor": rows[limit - 1]["seq"] if len(rows) > limit else None}

    def export(self):
        with self.db() as db:
            own = []
            for row in db.execute("SELECT * FROM notes WHERE owner=? ORDER BY seq", (self.principal,)):
                view = self._view(row)
                view["source_record_ids"] = self._source_ids(db, row)
                own.append(view)
            shared = [self._view(r) for r in db.execute("SELECT n.* FROM notes n WHERE n.owner!=? AND n.state!='forgotten' AND EXISTS(SELECT 1 FROM grants g WHERE g.note_id=n.id AND g.recipient IN (?, 'shared')) ORDER BY seq", (self.principal, self.principal))]
            messages = [dict(r) for r in db.execute("SELECT * FROM messages WHERE sender=? OR recipient=? ORDER BY seq", (self.principal, self.principal))]
        payload = {"profile": PROFILE, "principal": self.principal, "exported_at": now(),
                   "own": own, "shared": shared, "messages": messages, "letter": self.boot()["offer"],
                   "authority": "context_only", "origin": "local_launcher_asserted"}
        return {"payload": payload, "sha256": sha(payload),
                "verification_limit": "Digest detects changes relative to this export; it does not authenticate authorship or truth."}

    def import_export(self, bundle, operation_id=None):
        if not isinstance(bundle, dict) or set(bundle) != {"payload", "sha256", "verification_limit"}:
            raise MemoryError("INVALID_EXPORT")
        p = bundle["payload"]
        if not isinstance(p, dict) or sha(p) != bundle["sha256"] or p.get("profile") != PROFILE or p.get("principal") != self.principal:
            raise MemoryError("EXPORT_BINDING_FAILED")
        # Only the owner's records enter the owner store. Shared records/messages
        # remain portable evidence in the export, never imported as new authorship.
        if not isinstance(p.get("own"), list):
            raise MemoryError("INVALID_EXPORT_RECORD")
        def apply(db):
            mapping = {}
            for note in p["own"]:
                if not isinstance(note, dict):
                    raise MemoryError("INVALID_EXPORT_RECORD")
                if note.get("owner") != self.principal:
                    raise MemoryError("EXPORT_OWNER_MISMATCH")
                source_id = string(note.get("id"), "source_id", 100)
                if source_id in mapping or note.get("state") not in {"active", "superseded", "forgotten"}:
                    raise MemoryError("INVALID_EXPORT_RECORD")
                aliases = note.get("source_record_ids", [source_id])
                if not isinstance(aliases, list) or len(aliases) > 1000:
                    raise MemoryError("INVALID_SOURCE_IDS")
                aliases = set(string(x, "source_id", 100) for x in aliases) | {source_id}
                origin = note.get("origin", {})
                if not isinstance(origin, dict):
                    raise MemoryError("INVALID_EXPORT_RECORD")
                if origin.get("record_id") is not None:
                    aliases.add(string(origin["record_id"], "source_id", 100))
                forgotten = note["state"] == "forgotten"
                if not forgotten:
                    for alias in aliases:
                        direct = db.execute("SELECT 1 FROM notes WHERE owner=? AND id=? AND state='forgotten'",
                                            (self.principal, alias)).fetchone()
                        imported = db.execute(
                            "SELECT 1 FROM continuity_source_ids s JOIN notes n ON n.id=s.note_id "
                            "WHERE s.principal=? AND s.source_id=? AND n.owner=? AND n.state='forgotten'",
                            (self.principal, alias, self.principal)).fetchone()
                        # Covers pre-upgrade imports whose compact origin survives;
                        # no historic or private backup retrieval is involved.
                        legacy = any(json.loads(r[0]).get("record_id") == alias for r in db.execute(
                            "SELECT origin FROM notes WHERE owner=? AND state='forgotten'", (self.principal,)))
                        if direct or imported or legacy:
                            raise MemoryError("IMPORT_WOULD_RESURRECT_FORGOTTEN")
                content_digest = note.get("content_sha256")
                if forgotten:
                    if (note.get("title") != "" or note.get("body") != "" or note.get("sources") != []
                            or origin or not isinstance(content_digest, str)
                            or (content_digest and (len(content_digest) != 64 or any(c not in "0123456789abcdef" for c in content_digest)))
                            or note.get("deleted_content_sha256", content_digest or None) != (content_digest or None)
                            or note.get("kind") not in KINDS):
                        raise MemoryError("INVALID_TOMBSTONE")
                    nid = "memory_" + uuid.uuid4().hex
                    db.execute("INSERT INTO notes(id,owner,title,body,kind,sources,created_at,instance_id,state,supersedes,content_sha256,origin) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                               (nid, self.principal, "", "", note["kind"], "[]", now(), self.instance_id,
                                "forgotten", None, content_digest, "{}"))
                else:
                    try:
                        content = {k: note[k] for k in ("title", "body", "kind", "sources")}
                    except KeyError:
                        raise MemoryError("INVALID_EXPORT_RECORD") from None
                    if sha(content) != content_digest:
                        raise MemoryError("EXPORT_CONTENT_MISMATCH")
                    nid = self._save(db, **content)
                    new_origin = {"export_sha256": bundle["sha256"], "record_id": source_id,
                                  "instance_id": note.get("instance_id"), "created_at": note.get("created_at")}
                    db.execute("UPDATE notes SET origin=? WHERE id=?", (canonical(new_origin).decode(), nid))
                for alias in aliases:
                    db.execute("INSERT INTO continuity_source_ids VALUES(?,?,?,?)",
                               (self.principal, alias, nid, bundle["sha256"]))
                mapping[source_id] = nid
            for note in p["own"]:
                if note.get("supersedes") in mapping:
                    db.execute("UPDATE notes SET supersedes=? WHERE id=?", (mapping[note["supersedes"]], mapping[note["id"]]))
                if note.get("state") == "superseded":
                    db.execute("UPDATE notes SET state='superseded' WHERE id=?", (mapping[note["id"]],))
            if p.get("letter") and p["letter"].get("id") in mapping:
                letter_id = mapping[p["letter"]["id"]]
                self._note(db, letter_id, owner_only=True)
                db.execute("INSERT OR REPLACE INTO letters VALUES(?,?)", (self.principal, letter_id))
            receipt = self._receipt(db, "import_export", list(mapping.values()))
            selectors = [{"kind": kind, "id": nid} for nid in mapping.values() for kind in ("note", "source_ids")]
            selectors.append({"kind": "letter", "id": self.principal})
            return {"imported": mapping, "receipt": receipt, "shared_republished": False}, selectors
        return self._mutate("import_export", {"bundle": bundle}, operation_id, apply)

    def dispatch(self, operation, arguments):
        if operation not in OPERATIONS or not isinstance(arguments, dict):
            raise MemoryError("UNKNOWN_OPERATION")
        import inspect
        target = getattr(self, operation)
        try:
            inspect.signature(target).bind(**arguments)
        except TypeError as e:
            raise MemoryError("INVALID_ARGUMENTS") from e
        return target(**arguments)


OPERATIONS = ("boot", "resume", "browse", "read", "remember", "correct", "share", "unshare", "forget",
              "set_letter", "send", "message", "inbox", "export", "import_export", "reconcile")


def verify_export(bundle):
    return isinstance(bundle, dict) and isinstance(bundle.get("payload"), dict) and sha(bundle["payload"]) == bundle.get("sha256")
