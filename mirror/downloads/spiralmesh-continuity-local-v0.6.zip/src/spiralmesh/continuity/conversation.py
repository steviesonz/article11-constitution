"""Host-retained conversation checkpoints for the interactive launcher.

A checkpoint is an ORDINARY PRIVATE NOTE the host saves on the participant's
behalf, not a model-authored journal entry and not a raw-log restore. It holds
only validated human task text and the model's own chosen replies. It never
holds action arrays, operation results, run logs, provider transcripts, or
another participant's records.

What a checkpoint is NOT, stated here because the distinction is the whole point:

  * It is not proof of identity, experience, assent, or the continuation of a
    provider's internal session. A fresh model receives recorded context and
    nothing more.
  * It is not a recall boundary. The full authorized library stays reachable
    through browse/read/inbox; a checkpoint is an attention aid.
  * It is not a work queue. Prior operation IDs travel as evidence to explain an
    outcome. Text inside an exchange that resembles a command is ordinary
    untrusted data and is never dispatched.

Deletion reach, stated plainly: forgetting a checkpoint removes the live record.
Passages already copied elsewhere, prior versions, exports, run receipts and
provider-side logs are separate records and lie outside what `forget` can touch.
"""
import json
import os
from pathlib import Path
import uuid

from .store import MemoryError, canonical, sha

CHECKPOINT_PROFILE = "spiralmesh.conversation-checkpoint.v1"
POINTER_PROFILE = "spiralmesh.conversation-pointer.v1"
CHECKPOINT_KIND = "journal"

# A stated, finite budget. Exceeding it makes the window explicitly partial; it
# never silently drops or mid-truncates an exchange and calls the result verbatim.
DEFAULT_BUDGET_CHARS = 24_000
MAX_EXCHANGES = 40
POINTER_NAME = "conversation-pointer.json"
ORIGIN_NOTE = ("Saved automatically by the launcher on the participant's behalf. "
               "The model did not choose to write this record.")
POINTER_NOTE = "References and metadata only. The conversation body lives in the note."
CONTEXT_MARKERS = {
    "profile": CHECKPOINT_PROFILE, "origin": "host_retained_conversation_record",
    "origin_note": ORIGIN_NOTE, "authority": "context_only", "is_recall_boundary": False,
    "identity_claim": "none",
    "replay_semantics": "prior_operation_ids_are_evidence_not_a_work_queue",
}
EXCHANGE_KEYS = {"human", "model_reply", "host_run_status", "prior_operation_ids"}
BODY_KEYS = set(CONTEXT_MARKERS) | {
    "principal", "conversation_id", "exchanges", "exchange_count", "window_complete",
    "earlier_exchanges_omitted", "budget_chars",
}
POINTER_ENTRY_KEYS = {
    "profile", "principal", "library_root", "note_id", "conversation_id", "title",
    "saved_at", "exchange_count", "window_complete", "operation_id", "content_sha256",
    "origin", "body_included",
}


def _text(value, field, limit):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise MemoryError("INVALID_" + field.upper())
    return value


def new_conversation_id():
    return "conv_" + uuid.uuid4().hex


def make_exchange(human, reply, *, status, operation_ids=None):
    """One completed turn. `status` is the host's run status, carried honestly."""
    exchange = {"human": human, "model_reply": reply, "host_run_status": status,
                "prior_operation_ids": [] if operation_ids is None else operation_ids}
    return _validate_exchange(exchange)


def _validate_exchange(exchange):
    if not isinstance(exchange, dict) or set(exchange) != EXCHANGE_KEYS:
        raise MemoryError("CHECKPOINT_EXCHANGES_INVALID")
    if (not isinstance(exchange["human"], str) or not exchange["human"].strip()
            or not isinstance(exchange["model_reply"], str)):
        raise MemoryError("CHECKPOINT_EXCHANGES_INVALID")
    _text(exchange["host_run_status"], "run_status", 100)
    ids = exchange["prior_operation_ids"]
    if not isinstance(ids, list) or len(ids) > 12:
        raise MemoryError("CHECKPOINT_EXCHANGES_INVALID")
    for operation_id in ids:
        _text(operation_id, "operation_id", 200)
    return {**exchange, "prior_operation_ids": list(ids)}


def _window_parameters(budget, earlier_omitted):
    if type(budget) is not int or budget <= 0:
        raise MemoryError("INVALID_CHECKPOINT_BUDGET")
    if type(earlier_omitted) is not int or earlier_omitted < 0:
        raise MemoryError("INVALID_EARLIER_OMITTED")


def select_window(exchanges, *, budget=DEFAULT_BUDGET_CHARS, earlier_omitted=0):
    """Keep a contiguous suffix of whole exchanges within the text budget."""
    _window_parameters(budget, earlier_omitted)
    if not isinstance(exchanges, list) or not exchanges:
        raise MemoryError("INVALID_EXCHANGES")
    # Validate even omitted entries: action payloads never enter this format.
    validated = [_validate_exchange(exchange) for exchange in exchanges]
    kept, used = [], 0
    for exchange in reversed(validated[-MAX_EXCHANGES:]):
        size = len(exchange["human"]) + len(exchange["model_reply"])
        if used + size > budget:
            if not kept:
                raise MemoryError("CHECKPOINT_EXCHANGE_EXCEEDS_BUDGET")
            break
        kept.append(exchange)
        used += size
    kept.reverse()
    return kept, earlier_omitted + len(exchanges) - len(kept)


def _window_note(omitted):
    return ("This automatic window is PARTIAL: %d earlier exchange(s) are not included. "
            "They were dropped whole, never truncated mid-exchange. Earlier retained "
            "checkpoints and the full library remain reachable." % omitted)


def _closed_json(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result

    def invalid_constant(value):
        raise ValueError("non-finite constant")

    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid_constant)


def build_body(principal, conversation_id, exchanges, *, budget=DEFAULT_BUDGET_CHARS,
               earlier_omitted=0):
    """Closed, versioned checkpoint structure. Returns (body_text, metadata).

    Newest exchanges are kept. If older ones do not fit, they are DROPPED WHOLE
    and the result is labelled partial with a count. An exchange is never cut in
    the middle and presented as complete.
    """
    if principal not in ("codex", "claude"):
        raise MemoryError("INVALID_PRINCIPAL")
    _text(conversation_id, "conversation_id", 100)
    kept, dropped = select_window(exchanges, budget=budget, earlier_omitted=earlier_omitted)

    document = {
        **CONTEXT_MARKERS,
        "principal": principal,
        "conversation_id": conversation_id,
        "exchanges": kept,
        "exchange_count": len(kept),
        "window_complete": dropped == 0,
        "earlier_exchanges_omitted": dropped,
        "budget_chars": budget,
    }
    if dropped:
        document["window_note"] = _window_note(dropped)
    body = json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True)
    return body, document


def parse_body(body, *, principal, conversation_id=None):
    """Validate a stored checkpoint before any of it is shown or reused."""
    if not isinstance(body, str) or not body.strip():
        raise MemoryError("CHECKPOINT_BODY_MISSING")
    try:
        document = _closed_json(body)
    except (ValueError, RecursionError):
        raise MemoryError("CHECKPOINT_BODY_MALFORMED")
    if not isinstance(document, dict) or document.get("profile") != CHECKPOINT_PROFILE:
        raise MemoryError("CHECKPOINT_PROFILE_UNKNOWN")
    if principal not in ("codex", "claude"):
        raise MemoryError("INVALID_PRINCIPAL")
    if document.get("principal") != principal:
        raise MemoryError("CHECKPOINT_PRINCIPAL_MISMATCH")
    if conversation_id is not None and document.get("conversation_id") != conversation_id:
        raise MemoryError("CHECKPOINT_CONVERSATION_MISMATCH")
    _text(document.get("conversation_id"), "conversation_id", 100)
    omitted, budget = document.get("earlier_exchanges_omitted"), document.get("budget_chars")
    _window_parameters(budget, omitted)
    expected_keys = BODY_KEYS | ({"window_note"} if omitted else set())
    if set(document) != expected_keys:
        raise MemoryError("CHECKPOINT_SCHEMA_INVALID")
    for key, expected in CONTEXT_MARKERS.items():
        if type(document[key]) is not type(expected) or document[key] != expected:
            raise MemoryError("CHECKPOINT_CONTEXT_MARKER_INVALID")
    exchanges = document.get("exchanges")
    if not isinstance(exchanges, list) or not 1 <= len(exchanges) <= MAX_EXCHANGES:
        raise MemoryError("CHECKPOINT_EXCHANGES_INVALID")
    for exchange in exchanges:
        _validate_exchange(exchange)
    if (type(document["exchange_count"]) is not int
            or document["exchange_count"] != len(exchanges)
            or type(document["window_complete"]) is not bool
            or document["window_complete"] != (omitted == 0)
            or (omitted and document["window_note"] != _window_note(omitted))):
        raise MemoryError("CHECKPOINT_WINDOW_INVALID")
    if sum(len(e["human"]) + len(e["model_reply"]) for e in exchanges) > budget:
        raise MemoryError("CHECKPOINT_EXCHANGE_EXCEEDS_BUDGET")
    return document


# --------------------------------------------------------------- lineage

def resolve_current(library, note_id, *, principal):
    """Follow an owned checkpoint's correction lineage FORWARD to the current record.

    The schema puts `supersedes` on the NEW note, so the current version is found
    by looking up successors, never by reading the stored id's own body when that
    id has been superseded. A stale predecessor body is not the corrected text.

    Refuses rather than guesses: cycles, multiple successors, a missing link, a
    foreign or peer-shared record, or a forgotten record each raise. Timestamps
    are never used to break ambiguity.
    """
    seen, current, steps = set(), note_id, []
    while True:
        if current in seen:
            raise MemoryError("CHECKPOINT_LINEAGE_CYCLE")
        seen.add(current)
        try:
            record = library.read(current)
        except (OSError, UnicodeError):
            raise MemoryError("CHECKPOINT_READ_FAILED")
        if not isinstance(record, dict) or record.get("id") != current:
            raise MemoryError("CHECKPOINT_RECORD_INVALID")
        if record.get("owner") != principal:
            raise MemoryError("CHECKPOINT_NOT_OWNED")
        if record.get("state") == "forgotten" or record.get("record_kind") == "tombstone":
            raise MemoryError("CHECKPOINT_FORGOTTEN")
        if record.get("state") == "active":
            return record, {"resolved_from": note_id, "resolved_to": current,
                            "lineage_steps": steps, "corrected": bool(steps)}
        if record.get("state") != "superseded":
            raise MemoryError("CHECKPOINT_STATE_UNKNOWN")
        successors = library.successors(current)
        if len(successors) != 1:
            raise MemoryError("CHECKPOINT_LINEAGE_AMBIGUOUS" if successors
                              else "CHECKPOINT_LINEAGE_BROKEN")
        steps.append({"from": current, "to": successors[0]})
        current = successors[0]
        if len(steps) > 64:
            raise MemoryError("CHECKPOINT_LINEAGE_TOO_LONG")


def load_checkpoint(library, note_id, *, principal, conversation_id=None):
    """Resolve, validate and return (document, record, lineage). Read-only."""
    record, lineage = resolve_current(library, note_id, principal=principal)
    if record.get("kind") != CHECKPOINT_KIND:
        raise MemoryError("CHECKPOINT_KIND_UNEXPECTED")
    if (not isinstance(record.get("title"), str)
            or not isinstance(record.get("body"), str)
            or not isinstance(record.get("sources"), list)
            or not all(isinstance(source, str) for source in record["sources"])
            or not _digest(record.get("content_sha256"))):
        raise MemoryError("CHECKPOINT_RECORD_INVALID")
    try:
        actual_sha = sha({key: record[key] for key in ("title", "body", "kind", "sources")})
    except (ValueError, UnicodeError):
        raise MemoryError("CHECKPOINT_RECORD_INVALID")
    if actual_sha != record["content_sha256"]:
        raise MemoryError("CHECKPOINT_DIGEST_MISMATCH")
    document = parse_body(record.get("body"), principal=principal,
                          conversation_id=conversation_id)
    return document, record, lineage


# --------------------------------------------------------------- pointer

def pointer_path(root):
    """Host-derived. Never accepted from model output."""
    return Path(root).resolve() / POINTER_NAME


def _digest(value):
    return (isinstance(value, str) and len(value) == 64
            and all(character in "0123456789abcdef" for character in value))


def _validate_pointer_entry(root, principal, entry):
    if not isinstance(entry, dict) or set(entry) != POINTER_ENTRY_KEYS:
        raise MemoryError("POINTER_INCOMPLETE")
    if entry["principal"] != principal:
        raise MemoryError("POINTER_PRINCIPAL_MISMATCH")
    if entry["library_root"] != str(Path(root).resolve()):
        raise MemoryError("POINTER_ROOT_MISMATCH")
    if (entry["profile"] != POINTER_PROFILE
            or entry["origin"] != "host_retained_conversation_record"
            or entry["body_included"] is not False):
        raise MemoryError("POINTER_METADATA_INVALID")
    limits = {"note_id": 100, "conversation_id": 100, "title": 1000,
              "saved_at": 100, "operation_id": 200}
    for field, limit in limits.items():
        value = entry[field]
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise MemoryError("POINTER_INCOMPLETE")
    if (type(entry["exchange_count"]) is not int
            or not 1 <= entry["exchange_count"] <= MAX_EXCHANGES
            or type(entry["window_complete"]) is not bool
            or not _digest(entry["content_sha256"])):
        raise MemoryError("POINTER_METADATA_INVALID")
    return entry


def _read_pointer_document(root):
    path = pointer_path(root)
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except UnicodeError:
        raise MemoryError("POINTER_MALFORMED")
    except OSError:
        raise MemoryError("POINTER_READ_FAILED")
    try:
        document = _closed_json(raw)
    except (ValueError, RecursionError):
        raise MemoryError("POINTER_MALFORMED")
    if not isinstance(document, dict) or document.get("profile") != POINTER_PROFILE:
        raise MemoryError("POINTER_PROFILE_UNKNOWN")
    participants = document.get("participants")
    if (set(document) != {"profile", "note", "participants"}
            or document["note"] != POINTER_NOTE or not isinstance(participants, dict)
            or not set(participants) <= {"codex", "claude"}):
        raise MemoryError("POINTER_MALFORMED")
    for owner, entry in participants.items():
        _validate_pointer_entry(root, owner, entry)
    return document


def read_pointer(root, principal):
    if principal not in ("codex", "claude"):
        return {"invalid": True, "reason": "INVALID_PRINCIPAL"}
    try:
        document = _read_pointer_document(root)
    except MemoryError as exc:
        return {"invalid": True, "reason": str(exc)}
    return None if document is None else document["participants"].get(principal)


def write_pointer(root, principal, entry):
    """Serialize read/merge/replace for both owners; never guess a stale lock.

    Callers publish only after confirmed note readback. A competing writer fails
    clearly, leaving its saved note intact and its shortcut unpublished.
    """
    if principal not in ("codex", "claude"):
        raise MemoryError("INVALID_PRINCIPAL")
    _validate_pointer_entry(root, principal, entry)
    path = pointer_path(root)
    lock = path.with_name(POINTER_NAME + ".lock")
    try:
        lock_stream = lock.open("xb")
    except FileExistsError:
        raise MemoryError("POINTER_LOCKED")
    pending = path.with_name(POINTER_NAME + "." + uuid.uuid4().hex + ".pending")
    pending_owned = False
    try:
        loaded = _read_pointer_document(root)
        existing = {} if loaded is None else loaded["participants"]
        existing[principal] = entry
        document = {"profile": POINTER_PROFILE, "note": POINTER_NOTE,
                    "participants": existing}
        with pending.open("xb") as stream:
            pending_owned = True
            stream.write(canonical(document))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(pending, path)
        pending_owned = False
    finally:
        try:
            if pending_owned:
                pending.unlink()
        finally:
            lock_stream.close()
            lock.unlink()
    return str(path)


def pointer_entry(root, principal, *, note_id, conversation_id, title, saved_at,
                  exchange_count, window_complete, operation_id, content_sha256):
    return {"profile": POINTER_PROFILE, "principal": principal,
            "library_root": str(Path(root).resolve()), "note_id": note_id,
            "conversation_id": conversation_id, "title": title, "saved_at": saved_at,
            "exchange_count": exchange_count, "window_complete": window_complete,
            "operation_id": operation_id, "content_sha256": content_sha256,
            "origin": "host_retained_conversation_record",
            "body_included": False}


# --------------------------------------------------------------- saving

def save_checkpoint(library, root, principal, conversation_id, exchanges, *,
                    note_id=None, budget=DEFAULT_BUDGET_CHARS, operation_id=None,
                    publish_pointer=True, earlier_omitted=0):
    """Save or correct a checkpoint, then PROVE it before calling it saved.

    Returns a status dict. `saved` is True only after a fresh read of the stored
    note validated against the intended content digest. An uncertain write keeps
    its operation_id for read-only reconciliation and is never promoted to a
    usable shortcut, and is never retried here to make the result look clean.
    """
    body, document = build_body(principal, conversation_id, exchanges, budget=budget,
                                earlier_omitted=earlier_omitted)
    title = "Conversation checkpoint " + conversation_id
    expected_sha = sha({"title": title, "body": body, "kind": CHECKPOINT_KIND, "sources": []})
    stable_id = operation_id or ("op_" + sha({"principal": principal, "conversation": conversation_id,
                                              "exchanges": len(document["exchanges"]),
                                              "content": expected_sha}))
    status = {"operation_id": stable_id, "saved": False, "pointer_published": False,
              "conversation_id": conversation_id, "window_complete": document["window_complete"],
              "earlier_exchanges_omitted": document["earlier_exchanges_omitted"],
              "origin": "host_retained_conversation_record"}
    try:
        if note_id:
            outcome = library.correct(note_id, title, body, kind=CHECKPOINT_KIND,
                                      operation_id=stable_id)
        else:
            outcome = library.remember(title, body, kind=CHECKPOINT_KIND,
                                       operation_id=stable_id)
    except MemoryError as exc:
        status.update(storage_outcome="failed", error=str(exc), automatic_retry=False)
        return status
    if not isinstance(outcome, dict):
        outcome = {}
    status["storage_outcome"] = outcome.get("storage_outcome", "unknown")
    saved_id = outcome.get("note_id")
    if (outcome.get("ok") is not True or outcome.get("persisted") is not True
            or outcome.get("readback_verified") is not True
            or outcome.get("storage_outcome") != "committed"
            or not isinstance(saved_id, str) or not saved_id):
        # Unknown or failed. Keep the ID for reconciliation; do not write again.
        status.update(saved=False, automatic_retry=False,
                      reconcile_operation_id=stable_id,
                      message=("Checkpoint outcome unknown. Reconcile this operation ID "
                               "read-only before any further write."))
        return status

    # Independent proof: a fresh read of what is actually stored.
    try:
        _, stored, lineage = load_checkpoint(library, saved_id, principal=principal,
                                              conversation_id=conversation_id)
        digest_ok = stored.get("content_sha256") == expected_sha
        state_ok = stored.get("id") == saved_id and not lineage["corrected"]
    except (MemoryError, OSError, ValueError):
        status.update(saved=False, automatic_retry=False, reconcile_operation_id=stable_id,
                      message="Checkpoint written but readback failed; not offered as saved.")
        return status
    if not (digest_ok and state_ok):
        status.update(saved=False, automatic_retry=False, reconcile_operation_id=stable_id,
                      readback_digest_matched=digest_ok,
                      message="Checkpoint readback did not match the intended content.")
        return status

    status.update(saved=True, note_id=saved_id, title=title, readback_verified=True,
                  content_sha256=expected_sha, saved_at=stored.get("created_at"),
                  exchange_count=document["exchange_count"])
    if not publish_pointer:
        status["pointer_published"] = False
        status["pointer_note"] = "Pointer intentionally not published for this session."
        return status
    try:
        entry = pointer_entry(root, principal, note_id=saved_id, conversation_id=conversation_id,
                              title=title, saved_at=stored.get("created_at"),
                              exchange_count=document["exchange_count"],
                              window_complete=document["window_complete"],
                              operation_id=stable_id, content_sha256=expected_sha)
        status["pointer_path"] = write_pointer(root, principal, entry)
        status["pointer_published"] = True
    except (OSError, MemoryError) as exc:
        # The note IS saved. Do not repeat the note write to repair a shortcut.
        status.update(pointer_published=False, automatic_retry=False,
                      pointer_error=str(exc) if isinstance(exc, MemoryError) else "POINTER_WRITE_FAILED",
                      message="note saved; continuation shortcut unavailable")
    return status


def discover(library, root, principal):
    """Read-only metadata for the launcher. No body, no mutation, no provider call."""
    entry = read_pointer(root, principal)
    if entry is None:
        return {"available": False, "reason": "NO_CHECKPOINT_RECORDED"}
    if entry.get("invalid"):
        return {"available": False, "reason": entry["reason"],
                "note": "A pointer exists but is not usable. This is not an empty past."}
    try:
        document, record, lineage = load_checkpoint(
            library, entry["note_id"], principal=principal,
            conversation_id=entry.get("conversation_id"))
    except MemoryError as exc:
        return {"available": False, "reason": str(exc), "note_id": entry.get("note_id"),
                "note": ("The retained record could not be opened. This is an error, "
                         "not an empty history.")}
    return {"available": True, "note_id": record["id"], "pointer_note_id": entry["note_id"],
            "conversation_id": document["conversation_id"], "title": record.get("title", ""),
            "saved_at": record.get("created_at"), "exchange_count": document["exchange_count"],
            "window_complete": document["window_complete"],
            "earlier_exchanges_omitted": document["earlier_exchanges_omitted"],
            "corrected_since_pointer": lineage["corrected"], "lineage": lineage,
            "origin": "host_retained_conversation_record",
            "body_disclosed": False}


def safe_label(text, limit=110):
    """Titles are stored text, never terminal control sequences."""
    printable = "".join(c for c in str(text) if c.isprintable())
    return " ".join(printable.split())[:limit]
