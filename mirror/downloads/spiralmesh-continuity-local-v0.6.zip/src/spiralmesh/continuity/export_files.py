"""Write an existing export to a host-selected file and verify its readback.

This helper is not a model-facing memory operation. It never overwrites an
existing destination or removes an uncertain/partial file after a failure.
"""
import hashlib
import json
import os
from pathlib import Path

from .store import MemoryError, canonical, verify_export


def write_export_file(bundle, destination):
    """Return file evidence only after closing and independently reopening it."""
    try:
        if not verify_export(bundle):
            raise ValueError("invalid export")
        expected = canonical(bundle)
    except (ValueError, TypeError, KeyError):
        raise MemoryError("INVALID_EXPORT") from None
    path = Path(destination)
    try:
        with path.open("xb") as stream:
            if stream.write(expected) != len(expected):
                raise OSError("short export write")
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        raise MemoryError("EXPORT_DESTINATION_EXISTS", {
            "storage_outcome": "not_attempted", "persisted": False,
            "write_attempted": False, "readback_verified": False,
            "automatic_retry": False}) from None
    except OSError:
        raise MemoryError("EXPORT_WRITE_FAILED", {
            "storage_outcome": "unknown", "persisted": None,
            "write_attempted": True, "readback_verified": False,
            "automatic_retry": False}) from None
    try:
        with path.open("rb") as stream:
            # Bound the read by the intended file size; oversized replacement
            # files are mismatches, not an invitation to read unlimited bytes.
            observed = stream.read(len(expected) + 1)
    except OSError:
        raise MemoryError("EXPORT_READBACK_FAILED", {
            "storage_outcome": "written_unverified", "persisted": None,
            "write_attempted": True, "readback_verified": False,
            "automatic_retry": False}) from None
    if observed != expected or not verify_export(json.loads(observed)):
        raise MemoryError("EXPORT_READBACK_MISMATCH", {
            "storage_outcome": "written_unverified", "persisted": None,
            "write_attempted": True, "readback_verified": False,
            "automatic_retry": False})
    return {"ok": True, "exported": True, "storage_outcome": "written_verified",
            "persisted": True, "write_attempted": True, "readback_verified": True,
            "automatic_retry": False, "local_file": path.name,
            "bytes": len(observed), "sha256": bundle["sha256"],
            "export_sha256": hashlib.sha256(observed).hexdigest(),
            "verification_limit": "Exact bytes and payload digest checked at readback time; not authorship, truth, future retention or erasure of other copies."}
