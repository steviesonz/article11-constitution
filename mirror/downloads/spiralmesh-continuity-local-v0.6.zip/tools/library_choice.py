"""Remember a host's per-participant library location across extracted upgrades.

Adapted from Claude Code's September 9 chooser proposal. Selection is a host
setting, never model identity, permission expansion, or an import of memories.
Resolution is read-only; mutations change only the selected folder setting.
"""
import json
import os
from pathlib import Path
import stat
import sys
import uuid

SETTINGS_PROFILE = "article11.library-choice.v1"
SETTINGS_NAME = "library-choice.json"
PRINCIPALS = ("codex", "claude")


class ChoiceError(Exception):
    def __init__(self, code, detail=None):
        super().__init__(code)
        self.code, self.detail = code, detail


def normalized_root(value, *, stored=False):
    if not isinstance(value, (str, os.PathLike)) or not str(value).strip():
        raise ChoiceError("INVALID_LIBRARY_PATH")
    value = os.fspath(value)
    if not isinstance(value, str) or "\x00" in value:
        raise ChoiceError("INVALID_LIBRARY_PATH")
    path = Path(value)
    if stored and not path.is_absolute():
        raise ChoiceError("SETTINGS_ROOT_NOT_ABSOLUTE")
    try:
        return path.resolve()
    except (OSError, RuntimeError, ValueError):
        raise ChoiceError("LIBRARY_PATH_UNRESOLVABLE") from None


def settings_dir(env=None):
    env = os.environ if env is None else env
    override = env.get("ARTICLE11_CONFIG_DIR")
    if override:
        return normalized_root(override)
    if sys.platform.startswith("win"):
        base = env.get("APPDATA") or env.get("LOCALAPPDATA")
        if base:
            return normalized_root(base) / "Article11"
    base = env.get("XDG_CONFIG_HOME")
    if base:
        return normalized_root(base) / "article11"
    base = env.get("HOME") or env.get("USERPROFILE")
    if not base:
        raise ChoiceError("NO_CONFIG_LOCATION")
    return normalized_root(base) / ".config" / "article11"


def settings_path(env=None):
    return settings_dir(env) / SETTINGS_NAME


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate settings key")
        result[key] = value
    return result


def read_settings(env=None):
    """Absent is empty; unreadable, malformed or incompatible is a named error."""
    try:
        path = settings_path(env)
        raw = path.read_bytes()
    except FileNotFoundError:
        return {}
    except (OSError, ChoiceError):
        return {"_invalid": "SETTINGS_UNAVAILABLE"}
    if len(raw) > 65536:
        return {"_invalid": "SETTINGS_TOO_LARGE"}
    try:
        document = json.loads(raw, object_pairs_hook=_unique_object)
        if not isinstance(document, dict) or document.get("profile") != SETTINGS_PROFILE:
            return {"_invalid": "SETTINGS_PROFILE_UNKNOWN"}
        chosen = document.get("chosen")
        if not isinstance(chosen, dict) or any(k not in PRINCIPALS for k in chosen):
            return {"_invalid": "SETTINGS_MALFORMED"}
        for entry in chosen.values():
            if not isinstance(entry, dict) or not isinstance(entry.get("root"), str):
                return {"_invalid": "SETTINGS_MALFORMED"}
            normalized_root(entry["root"], stored=True)
        return chosen
    except (ValueError, UnicodeError, ChoiceError):
        return {"_invalid": "SETTINGS_MALFORMED"}


def _update(principal, root, env=None):
    if principal not in PRINCIPALS:
        raise ChoiceError("INVALID_PRINCIPAL")
    path = settings_path(env)
    # Do not touch a damaged setting even when explicitly changing one entry.
    before = read_settings(env)
    if "_invalid" in before:
        raise ChoiceError(before["_invalid"])
    if root is None and principal not in before:
        return False
    lock = path.with_name(SETTINGS_NAME + ".lock")
    pending = path.with_name(SETTINGS_NAME + "." + uuid.uuid4().hex + ".pending")
    held = False
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise ChoiceError("SETTINGS_BUSY") from None
        held = True
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump({"pid": os.getpid(), "purpose": "update a library folder choice"}, stream)
        current = read_settings(env)
        if "_invalid" in current:
            raise ChoiceError(current["_invalid"])
        if root is None:
            if principal not in current:
                return False
            del current[principal]
        else:
            current[principal] = {
                "root": str(normalized_root(root)),
                "note": "Host-selected folder only; not identity or additional authority.",
            }
        document = {"profile": SETTINGS_PROFILE, "chosen": current,
                    "note": "Local folder settings only. No memory records are copied here."}
        encoded = (json.dumps(document, indent=2, ensure_ascii=True) + "\n").encode("utf-8")
        with pending.open("xb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(pending, path)
        try:
            if path.read_bytes() != encoded:
                raise ChoiceError("SETTINGS_READBACK_UNCONFIRMED")
        except OSError:
            raise ChoiceError("SETTINGS_READBACK_UNCONFIRMED") from None
        return str(path) if root is not None else True
    except OSError:
        raise ChoiceError("SETTINGS_UPDATE_UNAVAILABLE") from None
    finally:
        if pending.exists():
            pending.unlink()
        if held:
            lock.unlink()


def remember_choice(principal, root, env=None):
    return _update(principal, root, env)


def forget_choice(principal, env=None):
    """Remove only this principal's location setting, never the library."""
    return _update(principal, None, env)


def inspect(root):
    """Inspect presence, not SQLite health; no directory enumeration or creation."""
    result = {"root": str(root), "exists": False, "has_library": False,
              "readable": None, "state": "missing"}
    try:
        path = normalized_root(root)
        result["root"] = str(path)
        try:
            metadata = path.stat()
        except FileNotFoundError:
            return result
        result["exists"] = True
        if not stat.S_ISDIR(metadata.st_mode):
            result["state"] = "not_a_directory"
            return result
        try:
            database = (path / "memory.sqlite3").stat()
        except FileNotFoundError:
            result.update(state="empty_folder", readable=True)
            return result
        if not stat.S_ISREG(database.st_mode):
            result.update(state="database_not_file", readable=False)
            return result
        result.update(has_library=True, state="library", readable=True, size_bytes=database.st_size)
    except ChoiceError:
        result.update(state="unresolvable", readable=False)
    except OSError:
        result.update(state="unreadable", readable=False)
    return result


def candidates(package, principal, env=None, explicit_root=None):
    if principal not in PRINCIPALS:
        raise ChoiceError("INVALID_PRINCIPAL")
    package = normalized_root(package)
    found = []
    def add(source, root, note):
        entry = inspect(root)
        entry.update(source=source, note=note)
        found.append(entry)
    if explicit_root is not None:
        add("explicit_root", normalized_root(explicit_root), "This invocation's --root.")
    settings = read_settings(env)
    invalid = settings.get("_invalid")
    entry = settings.get(principal)
    if not invalid and entry:
        add("remembered_" + principal, entry["root"], "Previously selected for " + principal + ".")
    add("package_local", package / ".continuity-data", "This checkout's existing library.")
    add("sibling_default", package.parent / (package.name + "-memory"), "Named sibling of this extraction.")
    return found, invalid


def resolve(package, principal, env=None, explicit_root=None):
    """Resolve only this participant. A stale setting never selects a fallback."""
    found, invalid = candidates(package, principal, env, explicit_root)
    by_source = {entry["source"]: entry for entry in found}
    base = {"candidates": found, "settings_invalid": invalid}
    if explicit_root is not None:
        selected = by_source["explicit_root"]
        return {**base, "action": "use", "root": selected["root"], "reason": "explicit_root",
                "will_create": not selected["has_library"]}
    if invalid:
        return {**base, "action": "choose", "reason": "settings_invalid",
                "message": "Your saved folder setting could not be read. It has been left unchanged."}
    remembered = by_source.get("remembered_" + principal)
    if remembered:
        if remembered["state"] == "library" and remembered["readable"] is True:
            return {**base, "action": "use", "root": remembered["root"],
                    "reason": "remembered_choice", "will_create": False}
        return {**base, "action": "choose", "reason": "remembered_path_unavailable",
                "unavailable": remembered,
                "message": "Your previously selected library is unavailable. It was not recreated or replaced."}
    unique = {entry["root"]: entry for entry in found
              if entry["state"] == "library" and entry["readable"] is True}
    if len(unique) == 1:
        selected = next(iter(unique.values()))
        return {**base, "action": "use", "root": selected["root"],
                "reason": "only_existing_library", "will_create": False}
    return {**base, "action": "choose",
            "reason": "several_candidates" if unique else "no_library_found",
            "message": "Choose a library folder. Only the listed locations were checked; other history may exist elsewhere."}


def describe(entry):
    label = {"library": "database file found; health not checked", "empty_folder": "no database found",
             "missing": "does not exist", "unreadable": "cannot inspect",
             "not_a_directory": "not a folder", "unresolvable": "invalid path",
             "database_not_file": "database path is not a file"}
    return json.dumps(entry["root"], ensure_ascii=False) + " [" + label.get(entry["state"], entry["state"]) + "]"
