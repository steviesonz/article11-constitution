@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
python -B "%~dp0tools\open_memory.py" claude %*
if errorlevel 1 pause
