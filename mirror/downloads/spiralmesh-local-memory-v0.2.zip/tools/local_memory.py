"""Run the extracted standalone package without pip or site-packages."""
from pathlib import Path
import sys

if sys.version_info < (3,10):
    raise SystemExit("SPIRALMESH local memory requires Python 3.10 or newer.")
sys.dont_write_bytecode = True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from spiralmesh.local_memory.runner import main

if __name__=="__main__":
    raise SystemExit(main())
