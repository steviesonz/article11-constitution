@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 -B "verify_bundle.py"
goto finished
:use_python
python -B "verify_bundle.py"
:finished
set "RESULT=%ERRORLEVEL%"
popd
echo.
pause
exit /b %RESULT%
