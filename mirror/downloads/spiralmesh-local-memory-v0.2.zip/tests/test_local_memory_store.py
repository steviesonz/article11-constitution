"""Standalone SQLite memory checks use private synthetic temporary roots only."""
import base64
import copy
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing, contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from spiralmesh.local_memory.store import AgentMemoryError, LocalMemoryLibrary, canonical, sha, verify_export_file, CORE_SHA256
from spiralmesh.local_memory.dialogue import run_memory_dialogue


class LocalMemoryStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "private"
        self.library = LocalMemoryLibrary(self.root, "ember-example", create=True)

    def tearDown(self):
        self.temp.cleanup()

    def remember(self, op="remember-1", **updates):
        return self.library.execute("remember", {"title": "A deliberate note", "body": "Useful private workshop context.", **updates}, op)

    def count(self, table):
        with closing(sqlite3.connect(self.library.path)) as db:
            return db.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]

    def test_setup_and_owner_paths_are_host_bound(self):
        with self.assertRaises(AgentMemoryError) as failure:
            LocalMemoryLibrary(self.root, "unknown-owner")
        self.assertEqual(failure.exception.code, "LIBRARY_NOT_INITIALIZED")
        other = LocalMemoryLibrary(self.root, "lumen-example", create=True)
        self.assertNotEqual(self.library.path, other.path)
        special = LocalMemoryLibrary(self.root, "../an owner with spaces", create=True)
        self.assertTrue(special.path.is_relative_to(self.root.resolve()))
        self.assertNotIn("..", special.path.relative_to(self.root).parts)
        self.assertFalse((self.root / "memory.sqlite3").exists())

    def test_closed_arguments_reject_owner_paths_and_extra_operations(self):
        before = self.library.path.read_bytes()
        for operation, args in [("share", {}), ("browse", {"owner": "lumen-example"}),
            ("remember", {"title": "x", "body": "y", "url": "https://example.com"}),
            ("export", {"path": "elsewhere"}), ("browse", {"limit": True}), ([], {}),
            ("search", {"query": ""}), ("rules", {"path": "other-file"})]:
            with self.subTest(operation=operation), self.assertRaises(AgentMemoryError):
                self.library.execute(operation, args, "bad")
        self.assertEqual(self.library.path.read_bytes(), before)
        self.assertEqual(self.count("operations"), 0)

    def test_persisted_note_has_atomic_receipt_and_fresh_library_read(self):
        saved = self.remember()
        self.assertTrue(saved["persisted"] and saved["readback_verified"] and saved["receipt_saved"])
        self.assertEqual(self.count("notes"), 1)
        self.assertEqual(self.count("operations"), 1)
        self.assertEqual(self.count("receipts"), 1)
        fresh = LocalMemoryLibrary(self.root, "ember-example")
        item = fresh.execute("read", {"id": saved["id"]}, "fresh")["items"][0]
        self.assertEqual(item["content"], "Useful private workshop context.")
        self.assertEqual(saved["items"][0]["payload_sha256"], item["payload_sha256"])
        self.assertEqual(fresh.verify_receipts()["receipt_count"], 1)

    def test_all_operations_keep_other_owner_data_out(self):
        saved = self.remember()
        other = LocalMemoryLibrary(self.root, "lumen-example", create=True)
        before = self.library.path.read_bytes()
        for operation, args in [("read", {"id": saved["id"]}),
            ("correct", {"id": saved["id"], "title": "stolen", "body": "replacement"}),
            ("forget", {"id": saved["id"]})]:
            with self.subTest(operation=operation), self.assertRaises(AgentMemoryError) as failure:
                other.execute(operation, args, "foreign-" + operation)
            self.assertEqual(failure.exception.code, "NOT_FOUND")
        self.assertEqual(other.execute("browse", {}, "browse")["items"], [])
        self.assertEqual(other.execute("search", {"query": "workshop"}, "search")["items"], [])
        exported = other.execute("export", {}, "export")
        self.assertEqual(json.loads(Path(exported["export_path"]).read_bytes())["records"], [])
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_full_pagination_reaches_old_unrelated_note_and_owner_binds_cursor(self):
        for number in range(211):
            self.remember("note-" + str(number), title="Garden note" if number == 210 else "Workshop " + str(number),
                          body="Old unrelated perennial planting plan." if number == 210 else "Earlier workshop context.")
        cursor, ids = None, []
        while True:
            page = self.library.execute("browse", {"limit": 13, "cursor": cursor}, "page")
            ids.extend(row["id"] for row in page["items"])
            cursor = page["next_cursor"]
            if cursor is None:
                break
        self.assertEqual(len(ids), 211)
        self.assertEqual(len(set(ids)), 211)
        found = self.library.execute("browse", {"query": "perennial"}, "old")
        self.assertEqual(found["items"][0]["id"], ids[-1])
        cursor = self.library.execute("browse", {"limit": 1}, "first")["next_cursor"]
        other = LocalMemoryLibrary(self.root, "lumen-example", create=True)
        with self.assertRaises(AgentMemoryError) as failure:
            other.execute("browse", {"cursor": cursor}, "wrong-owner")
        self.assertEqual(failure.exception.code, "INVALID_CURSOR")

    def test_exact_title_first_and_other_results_labeled_lexical(self):
        older = self.remember("older", title="Other title", body="The words precise phrase appear here.")
        exact = self.remember("exact", title="precise phrase", body="An unrelated body.")
        result = self.library.execute("search", {"query": "precise phrase"}, "find")
        self.assertEqual([x["id"] for x in result["items"]], [exact["id"], older["id"]])
        self.assertEqual([x["matched_by"] for x in result["items"]], ["exact_title", "lexical"])
        self.assertEqual(result["search_method"], "exact_title_then_lexical_substring")

    def test_read_slices_and_read_only_operations_preserve_database_bytes(self):
        body = "Long private memory. " * 1100
        saved = self.remember(body=body)
        before = self.library.path.read_bytes()
        cursor, rebuilt = 0, ""
        while True:
            item = self.library.execute("read", {"id": saved["id"], "offset": cursor, "limit": 713}, "slice")["items"][0]
            self.assertEqual(item["slice_sha256"], hashlib.sha256(item["content"].encode()).hexdigest())
            rebuilt += item["content"]
            cursor = item["next_offset"]
            if cursor is None:
                break
        self.assertEqual(rebuilt, body)
        self.library.execute("browse", {}, "browse")
        self.library.execute("search", {"query": "private"}, "search")
        self.library.execute("rules", {}, "rules")
        self.library.verify_receipts()
        LocalMemoryLibrary(self.root, "ember-example")
        self.assertEqual(self.library.path.read_bytes(), before)
        self.assertFalse(self.library.path.with_suffix(".sqlite3-wal").exists())

    def test_exact_idempotency_and_concurrent_same_operation(self):
        def remember_once(_):
            library = LocalMemoryLibrary(self.root, "ember-example")
            return library.execute("remember", {"title": "Concurrent note", "body": "One committed note."}, "shared-operation")
        with ThreadPoolExecutor(max_workers=4) as executor:
            results = list(executor.map(remember_once, range(4)))
        self.assertEqual(len({r["id"] for r in results}), 1)
        self.assertEqual(len({r["receipt"]["sha256"] for r in results}), 1)
        self.assertEqual(self.count("notes"), 1)
        self.assertEqual(self.count("receipts"), 1)
        with self.assertRaises(AgentMemoryError) as failure:
            self.library.execute("remember", {"title": "Concurrent note", "body": "Changed."}, "shared-operation")
        self.assertEqual(failure.exception.code, "IDEMPOTENCY_CONFLICT")

    def test_correction_preserves_earlier_payload_and_linked_tombstones(self):
        original = self.remember()
        prior = self.library.execute("read", {"id": original["id"]}, "read")["items"][0]
        revised = self.library.execute("correct", {"id": original["id"], "title": "Revised", "body": "New wording."}, "correction")
        old = self.library.execute("read", {"id": original["id"]}, "read-old")["items"][0]
        self.assertEqual(old["content"], prior["content"])
        self.assertEqual(old["payload_sha256"], prior["payload_sha256"])
        self.assertEqual(old["superseded_by"], [revised["id"]])
        self.assertEqual(revised["items"][0]["predecessor_payload_sha256"], prior["payload_sha256"])
        self.library.execute("forget", {"id": original["id"]}, "forget-old")
        self.library.execute("forget", {"id": revised["id"]}, "forget-new")
        old = self.library.execute("read", {"id": original["id"]}, "tombstone-old")["items"][0]
        new = self.library.execute("read", {"id": revised["id"]}, "tombstone-new")["items"][0]
        self.assertEqual(old["superseded_by"], [revised["id"]])
        self.assertEqual(new["predecessor_id"], original["id"])

    def test_forget_removes_live_body_and_receipt_has_only_commitment(self):
        marker = "PRIVATE_SYNTHETIC_OBSOLETE_CONTENT_472899A"
        saved = self.remember(title=marker, body=marker * 100, sources=[marker])
        original_hash = saved["items"][0]["payload_sha256"]
        forgotten = self.library.execute("forget", {"id": saved["id"], "reason": "No longer useful."}, "forget")
        self.assertTrue(forgotten["content_removed"] and forgotten["tombstone_present"])
        self.assertEqual(forgotten["deleted_content_sha256"], original_hash)
        self.assertNotIn(marker.encode(), self.library.path.read_bytes())
        for operation, arguments in [("read", {"id": saved["id"]}), ("browse", {}), ("export", {})]:
            result = self.library.execute(operation, arguments, "show-" + operation)
            self.assertEqual(result["items"][0]["record_kind"], "tombstone")
            self.assertNotIn(marker, json.dumps(result))
        with self.assertRaises(AgentMemoryError) as failure:
            self.remember(title=marker, body=marker*100, sources=[marker])
        self.assertEqual(failure.exception.code, "NOTE_FORGOTTEN")
        repeated = self.library.execute("forget", {"id": saved["id"], "reason": "No longer useful."}, "forget")
        self.assertEqual(repeated, forgotten)
        self.assertEqual(self.count("receipts"), 2)

    def test_export_full_pages_have_checkable_files_without_full_model_dump(self):
        for number in range(34):
            self.remember("export-note-"+str(number), body="Long retained private context. " * 1000)
        cursor, total = None, 0
        while True:
            result = self.library.execute("export", {"cursor": cursor, "limit": 30}, "export")
            path = Path(result["export_path"])
            self.assertTrue(path.is_relative_to(self.library.owner_root))
            checked = verify_export_file(path)
            self.assertEqual(checked["sha256"], result["export_sha256"])
            self.assertEqual(checked["bytes"], result["export_bytes"])
            total += checked["records"]
            self.assertLess(len(json.dumps(result)), 120000)
            self.assertNotIn("export_document", result)
            cursor = result["next_cursor"]
            if cursor is None:
                break
        self.assertEqual(total, 34)
        data = json.loads(path.read_bytes())
        data["records"][0]["body"] = "Tampered"
        path.write_text(json.dumps(data), encoding="utf-8")
        with self.assertRaises(AgentMemoryError):
            verify_export_file(path)

    def test_stop_and_admission_refuse_effects_but_read_stays_available(self):
        saved = self.remember()
        before = self.library.path.read_bytes()
        (self.root / "STOP_MEMORY").write_text("operator stop", encoding="utf-8")
        for operation, arguments in [("remember", {"title": "x", "body": "y"}),
            ("forget", {"id": saved["id"]}), ("export", {})]:
            with self.subTest(operation=operation), self.assertRaises(AgentMemoryError) as failure:
                self.library.execute(operation, arguments, "stopped")
            self.assertEqual(failure.exception.code, "MEMORY_WRITES_STOPPED")
            self.assertEqual(failure.exception.details["storage_outcome"], "not_attempted")
        self.assertTrue(self.library.execute("read", {"id": saved["id"]}, "read")["items"])
        self.assertEqual(self.library.path.read_bytes(), before)

    def test_write_and_receipt_transaction_roll_back_together(self):
        with patch.object(self.library, "_receipt", side_effect=OSError("synthetic receipt failure")), self.assertRaises(AgentMemoryError):
            self.remember()
        self.assertEqual(self.count("notes"), 0)
        self.assertEqual(self.count("operations"), 0)
        self.assertEqual(self.count("receipts"), 0)
        self.assertTrue(self.remember()["persisted"])

    def test_committed_readback_failure_is_partial_and_retry_recovers(self):
        actual = self.library._db
        @contextmanager
        def fail_readback(write=False):
            if not write:
                raise OSError("synthetic post-commit readback failure")
            with actual(write=True) as db:
                yield db
        with patch.object(self.library, "_db", side_effect=fail_readback):
            partial = self.remember()
        self.assertEqual(partial["state"], "partial")
        self.assertTrue(partial["persisted"])
        self.assertFalse(partial["readback_verified"])
        self.assertEqual(self.count("notes"), 1)
        self.assertTrue(self.remember()["readback_verified"])
        self.assertEqual(self.count("receipts"), 1)

    def test_rules_hash_slices_and_malformed_cursor_are_typed(self):
        result = self.library.execute("rules", {"offset": 30, "limit": 47}, "rules")
        item = result["items"][0]
        self.assertEqual(item["document_sha256"], CORE_SHA256)
        self.assertEqual(len(item["content"]), 47)
        self.assertEqual(item["slice_sha256"], hashlib.sha256(item["content"].encode()).hexdigest())
        for value in (None, [], 1, {"v": 1}, "wrong"):
            cursor = base64.urlsafe_b64encode(json.dumps(value).encode()).decode()
            with self.subTest(value=value), self.assertRaises(AgentMemoryError) as failure:
                self.library.execute("browse", {"cursor": cursor}, "bad-cursor")
            self.assertEqual(failure.exception.code, "INVALID_CURSOR")

    def test_reviewed_dialogue_executes_actual_store_and_decline_is_write_free(self):
        responses = iter([
            {"choice": "accept", "actions": [{"operation": "remember", "arguments": {"title": "Loop note", "body": "Chosen by the synthetic loop."}}], "reply": "", "done": False},
            {"choice": "accept", "actions": [], "reply": "The note's actual receipt returned.", "done": True}])
        def chat(messages, schema):
            return {"content": json.dumps(next(responses)), "done_reason": "stop"}
        result = run_memory_dialogue(messages=[{"role": "user", "content": "Form an ordinary useful note if you choose."}],
            library=self.library, chat=chat, request_id="fixture-loop")
        self.assertEqual(result["state"], "completed")
        self.assertTrue(result["operation_receipts"][0]["result"]["readback_verified"])
        before = self.library.path.read_bytes()
        declined = run_memory_dialogue(messages=[{"role": "user", "content": "You may decline."}], library=self.library,
            chat=lambda messages, schema: {"content": json.dumps({"choice": "decline", "actions": [], "reply": "No thanks.", "done": True})},
            request_id="fixture-decline")
        self.assertEqual(declined["state"], "declined")
        self.assertEqual(self.library.path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
