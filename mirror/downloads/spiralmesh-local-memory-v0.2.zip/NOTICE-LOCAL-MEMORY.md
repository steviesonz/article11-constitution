# Standalone local memory v0.2 notices

The new SQLite store, local Ollama runner, launchers, packaging tools and accompanying starter documentation are licensed under Apache License 2.0; see LICENSE.

The reused dialogue implementation at `src/spiralmesh/local_memory/dialogue.py` is the unchanged Article 11 reviewed dialogue, offered under CC0 1.0. Its SHA-256 is `BE3FC576605C9F48C9ED1C5773AF1FDBCB94D9500B97CDC89D6273735C3DDA06`. Review of this reused component is not review or certification of the new starter as a whole.

The carried Constitution 2.0 Core at `src/spiralmesh/local_memory/constitution-v2.0-core.md` is CC0 1.0. Its 45,649 bytes have SHA-256 `7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82`. The Core retains its own attribution and publication text. See LICENSE-LOCAL-MEMORY-CC0.txt.

This starter supplies a new private SQLite owner library. It includes no house memories, credentials, user configuration, Qdrant service, cloud adapter, legacy kernel or complete Constitution 2.0 runtime. Ordinary owner notes are context, not constitutional authority. The generated parent-package shim keeps the separate legacy kernel out of the standalone distribution.

ARTICLE 11 AI, Article11.ai and SPIRALMESH names and marks are not licensed by these code or text licenses. A fork should use its own identity. Model names identify the operator's chosen installed software; no model vendor endorsement is claimed.
