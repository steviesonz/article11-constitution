"""Bundle-only parent package for the portable local memory starter.

The separate legacy SpiralMesh kernel is intentionally not imported or included.
"""
__version__ = "0.2.0-local-memory"
__license__ = "Apache-2.0"
