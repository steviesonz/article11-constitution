# Reviewed dialogue and separate private storage

`dialogue.py` is an unchanged copy of the reviewed local Article 11 dialogue
loop from `locus_bridge/agent_memory_dialogue.py`:

```text
BE3FC576605C9F48C9ED1C5773AF1FDBCB94D9500B97CDC89D6273735C3DDA06
```

The pinned `constitution-v2.0-core.md` has SHA-256:

```text
7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82
```

The Constitution is CC0. Its rules do not override law, human instructions,
host permissions or model-provider requirements. This memory component does
not certify full Constitution 2.0 implementation or migrate older receipt
profiles.

`store.py` is a new stdlib SQLite adapter using established patterns from the
existing `spiralmesh.continuity.store`: canonical JSON, readonly connections,
immediate transactions, secure-delete/DELETE-journal settings and chained
receipts. It is a separate local store. It does not open the existing participant
continuity database, query Qdrant, import global history or copy house privacy
patterns. There is no implicit history migration between these adapters.

Each host-bound owner has a separate hashed directory under the configured
private root. The application exposes no share, publish, external-send or import
operation. Content is private local plaintext; no automatic PII redaction or
encryption is claimed. Protect the filesystem as appropriate for your device.
Model actions cannot change their owner or choose a file path. Ordinary
owner-authored notes need no repeated human gate; a host admission callback or
the root's `STOP_MEMORY` file can stop new writes/exports while reads remain
available.

Browse and export continue until their returned cursor is null. Read exposes
explicit character slices. Search ranks exact titles first, then labels text
substring results as lexical; there is no embedding model or semantic service.
An export's full records are saved in a private file; the model receives its
digest, location and short record excerpts instead of an automatic library dump.

The note, operation binding and receipt commit in one SQLite transaction.
Post-commit readback is separate. A correction keeps the predecessor; forget
replaces a single live note with a same-ID tombstone and a hash of the removed
payload. Old write replays cannot resurrect it. Receipts/idempotency rows contain
only metadata and commitments, not copies of the original text. Earlier versions,
exports, backups, logs or other copies remain. A digest is not encryption, and
predictable content can be guessed. The optional deletion reason is retained.
