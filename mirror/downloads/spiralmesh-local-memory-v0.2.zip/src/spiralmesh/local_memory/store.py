"""Private SQLite owner library for the reviewed Article 11 dialogue protocol.

Reuses the existing continuity store's canonical JSON, readonly connection,
immediate transaction, secure-delete and receipt-chain patterns. This separate
store has no share/publish/import operation and no house privacy-pattern stub.
Content is local plaintext, not automatically classified/redacted. The host
binds owners/paths; these application rules are not filesystem/OS isolation.
"""
from __future__ import annotations

import base64
from contextlib import closing, contextmanager, nullcontext
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import uuid

RESULT_SCHEMA = "article11.agent-memory-result.v1"
CORE_SHA256 = "7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82"
OPERATIONS = {
    "browse": {"query", "cursor", "limit"}, "search": {"query", "limit"},
    "read": {"id", "offset", "limit"}, "remember": {"title", "body", "kind", "sources"},
    "correct": {"id", "title", "body", "kind", "sources"}, "forget": {"id", "reason"},
    "export": {"cursor", "limit"}, "rules": {"offset", "limit"},
}
MUTATIONS = {"remember", "correct", "forget"}


class AgentMemoryError(ValueError):
    def __init__(self, code, **details):
        self.code, self.details = code, details
        super().__init__(code)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(value):
    return hashlib.sha256(value if isinstance(value, bytes) else canonical(value)).hexdigest()


def text_hash(value):
    return sha(value.encode("utf-8"))


def _string(value, field, maximum, empty=False):
    if not isinstance(value, str) or len(value) > maximum or "\x00" in value or (not empty and not value.strip()):
        raise AgentMemoryError("INVALID_ARGUMENT", field=field, storage_outcome="not_attempted")
    return value


def _integer(value, field, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise AgentMemoryError("INVALID_ARGUMENT", field=field, storage_outcome="not_attempted")
    return value


def _atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temporary.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


class LocalMemoryLibrary:
    def __init__(self, root, owner, *, create=False, admission=None):
        self.owner = _string(owner, "owner", 200)
        self.root = Path(root).resolve()
        self.namespace = text_hash(owner)
        self.owner_root = self.root / "owners" / self.namespace
        self.path = self.owner_root / "memory.sqlite3"
        self.admission = admission
        if create:
            self.owner_root.mkdir(parents=True, exist_ok=True)
            with closing(sqlite3.connect(self.path)) as connection, connection:
                connection.executescript("""
                PRAGMA secure_delete=ON;
                PRAGMA journal_mode=DELETE;
                CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS notes(seq INTEGER PRIMARY KEY AUTOINCREMENT,
                  id TEXT UNIQUE NOT NULL,payload TEXT NOT NULL,payload_sha256 TEXT NOT NULL,
                  title TEXT NOT NULL,body TEXT NOT NULL,record_kind TEXT NOT NULL,predecessor_id TEXT);
                CREATE TABLE IF NOT EXISTS receipts(seq INTEGER PRIMARY KEY AUTOINCREMENT,
                  digest TEXT UNIQUE NOT NULL,record TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS operations(operation_id TEXT PRIMARY KEY,operation TEXT NOT NULL,
                  request_sha256 TEXT NOT NULL,note_id TEXT NOT NULL,receipt_sha256 TEXT NOT NULL);
                """)
                connection.execute("INSERT OR IGNORE INTO metadata VALUES('schema','spiralmesh.local-memory.v1')")
                connection.execute("INSERT OR IGNORE INTO metadata VALUES('owner',?)", (owner,))
        if not self.path.is_file():
            raise AgentMemoryError("LIBRARY_NOT_INITIALIZED", storage_outcome="not_attempted")
        with self._db() as db:
            metadata = dict(db.execute("SELECT key,value FROM metadata"))
            if metadata != {"schema": "spiralmesh.local-memory.v1", "owner": owner}:
                raise AgentMemoryError("OWNER_STORE_BINDING_FAILED", storage_outcome="not_attempted")

    @contextmanager
    def _db(self, write=False):
        connection = sqlite3.connect(self.path.as_uri() + ("?mode=rw" if write else "?mode=ro"), uri=True, timeout=15)
        connection.row_factory = sqlite3.Row
        try:
            if write:
                connection.execute("PRAGMA secure_delete=ON")
                connection.execute("PRAGMA journal_mode=DELETE")
                connection.execute("BEGIN IMMEDIATE")
            yield connection
            if write:
                connection.commit()
        except BaseException:
            if write:
                connection.rollback()
            raise
        finally:
            connection.close()

    @contextmanager
    def _admit(self, operation):
        if (self.root / "STOP_MEMORY").exists():
            raise AgentMemoryError("MEMORY_WRITES_STOPPED", storage_outcome="not_attempted")
        manager = self.admission(operation) if self.admission is not None else nullcontext()
        with manager:
            if (self.root / "STOP_MEMORY").exists():
                raise AgentMemoryError("MEMORY_WRITES_STOPPED", storage_outcome="not_attempted")
            yield

    def capabilities(self):
        return {"schema": "article11.agent-memory-capabilities.v1", "operations": list(OPERATIONS),
                "authority": "context_only", "owner": self.owner, "availability": "store_opened_not_model_checked",
                "whole_permitted_library": True, "read_max_chars": 12000, "note_max_chars": 48000,
                "search": "exact title first, then explicitly labeled lexical substring matches; no embeddings",
                "rules": {"version": "2.0", "sha256": CORE_SHA256, "license": "CC0"},
                "privacy_policy": "private local plaintext; no automatic redaction or public/shared route",
                "automatic_transcript_archive": False, "sharing": False, "imports": False,
                "write_control": "host admission and STOP_MEMORY; ordinary owner notes need no per-note gate",
                "forget": "one own note; live content removed, visible tombstone, prior copies remain"}

    def _validate(self, operation, arguments):
        if not isinstance(operation, str) or operation not in OPERATIONS or type(arguments) is not dict or set(arguments) - OPERATIONS[operation]:
            raise AgentMemoryError("INVALID_OPERATION_ARGUMENTS", storage_outcome="not_attempted")
        args = dict(arguments)
        if operation in {"browse", "search", "export"}:
            args["limit"] = _integer(args.get("limit", 10), "limit", 1, 20 if operation == "search" else 30)
        if operation in {"browse", "search"}:
            args["query"] = _string(args.get("query", ""), "query", 2000, operation == "browse")
        if operation in {"browse", "export"}:
            args.setdefault("cursor", None)
            if args["cursor"] is not None:
                _string(args["cursor"], "cursor", 3000)
        if operation in {"read", "correct", "forget"}:
            note_id = _string(args.get("id"), "id", 100)
            if not re.fullmatch(r"lm_[a-f0-9]{32}", note_id):
                raise AgentMemoryError("NOT_FOUND", storage_outcome="not_attempted")
        if operation in {"read", "rules"}:
            args["offset"] = _integer(args.get("offset", 0), "offset", 0, 2**53-1)
            args["limit"] = _integer(args.get("limit", 4000), "limit", 1, 12000)
        if operation in {"remember", "correct"}:
            args["title"] = _string(args.get("title"), "title", 240)
            args["body"] = _string(args.get("body"), "body", 48000)
            args.setdefault("kind", "observation")
            if not isinstance(args["kind"], str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,39}", args["kind"]):
                raise AgentMemoryError("INVALID_ARGUMENT", field="kind", storage_outcome="not_attempted")
            args.setdefault("sources", [])
            if type(args["sources"]) is not list or len(args["sources"]) > 20:
                raise AgentMemoryError("INVALID_ARGUMENT", field="sources", storage_outcome="not_attempted")
            args["sources"] = [_string(value, "sources", 1000) for value in args["sources"]]
        if operation == "forget":
            args["reason"] = _string(args.get("reason", ""), "reason", 2000, True)
        return args

    def execute(self, operation, arguments, operation_id):
        args = self._validate(operation, arguments)
        _string(operation_id, "operation_id", 240)
        result = {"schema": RESULT_SCHEMA, "operation": operation, "operation_id": operation_id,
                  "state": "ok", "storage_outcome": "read_only", "authority": "context_only", "items": []}
        if operation in MUTATIONS:
            return self._mutate(operation, args, operation_id, result)
        try:
            if operation == "rules":
                return self._rules(args, result)
            with self._db() as db:
                if operation == "read":
                    result["items"] = [self._item(db, self._get(db, args["id"]), args["offset"], args["limit"])]
                elif operation == "search":
                    rows = db.execute("SELECT * FROM notes WHERE instr(lower(title||' '||body),lower(?))>0 "
                        "ORDER BY CASE WHEN title=? THEN 0 ELSE 1 END,seq LIMIT ?", (args["query"], args["query"], args["limit"])).fetchall()
                    result["items"] = [{**self._item(db, row), "matched_by": "exact_title" if row["title"] == args["query"] else "lexical"} for row in rows]
                    result["search_method"] = "exact_title_then_lexical_substring"
                else:
                    cursor = self._decode_cursor(args["cursor"], operation, args.get("query", ""))
                    rows = db.execute("SELECT * FROM notes WHERE seq>? AND instr(lower(title||' '||body),lower(?))>0 ORDER BY seq LIMIT ?",
                        (cursor, args.get("query", ""), args["limit"]+1)).fetchall()
                    page = rows[:args["limit"]]
                    result["items"] = [self._item(db, row) for row in page]
                    result["next_cursor"] = self._cursor(page[-1]["seq"], operation, args.get("query", "")) if len(rows) > args["limit"] else None
                    result["complete"] = result["next_cursor"] is None
                    if operation == "export":
                        payloads = [self._payload(row) for row in page]
            if operation == "export":
                return self._export(result, payloads)
            return result
        except AgentMemoryError:
            raise
        except Exception as exc:
            raise AgentMemoryError("MEMORY_STORAGE_UNAVAILABLE", exception_type=type(exc).__name__, storage_outcome="read_only") from exc

    def _payload(self, row):
        payload = json.loads(row["payload"])
        if payload.get("owner") != self.owner:
            raise AgentMemoryError("NOT_FOUND")
        if (sha(payload) != row["payload_sha256"] or payload.get("id") != row["id"]
                or payload.get("record_kind") != row["record_kind"]
                or payload.get("title", "Forgotten note") != row["title"]
                or self._body(payload) != row["body"]
                or payload.get("predecessor_id") != row["predecessor_id"]):
            raise AgentMemoryError("STORED_CONTENT_BINDING_FAILED")
        return payload

    def _get(self, db, note_id):
        row = db.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        if row is None:
            raise AgentMemoryError("NOT_FOUND", storage_outcome="not_attempted")
        self._payload(row)
        return row

    @staticmethod
    def _body(payload):
        if payload["record_kind"] == "tombstone":
            value = "Forgotten note. Live content removed on " + payload["deleted_at"] + "."
            return value + (" Retained reason: " + payload["reason"] if payload["reason"] else "")
        return payload["body"]

    def _item(self, db, row, offset=0, limit=600):
        payload = self._payload(row)
        body = self._body(payload)
        if offset > len(body):
            raise AgentMemoryError("READ_OFFSET_OUT_OF_RANGE", total_chars=len(body))
        end = min(len(body), offset + limit)
        piece = body[offset:end]
        successors = [r[0] for r in db.execute("SELECT id FROM notes WHERE predecessor_id=? ORDER BY seq", (row["id"],))]
        item = {"id": row["id"], "record_kind": payload["record_kind"], "title": row["title"],
                "content": piece, "content_sha256": text_hash(body), "slice_sha256": text_hash(piece),
                "payload_sha256": row["payload_sha256"], "offset": offset, "next_offset": end if end < len(body) else None,
                "total_chars": len(body), "content_is_excerpt": end-offset < len(body), "authority": "context_only",
                "ownership": "own_tombstone" if payload["record_kind"] == "tombstone" else "own_deliberate_note",
                "eligibility": "owner_deliberate_nonratified", "ratified": False,
                "kind": payload.get("kind", "tombstone"), "sources": payload.get("sources", []),
                "superseded_by": successors}
        if payload.get("predecessor_id"):
            item.update(predecessor_id=payload["predecessor_id"], predecessor_payload_sha256=payload["predecessor_payload_sha256"])
        if payload["record_kind"] == "tombstone":
            item.update(deleted_content_sha256=payload["deleted_content_sha256"], deleted_at=payload["deleted_at"],
                        deleted_by=payload["deleted_by"], deletion_reason=payload["reason"], content_removed=True)
        return item

    def _cursor(self, seq, operation, query):
        return base64.urlsafe_b64encode(canonical({"v": 1, "owner": self.namespace, "operation": operation,
                                                  "query": text_hash(query), "seq": seq})).decode("ascii")

    def _decode_cursor(self, token, operation, query):
        if token is None:
            return 0
        try:
            value = json.loads(base64.b64decode(token, altchars=b"-_", validate=True))
            if (type(value) is not dict or set(value) != {"v", "owner", "operation", "query", "seq"} or value["v"] != 1
                    or value["owner"] != self.namespace or value["operation"] != operation or value["query"] != text_hash(query)
                    or type(value["seq"]) is not int or value["seq"] < 0):
                raise ValueError()
            return value["seq"]
        except (ValueError, TypeError, UnicodeError) as exc:
            raise AgentMemoryError("INVALID_CURSOR") from exc

    def _write_note(self, db, payload):
        db.execute("INSERT INTO notes(id,payload,payload_sha256,title,body,record_kind,predecessor_id) VALUES(?,?,?,?,?,?,?)",
            (payload["id"], canonical(payload).decode(), sha(payload), payload.get("title", "Forgotten note"),
             self._body(payload), payload["record_kind"], payload.get("predecessor_id")))

    def _receipt(self, db, operation, operation_id, request_sha256, payload):
        previous = db.execute("SELECT digest FROM receipts ORDER BY seq DESC LIMIT 1").fetchone()
        receipt = {"schema": "spiralmesh.local-memory-receipt.v1", "owner": self.owner,
            "operation": operation, "operation_id": operation_id, "request_sha256": request_sha256,
            "record_id": payload["id"], "payload_sha256": sha(payload), "at": datetime.now(timezone.utc).isoformat(),
            "authority": "context_only", "previous": previous[0] if previous else ""}
        if operation == "forget":
            receipt["deleted_content_sha256"] = payload["deleted_content_sha256"]
        digest = sha(receipt)
        db.execute("INSERT INTO receipts(digest,record) VALUES(?,?)", (digest, canonical(receipt).decode()))
        db.execute("INSERT INTO operations VALUES(?,?,?,?,?)", (operation_id, operation, request_sha256, payload["id"], digest))
        return {**receipt, "sha256": digest}

    def _mutate(self, operation, args, operation_id, result):
        request_hash = sha([operation, args])
        planned_id = "lm_" + uuid.uuid5(uuid.NAMESPACE_URL, "spiralmesh.local-memory:" + self.namespace + ":" + operation_id).hex
        target_id = args["id"] if operation == "forget" else planned_id
        attempted = False
        try:
            with self._admit(operation):
                with self._db(write=True) as db:
                    existing = db.execute("SELECT * FROM operations WHERE operation_id=?", (operation_id,)).fetchone()
                    if existing:
                        if existing["operation"] != operation or existing["request_sha256"] != request_hash:
                            raise AgentMemoryError("IDEMPOTENCY_CONFLICT", storage_outcome="not_attempted")
                        row = self._get(db, existing["note_id"])
                        payload = self._payload(row)
                        if operation != "forget" and payload["record_kind"] == "tombstone":
                            raise AgentMemoryError("NOTE_FORGOTTEN", storage_outcome="not_attempted")
                        record = db.execute("SELECT record FROM receipts WHERE digest=?", (existing["receipt_sha256"],)).fetchone()
                        if record is None:
                            raise AgentMemoryError("RECEIPT_BINDING_FAILED")
                        receipt = {**json.loads(record[0]), "sha256": existing["receipt_sha256"]}
                        target_id = existing["note_id"]
                    else:
                        previous = self._payload(self._get(db, args["id"])) if operation in {"correct", "forget"} else None
                        if previous and previous["record_kind"] == "tombstone":
                            raise AgentMemoryError("NOTE_ALREADY_FORGOTTEN", storage_outcome="not_attempted")
                        at = datetime.now(timezone.utc).isoformat()
                        if operation == "forget":
                            payload = {"schema": "spiralmesh.local-memory-record.v1", "id": target_id, "owner": self.owner,
                                "record_kind": "tombstone", "deleted_content_sha256": sha(previous), "deleted_at": at,
                                "deleted_by": self.owner, "reason": args["reason"], "authority": "context_only", "ratified": False}
                            if previous.get("predecessor_id"):
                                payload.update(predecessor_id=previous["predecessor_id"], predecessor_payload_sha256=previous["predecessor_payload_sha256"])
                            attempted = True
                            db.execute("UPDATE notes SET payload=?,payload_sha256=?,title='Forgotten note',body=?,record_kind='tombstone' WHERE id=?",
                                       (canonical(payload).decode(), sha(payload), self._body(payload), target_id))
                        else:
                            payload = {"schema": "spiralmesh.local-memory-record.v1", "id": target_id, "owner": self.owner,
                                "record_kind": "note", "title": args["title"], "body": args["body"], "kind": args["kind"],
                                "sources": args["sources"], "created_at": at, "authority": "context_only", "ratified": False}
                            if previous:
                                payload.update(predecessor_id=previous["id"], predecessor_payload_sha256=sha(previous))
                            attempted = True
                            self._write_note(db, payload)
                        receipt = self._receipt(db, operation, operation_id, request_hash, payload)
                    if self._payload(self._get(db, target_id)) != payload:
                        raise AgentMemoryError("WRITE_READBACK_MISMATCH")
                    if sha({k: v for k, v in receipt.items() if k != "sha256"}) != receipt["sha256"] or receipt["payload_sha256"] != sha(payload):
                        raise AgentMemoryError("RECEIPT_BINDING_FAILED")
                # A separate readonly connection verifies committed bytes, not
                # just the transaction's own pending writes.
                try:
                    with self._db() as db:
                        stored = self._get(db, target_id)
                        if self._payload(stored) != payload:
                            raise AgentMemoryError("WRITE_READBACK_MISMATCH")
                        item = self._item(db, stored)
                        committed_receipt = db.execute("SELECT record FROM receipts WHERE digest=?", (receipt["sha256"],)).fetchone()
                        if committed_receipt is None or json.loads(committed_receipt[0]) != {k:v for k,v in receipt.items() if k != "sha256"}:
                            raise AgentMemoryError("RECEIPT_BINDING_FAILED")
                except Exception as exc:
                    return {**result, "state": "partial", "storage_outcome": "committed_readback_unavailable",
                            "persisted": True, "readback_verified": False, "receipt_saved": True,
                            "id": target_id, "receipt": receipt, "readback_error": type(exc).__name__}
                result.update(storage_outcome="committed", persisted=True, readback_verified=True, receipt_saved=True,
                              id=target_id, items=[item], receipt=receipt)
                if operation == "forget":
                    result.update(tombstone_present=True, content_removed=True,
                        deleted_content_sha256=payload["deleted_content_sha256"],
                        retention_limits="Live record content removed; earlier versions, exports, backups and other copies remain. Hashes are commitments, not encryption; predictable text can be guessed. No sharing grants exist.")
                return result
        except AgentMemoryError as exc:
            if result.get("persisted"):
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed", "error": exc.code}
            exc.details.setdefault("storage_outcome", "write_outcome_unknown" if attempted else "not_attempted")
            raise
        except Exception as exc:
            if result.get("persisted"):
                return {**result, "state": "partial", "storage_outcome": "committed_admission_cleanup_failed", "error": type(exc).__name__}
            raise AgentMemoryError("MEMORY_STORAGE_UNAVAILABLE", exception_type=type(exc).__name__,
                                   storage_outcome="write_outcome_unknown" if attempted else "not_attempted") from exc

    def _export(self, result, payloads):
        document = {"schema": "spiralmesh.local-memory-export.v1", "owner": self.owner,
                    "authority": "context_only", "visibility": "local_private", "automatic_redaction": False,
                    "records": payloads, "record_hashes": {p["id"]:sha(p) for p in payloads},
                    "next_cursor": result["next_cursor"], "complete": result["complete"]}
        data = canonical(document)
        export_hash = sha(data)
        path = self.owner_root / "exports" / (export_hash + ".json")
        attempted = False
        try:
            with self._admit("export"):
                attempted = True
                _atomic_write(path, data)
                if path.read_bytes() != data:
                    raise AgentMemoryError("EXPORT_READBACK_MISMATCH")
        except Exception as exc:
            raise AgentMemoryError(getattr(exc, "code", "EXPORT_WRITE_UNAVAILABLE"),
                                   storage_outcome="export_outcome_unknown" if attempted else "not_attempted",
                                   export_sha256=export_hash) from exc
        return {**result, "storage_outcome": "local_private_export", "export_path": str(path),
                "export_sha256": export_hash, "export_bytes": len(data), "export_saved": True,
                "export_receipt": {"sha256": export_hash, "record_ids": [p["id"] for p in payloads],
                                   "visibility": "local_private", "meaning": "Exact exported bytes, not proof of identity or truth"}}

    def _rules(self, args, result):
        raw = Path(__file__).with_name("constitution-v2.0-core.md").read_bytes()
        if sha(raw).upper() != CORE_SHA256:
            raise AgentMemoryError("RULE_BINDING_FAILED")
        text = raw.decode("utf-8")
        offset = args["offset"]
        if offset > len(text):
            raise AgentMemoryError("READ_OFFSET_OUT_OF_RANGE", total_chars=len(text))
        content = text[offset:offset+args["limit"]]
        return {**result, "items": [{"id": "constitution-2.0-core", "content": content,
            "content_sha256": text_hash(text), "slice_sha256": text_hash(content), "document_sha256": CORE_SHA256,
            "offset": offset, "next_offset": offset+len(content) if offset+len(content)<len(text) else None,
            "total_chars": len(text), "source_kind": "public_rules", "authority": "context_only"}]}

    def verify_receipts(self):
        previous, count = "", 0
        with self._db() as db:
            for row in db.execute("SELECT digest,record FROM receipts ORDER BY seq"):
                record = json.loads(row["record"])
                if record.get("owner") != self.owner or record.get("previous") != previous or sha(record) != row["digest"]:
                    raise AgentMemoryError("RECEIPT_CHAIN_MISMATCH")
                previous, count = row["digest"], count+1
        return {"state": "ok", "owner": self.owner, "receipt_count": count, "head_sha256": previous,
                "meaning": "Local hash-chain consistency, not authenticated identity or external truth"}


def verify_export_file(path):
    raw = Path(path).read_bytes()
    document = json.loads(raw)
    if (type(document) is not dict or document.get("schema") != "spiralmesh.local-memory-export.v1"
            or type(document.get("records")) is not list or type(document.get("record_hashes")) is not dict):
        raise AgentMemoryError("INVALID_EXPORT")
    if any(type(p) is not dict or not isinstance(p.get("id"), str) for p in document["records"]):
        raise AgentMemoryError("INVALID_EXPORT")
    if len({p.get("id") for p in document["records"]}) != len(document["records"]):
        raise AgentMemoryError("INVALID_EXPORT")
    for payload in document["records"]:
        if payload.get("owner") != document.get("owner") or document["record_hashes"].get(payload.get("id")) != sha(payload):
            raise AgentMemoryError("EXPORT_BINDING_FAILED")
    if set(document["record_hashes"]) != {p["id"] for p in document["records"]}:
        raise AgentMemoryError("EXPORT_BINDING_FAILED")
    return {"state": "ok", "sha256": sha(raw), "bytes": len(raw), "records": len(document["records"]),
            "meaning": "Internal record hashes match; compare this file digest with your independently retained export receipt"}
