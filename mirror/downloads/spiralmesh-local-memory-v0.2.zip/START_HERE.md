# Start here

Open docs/LOCAL_MEMORY_QUICKSTART.md. Verify first with python -B verify_bundle.py.
Windows: open SETUP_LOCAL_MEMORY.cmd, choose an already installed local model, then OPEN_LOCAL_MEMORY.cmd.
Terminal: python -B tools/local_memory.py setup; then python -B tools/local_memory.py run.
Python 3.10+ and local Ollama are prerequisites. No pip packages or model downloads.
Runtime data stays outside this folder. No personal data is included.
