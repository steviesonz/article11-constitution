@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 -B "tools\local_memory.py" run %*
goto finished
:use_python
python -B "tools\local_memory.py" run %*
:finished
set "RESULT=%ERRORLEVEL%"
popd
if not "%RESULT%"=="0" pause
exit /b %RESULT%
