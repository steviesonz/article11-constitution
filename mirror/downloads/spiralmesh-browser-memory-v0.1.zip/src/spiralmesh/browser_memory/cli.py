"""Manual browser-memory packets; stdlib only, no provider or browser calls."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

from .session import BrowserMemoryBridge, BrowserMemoryError
from ..local_memory.store import AgentMemoryError

DEFAULT_ROOT = "~/.spiralmesh-browser-memory"
MAX_RETURN_BYTES = 250_000
MAX_TASK_CHARS = 16_000
OWNER_PATTERN = re.compile(r"[a-z0-9][a-z0-9_-]{0,63}")
ERROR_HINTS = {
    "ROOT_REQUIRED": "This environment has no home directory. Supply an explicit --root private data folder.",
    "OWNER_REQUIRED": "Choose --owner grok, --owner gemini, or your own lowercase owner label.",
    "INVALID_OWNER": "Use 1-64 lowercase letters, digits, underscores or hyphens; begin with a letter or digit.",
    "TASK_REQUIRED": "Supply --task or run start in an interactive terminal.",
    "INVALID_TASK": "Use a nonempty task of at most 16000 characters, without NUL characters.",
    "INVALID_PROVIDER_LABEL": "Use a short, single-line host label, or omit --provider-label.",
    "RETURN_TOO_LARGE": "The returned JSON must be at most 250000 UTF-8 bytes.",
    "RETURN_NOT_UTF8": "Save the returned JSON as UTF-8 text.",
    "RETURN_FILE_UNAVAILABLE": "The selected return file could not be read.",
    "LIBRARY_NOT_INITIALIZED": "Run setup once for this exact root and owner first.",
    "BROWSER_SETUP_REQUIRED": "Run setup once for this exact root and owner first.",
}


class CLIError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def command_text(arguments):
    """A PowerShell-compatible command; arguments are host-selected, not model text."""
    launcher = Path(__file__).resolve().parents[3] / "tools" / "browser_memory.py"
    parts = [str(Path(sys.executable).resolve()), "-B", str(launcher), *arguments]
    if sys.platform == "win32":
        # Single-quote every argument; PowerShell doubles embedded apostrophes.
        return "& " + " ".join("'" + str(value).replace("'", "''") + "'" for value in parts)
    import shlex
    return shlex.join(parts)


def owner_value(value, *, interactive):
    if value is None and interactive:
        value = input("Memory owner (for example grok or gemini): ").strip()
    if not value:
        raise CLIError("OWNER_REQUIRED")
    if not OWNER_PATTERN.fullmatch(value):
        raise CLIError("INVALID_OWNER")
    return value


def provider_value(value):
    if value is not None and (not isinstance(value, str) or not value.strip()
            or len(value) > 200 or any(ord(c) < 32 for c in value)):
        raise CLIError("INVALID_PROVIDER_LABEL")
    return value


def task_value(args):
    value = args.task
    if value is None:
        if not sys.stdin.isatty() or args.json:
            raise CLIError("TASK_REQUIRED")
        value = input("Task for your chosen conversation: ")
    if not value.strip() or len(value) > MAX_TASK_CHARS or "\x00" in value:
        raise CLIError("INVALID_TASK")
    return value


def read_return(path):
    try:
        if path:
            with Path(path).expanduser().open("rb") as stream:
                raw = stream.read(MAX_RETURN_BYTES + 1)
        else:
            if sys.stdin.isatty():
                print("Paste only the returned JSON. Finish with Ctrl+Z then Enter on Windows, or Ctrl+D elsewhere.", file=sys.stderr)
            if hasattr(sys.stdin, "buffer"):
                raw = sys.stdin.buffer.read(MAX_RETURN_BYTES + 1)
            else:
                raw = sys.stdin.read(MAX_RETURN_BYTES + 1).encode("utf-8")
    except OSError:
        raise CLIError("RETURN_FILE_UNAVAILABLE") from None
    if len(raw) > MAX_RETURN_BYTES:
        raise CLIError("RETURN_TOO_LARGE")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeError:
        raise CLIError("RETURN_NOT_UTF8") from None


def common_options(parser, *, secondary=False):
    default = argparse.SUPPRESS if secondary else None
    parser.add_argument("--root", default=default, help="Private data folder (default: ~/.spiralmesh-browser-memory)")
    parser.add_argument("--owner", default=default, help="Host-selected lowercase owner label, such as grok or gemini")
    parser.add_argument("--provider-label", default=default, help="Optional host description; not authenticated provider identity")
    parser.add_argument("--json", action="store_true", default=argparse.SUPPRESS if secondary else False,
                        help="Print structured output; offers and tool results may contain private memory")


def parser():
    result = argparse.ArgumentParser(description="Carry private owner-memory packets through your chosen browser conversation.")
    common_options(result)
    sub = result.add_subparsers(dest="command", required=True)
    for name, help_text in (("setup", "Initialize only the selected owner's private library"),
                            ("start", "Create the first packet for a fresh task"),
                            ("pending", "Print the currently pending packet without advancing it"),
                            ("accept-return", "Validate and apply one manually returned JSON message"),
                            ("status", "Show session metadata without printing recalled content")):
        item = sub.add_parser(name, help=help_text)
        common_options(item, secondary=True)
        if name == "start":
            item.add_argument("--task", help="Task text; omitted for an interactive prompt")
        if name in {"pending", "accept-return", "status"}:
            item.add_argument("--session", required=True, help="Session id returned by start")
        if name == "accept-return":
            item.add_argument("--file", help="UTF-8 JSON file; otherwise read JSON from standard input")
    return result


def show_offer(value, root, owner):
    print("\nPRIVATE PACKET: transfer only to a conversation you authorize for this owner memory.")
    print("Session: " + value["session_id"])
    print("Offer SHA-256: " + value["offer_sha256"])
    print("\n" + value["offer_text"] + "\n")
    print("Copy the complete packet above into your chosen conversation. Save its returned JSON to a UTF-8 file, then run this command in PowerShell (Windows) or your shell (macOS/Linux):")
    print(command_text(["accept-return", "--root", str(root), "--owner", owner,
                        "--session", value["session_id"], "--file", str(root / (owner + "-return.json"))]))
    print("The suggested return filename is not created for you. You can choose another --file path.")


def show_result(value, args, root, owner):
    if args.json:
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return
    if args.command == "setup":
        print("Ready: private browser-memory owner '" + owner + "'.")
        print("Data: " + str(root))
        print("No model or browser was contacted. Your provider label is a host description, not verified identity.")
        print("Start a task with:\n" + command_text(["start", "--root", str(root), "--owner", owner]))
    elif args.command in {"start", "pending"}:
        show_offer(value, root, owner)
    elif args.command == "status":
        print(json.dumps(value, ensure_ascii=False, indent=2))
    else:
        print("State: " + str(value.get("state", "unknown")))
        if value.get("reply"):
            print("Model reply:\n" + str(value["reply"]))
        observed = value.get("operation_result")
        if observed is not None:
            print("Observed operation result (may contain private memory):")
            print(json.dumps(observed, ensure_ascii=False, indent=2))
        if value.get("next_offer") is not None:
            show_offer(value["next_offer"], root, owner)
        elif value.get("state") == "reconciliation_required":
            print("Inspect status before further action. No automatic retry or replacement session was started.")


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        owner = owner_value(args.owner, interactive=sys.stdin.isatty() and not args.json)
        provider = provider_value(args.provider_label)
        try:
            root = Path(args.root if args.root else DEFAULT_ROOT).expanduser().resolve()
        except RuntimeError:
            raise CLIError("ROOT_REQUIRED") from None
        # Validate input before constructing or opening any selected owner store.
        task = task_value(args) if args.command == "start" else None
        content = read_return(args.file) if args.command == "accept-return" else None
        bridge = BrowserMemoryBridge(root, owner, provider_label=provider, create=args.command == "setup")
        if args.command == "setup":
            value = {"schema": "spiralmesh.browser-memory.setup.v0.1", "state": "ready",
                     "root": str(bridge.root), "owner": bridge.owner, "provider_label": bridge.provider_label,
                     "owner_library": str(bridge.library.owner_root), "network_calls": 0, "model_calls": 0,
                     "authorization_scope": "Ordinary operations in this selected owner's full memory library via validated manually carried returns; no per-note confirmation.",
                     "identity_limit": "Host-selected owner/provider label, not authenticated model identity."}
        elif args.command == "start":
            value = bridge.start(task)
        elif args.command == "pending":
            value = bridge.pending(args.session)
        elif args.command == "status":
            value = bridge.status(args.session)
        else:
            value = bridge.accept_return(args.session, content)
        show_result(value, args, root, owner)
        return 1 if value.get("state") in {"reconciliation_required", "round_limit", "error"} else 0
    except (CLIError, BrowserMemoryError, AgentMemoryError) as exc:
        code = getattr(exc, "code", "BROWSER_MEMORY_ERROR")
        if not isinstance(code, str) or not re.fullmatch(r"[A-Z][A-Z0-9_]{0,95}", code):
            code = "BROWSER_MEMORY_ERROR"
        hint = ERROR_HINTS.get(code, "No automatic retry was made. Use status for this session before repeating a submitted return.")
        print(json.dumps({"state": "error", "error": {"code": code}, "message": hint}), file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print(json.dumps({"state": "cancelled", "message": "Input stopped; no automatic retry was made. Check status if a return had already been submitted."}), file=sys.stderr)
        return 130
    except (OSError, UnicodeError):
        print(json.dumps({"state": "error", "error": {"code": "LOCAL_IO_UNAVAILABLE"},
                          "message": "A local input/output operation failed. Check status before repeating a submitted return."}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
