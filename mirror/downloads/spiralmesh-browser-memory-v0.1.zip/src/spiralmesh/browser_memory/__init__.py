"""Local, operator-carried browser memory packets; no provider integration."""
from .session import BrowserMemoryBridge, BrowserMemoryError

__all__ = ["BrowserMemoryBridge", "BrowserMemoryError"]
