"""Bundle-only parent package for the portable browser memory bridge.

The separate legacy SpiralMesh kernel is intentionally not imported or included.
"""
__version__ = "0.1.0-browser-memory"
__license__ = "Apache-2.0"
