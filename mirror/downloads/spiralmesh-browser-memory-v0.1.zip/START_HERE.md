# Start here

Read docs/BROWSER_MEMORY_QUICKSTART.md. First verify with python -B verify_bundle.py.
Windows: SETUP_BROWSER_MEMORY.cmd once per owner, then OPEN_BROWSER_MEMORY.cmd.
Terminal: python -B tools/browser_memory.py setup --owner grok; then start --owner grok.
Python 3.10+ only. No SDK, pip, API key, Ollama or model download.
You carry private packets to and from your chosen browser conversation. The model selects memory actions.
This bridge does not automate the browser or authenticate model identity.
Data stays outside this package until you deliberately transfer a packet. No personal data is included.
