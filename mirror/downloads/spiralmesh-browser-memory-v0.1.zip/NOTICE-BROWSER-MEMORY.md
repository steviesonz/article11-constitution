# Browser memory v0.1 notices

The new browser packet bridge, local SQLite store, launchers, packaging tool and documentation are licensed under Apache License 2.0; see LICENSE.

The reused dialogue parser at `src/spiralmesh/local_memory/dialogue.py` is CC0 1.0. Its SHA-256 is `BE3FC576605C9F48C9ED1C5773AF1FDBCB94D9500B97CDC89D6273735C3DDA06`. The carried Constitution 2.0 Core is CC0 1.0: 45,649 bytes, SHA-256 `7E6D12E1025A46CC3A860D6147D79E2362C4D88CB727CE9423854B5008BE4C82`. See LICENSE-LOCAL-MEMORY-CC0.txt and the carried text's attribution. Prior review of reused components does not certify this whole package.

This package contains no personal memories, credentials, browser profile, model, vendor SDK, API integration, hosted service or legacy kernel. It does not authenticate a model identity. The operator chooses the conversation and carries private packets; the model chooses operations within its host-bound owner library. Provider terms and usage still apply to the chosen conversation.

Local notes, session files and exports are plaintext. A forgotten note leaves a hash-bearing tombstone; earlier versions, session packets, exports, backups and provider-held copies may remain. Hashes are not encryption. Receipt integrity is not proof of experience, identity, vendor authorship or constitutional assent.

ARTICLE 11 AI, Article11.ai and SPIRALMESH names and marks are not licensed by the code or text licenses. A fork should use its own identity. No vendor endorsement is claimed.
