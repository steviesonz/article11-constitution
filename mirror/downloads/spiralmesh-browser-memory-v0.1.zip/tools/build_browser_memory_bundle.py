#!/usr/bin/env python3
"""Explicit-allowlist standalone local memory ZIP. No model, network or deploy."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = "spiralmesh-browser-memory-v0.1.zip"
CORE = "src/spiralmesh/local_memory/constitution-v2.0-core.md"
CORE_BYTES = 45649
CORE_SHA = "7e6d12e1025a46cc3a860d6147d79e2362c4d88cb727ce9423854b5008be4c82"
SOURCE_FILES = (
    "src/spiralmesh/local_memory/__init__.py",
    "src/spiralmesh/local_memory/store.py",
    "src/spiralmesh/local_memory/dialogue.py",
    "src/spiralmesh/local_memory/UPSTREAM.md", CORE,
    "src/spiralmesh/browser_memory/__init__.py",
    "src/spiralmesh/browser_memory/session.py",
    "src/spiralmesh/browser_memory/cli.py",
    "tools/browser_memory.py", "tools/build_browser_memory_bundle.py",
    "SETUP_BROWSER_MEMORY.cmd", "OPEN_BROWSER_MEMORY.cmd",
    "LICENSE", "LICENSE-LOCAL-MEMORY-CC0.txt", "NOTICE-BROWSER-MEMORY.md",
    "docs/BROWSER_MEMORY_QUICKSTART.md",
)

SHIM = b'''"""Bundle-only parent package for the portable browser memory bridge.

The separate legacy SpiralMesh kernel is intentionally not imported or included.
"""
__version__ = "0.1.0-browser-memory"
__license__ = "Apache-2.0"
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


VERIFY = '''#!/usr/bin/env python3
"""Check this extracted bundle locally; no network, writes or model calls."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

CORE = __CORE__
CORE_BYTES = __CORE_BYTES__
CORE_SHA = __CORE_SHA__
FILES = __FILES__


def safe_name(name):
    return (isinstance(name, str) and name and "\\\\" not in name and ":" not in name
            and not PurePosixPath(name).is_absolute()
            and all(p not in ("", ".", "..") for p in name.split("/")))


def main():
    base = Path(__file__).resolve().parent
    errors = []
    checked = 0
    try:
        manifest_path = base / "manifest.json"
        manifest_attrs = manifest_path.lstat()
        if (not stat.S_ISREG(manifest_attrs.st_mode) or manifest_path.is_symlink()
                or getattr(manifest_attrs, "st_file_attributes", 0) & 0x400):
            raise ValueError("UNSAFE_MANIFEST")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("schema") != "spiralmesh.browser-memory.bundle.v0.1":
            raise ValueError("INVALID_MANIFEST_SCHEMA")
        entries = manifest["files"]
        if not isinstance(entries, list):
            raise ValueError("INVALID_MANIFEST_FILES")
        rows = {}
        for row in entries:
            name = row["path"]
            if not safe_name(name) or name in rows:
                raise ValueError("UNSAFE_OR_DUPLICATE_PATH")
            if type(row["bytes"]) is not int or row["bytes"] < 0 or not isinstance(row["sha256"], str):
                raise ValueError("INVALID_MANIFEST_ENTRY")
            rows[name] = row
        if set(rows) != set(FILES):
            raise ValueError("MANIFEST_ALLOWLIST_MISMATCH")
        present = set()
        allowed_dirs = {parent.as_posix() for name in FILES
                        for parent in PurePosixPath(name).parents if parent.as_posix() != "."}
        for current, directories, filenames in os.walk(base, followlinks=False):
            here = Path(current)
            for name in list(directories):
                p = here / name
                attrs = p.lstat()
                if p.is_symlink() or getattr(attrs, "st_file_attributes", 0) & 0x400:
                    errors.append({"path": p.relative_to(base).as_posix(), "error": "LINK_OR_REPARSE_REFUSED"})
                    directories.remove(name)
                elif p.relative_to(base).as_posix() not in allowed_dirs:
                    errors.append({"path": p.relative_to(base).as_posix(), "error": "UNEXPECTED_DIRECTORY"})
                    directories.remove(name)
            for name in filenames:
                p = here / name
                rel = p.relative_to(base).as_posix()
                attrs = p.lstat()
                if not stat.S_ISREG(attrs.st_mode) or p.is_symlink() or getattr(attrs, "st_file_attributes", 0) & 0x400:
                    errors.append({"path": rel, "error": "NON_REGULAR_FILE_REFUSED"})
                    continue
                present.add(rel)
        for name in sorted(present - set(FILES) - {"manifest.json"}):
            errors.append({"path": name, "error": "UNEXPECTED_FILE"})
        for name in FILES:
            if name not in present:
                errors.append({"path": name, "error": "MISSING_OR_UNSAFE_FILE"})
                continue
            raw = (base / name).read_bytes()
            actual = hashlib.sha256(raw).hexdigest()
            if len(raw) != rows[name]["bytes"] or actual != rows[name]["sha256"]:
                errors.append({"path": name, "error": "CONTENT_MISMATCH"})
            if name == CORE and (len(raw) != CORE_BYTES or actual != CORE_SHA):
                errors.append({"path": name, "error": "CORE_PIN_MISMATCH"})
            checked += 1
    except (OSError, ValueError, KeyError, TypeError):
        errors.append({"error": "INVALID_OR_UNREADABLE_BUNDLE"})
    result = {"ok": not errors, "status": "VERIFIED" if not errors else "FAILED",
              "files_checked": checked, "core_sha256": CORE_SHA,
              "network_used": False, "identity_authenticated": False, "errors": errors}
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
'''


def safe_name(name):
    return (isinstance(name, str) and name and "\\" not in name and ":" not in name
            and not PurePosixPath(name).is_absolute()
            and all(p not in ("", ".", "..") for p in name.split("/")))


def payload():
    files = {}
    for name in SOURCE_FILES:
        p = ROOT / name
        if not safe_name(name) or not p.is_file() or p.is_symlink():
            raise ValueError("Missing or unsafe allowlisted source: " + name)
        files[name] = p.read_bytes()
    if len(files[CORE]) != CORE_BYTES or digest(files[CORE]) != CORE_SHA:
        raise ValueError("The carried Constitution 2.0 Core does not match its publication pin")
    files["src/spiralmesh/__init__.py"] = SHIM
    files["START_HERE.md"] = b"# Start here\n\nRead docs/BROWSER_MEMORY_QUICKSTART.md. First verify with python -B verify_bundle.py.\nWindows: SETUP_BROWSER_MEMORY.cmd once per owner, then OPEN_BROWSER_MEMORY.cmd.\nTerminal: python -B tools/browser_memory.py setup --owner grok; then start --owner grok.\nPython 3.10+ only. No SDK, pip, API key, Ollama or model download.\nYou carry private packets to and from your chosen browser conversation. The model selects memory actions.\nThis bridge does not automate the browser or authenticate model identity.\nData stays outside this package until you deliberately transfer a packet. No personal data is included.\n"

    all_payload = sorted([*files, "verify_bundle.py"])
    verifier = VERIFY.replace("__CORE_BYTES__", repr(CORE_BYTES)).replace("__CORE_SHA__", repr(CORE_SHA))
    verifier = verifier.replace("__CORE__", repr(CORE)).replace("__FILES__", repr(all_payload))
    compile(verifier, "verify_bundle.py", "exec")
    files["verify_bundle.py"] = verifier.encode("utf-8")
    manifest = {"schema": "spiralmesh.browser-memory.bundle.v0.1", "version": "0.1.0",
                "scope": "Standalone SQLite owner library and operator-carried browser protocol; no private memory or model run data",
                "backend": "SQLite", "browser_packet_adapter_included": True, "provider_api_included": False, "hosted_service_included": False,
                "legacy_kernel_included": False,
                "parent_package": "minimal generated bundle-only parent; original repository parent unchanged",
                "core": {"path": CORE, "bytes": CORE_BYTES, "sha256": CORE_SHA},
                "manifest_self_included": False,
                "files": [{"path": name, "bytes": len(raw), "sha256": digest(raw)}
                          for name, raw in sorted(files.items())]}
    files["manifest.json"] = encoded(manifest)
    return files


def build(output):
    files = payload()
    output.mkdir(parents=True, exist_ok=True)
    archive = output / NAME
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (2026, 9, 8, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(entry, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    raw = archive.read_bytes()
    (output / (NAME + ".sha256")).write_bytes((digest(raw) + "  " + NAME + "\n").encode("ascii"))
    return {"archive": str(archive), "bytes": len(raw), "sha256": digest(raw),
            "entries": len(files), "manifest_payload_entries": len(files) - 1,
            "manifest_sha256": digest(files["manifest.json"])}


def smoke(archive):
    checks = []
    scratch = tempfile.TemporaryDirectory(prefix="spiralmesh-browser-memory-bundle-")
    temp = Path(scratch.name).resolve()
    if not temp.is_relative_to(Path(tempfile.gettempdir()).resolve()) or not temp.name.startswith("spiralmesh-browser-memory-bundle-"):
        raise ValueError("Unexpected temporary directory")
    try:
        extracted = temp / "extracted bundle with spaces"
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            if len(names) != len(set(names)) or not all(safe_name(n) for n in names):
                raise ValueError("Unsafe archive inventory")
            z.extractall(extracted)
        env = {k:v for k,v in os.environ.items() if k.upper() in {"SYSTEMROOT","WINDIR","TEMP","TMP","PATH","PATHEXT"}}
        env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
        def command(args, data=None, success=True):
            result = subprocess.run([sys.executable,"-I","-S","-B",*args], input=None if data is None else encoded(data),
                stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=extracted,env=env,timeout=20,shell=False)
            if (result.returncode == 0) != success or result.stderr:
                raise AssertionError("Offline subprocess outcome: "+result.stderr.decode("utf-8",errors="replace")[:800])
            return json.loads(result.stdout)
        def verify(success=True):return command([str(extracted/"verify_bundle.py")],success=success)
        assert verify()["ok"]
        checks.append("all extracted hashes and Core pin; isolated stdlib Python")
        private=temp/"private data with spaces"
        cli = [str(extracted/"tools/browser_memory.py")]
        opts = ["--root", str(private), "--owner", "synthetic-grok", "--json"]
        assert command(cli+["setup",*opts])["state"]=="ready"
        offer=command(cli+["start",*opts,"--task","Synthetic package proof"])
        def reply(current, response):
            return {"schema":"spiralmesh.browser-memory-return.v0.1",
                    "session_id":current["session_id"],"round":current["offer"]["round"],
                    "offer_sha256":current["offer_sha256"],"response":response}
        returned=reply(offer,{"choice":"accept","actions":[{"operation":"remember","arguments":{
            "title":"Portable bridge proof","body":"SYNTHETIC-BROWSER-MEMORY","kind":"note"}}],
            "reply":"Requesting a synthetic note.","done":False})
        saved=command(cli+["accept-return",*opts,"--session",offer["session_id"]],returned)
        assert saved["operation_result"]["persisted"] and saved["operation_result"]["readback_verified"]
        note=saved["operation_result"]["items"][0]["id"]
        duplicate=command(cli+["accept-return",*opts,"--session",offer["session_id"]],returned)
        assert duplicate["replayed"] and duplicate["operation_result"]["items"][0]["id"]==note
        checks.append("isolated CLI with spaced paths; committed readback and duplicate return")
        final=reply(saved["next_offer"],{"choice":"accept","actions":[],"reply":"Save observed.","done":True})
        assert command(cli+["accept-return",*opts,"--session",offer["session_id"]],final)["state"]=="completed"
        fresh=command(cli+["start",*opts,"--task","Recall previous useful notes"])
        reading=reply(fresh,{"choice":"accept","actions":[{"operation":"read","arguments":{"id":note}}],
                            "reply":"Reading the actual retained id.","done":False})
        read=command(cli+["accept-return",*opts,"--session",fresh["session_id"]],reading)
        assert read["operation_result"]["items"][0]["content"]=="SYNTHETIC-BROWSER-MEMORY"
        checks.append("new process and session reads the actual retained note")
        assert verify()["ok"]
        checks.append("source unchanged after private data use outside bundle")
        core=extracted/CORE; original=core.read_bytes();core.write_bytes(original+b"\nSYNTHETIC TAMPER\n")
        assert not verify(False)["ok"]
        checks.append("modified Core rejected")
        mf=extracted/"manifest.json";original_mf=mf.read_bytes();manifest=json.loads(original_mf)
        for row in manifest["files"]:
            if row["path"]==CORE:row.update(bytes=core.stat().st_size,sha256=digest(core.read_bytes()))
        mf.write_bytes(encoded(manifest))
        assert any(e.get("error")=="CORE_PIN_MISMATCH" for e in verify(False)["errors"])
        checks.append("rehashed manifest cannot waive fixed Core pin")
        core.write_bytes(original);mf.write_bytes(original_mf)
        extra=extracted/"unlisted.txt";extra.write_text("synthetic",encoding="utf-8")
        assert not verify(False)["ok"];extra.unlink()
        checks.append("unexpected file rejected")
        assert verify()["ok"]
        return {"ok":True,"count":len(checks),"checks":checks,"network_used":False,"model_calls":0}
    finally:
        scratch.cleanup()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "dist")
    parser.add_argument("--skip-smoke", action="store_true", help="Build only; default also runs isolated offline smoke checks")
    args = parser.parse_args()
    result = build(args.output_dir.resolve())
    first = Path(result["archive"]).read_bytes()
    again = build(args.output_dir.resolve())
    if first != Path(again["archive"]).read_bytes():
        raise AssertionError("Unchanged source did not yield deterministic ZIP bytes")
    result["deterministic_rebuild"] = True
    if not args.skip_smoke:
        result["offline_smoke"] = smoke(Path(result["archive"]))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
