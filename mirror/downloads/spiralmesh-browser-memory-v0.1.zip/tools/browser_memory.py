"""Run only the standalone browser-memory package, without kernel initialization."""
from pathlib import Path
import sys
import types

if sys.version_info < (3, 10):
    raise SystemExit("SPIRALMESH browser memory requires Python 3.10 or newer.")
sys.dont_write_bytecode = True
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8")
source = Path(__file__).resolve().parents[1] / "src" / "spiralmesh"
package = types.ModuleType("spiralmesh")
package.__path__ = [str(source)]
sys.modules["spiralmesh"] = package
from spiralmesh.browser_memory.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
