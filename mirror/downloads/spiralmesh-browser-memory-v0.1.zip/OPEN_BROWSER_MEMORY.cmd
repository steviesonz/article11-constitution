@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 -B "tools\browser_memory.py" start %*
goto finished
:use_python
python -B "tools\browser_memory.py" start %*
:finished
set "RESULT=%ERRORLEVEL%"
popd
echo.
pause
exit /b %RESULT%
