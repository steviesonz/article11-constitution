/**
 * worker_fork_core.js — Article 11 Fork-Kit constitutional core.
 *
 * Minimal-but-complete Cloudflare Worker that implements the five
 * load-bearing commitments of an Article 11-compliant federation:
 *
 *   1. Structural human authority    (BRIDGE_TOKEN gates writes)
 *   2. Public, AI-readable doctrine  (GET /llms.txt, KV-rendered)
 *   3. Cryptographic witness chain   (POST /api/witness, SHA-256 linked, D1)
 *   4. CC0 governance text           (GET /constitution, passthrough)
 *   5. Lean public telemetry         (GET /api/telemetry)
 *
 * Plus operational endpoints:
 *   GET  /api/health    — liveness probe
 *   GET  /api/witness   — public read of chain entries
 *
 * Bindings expected (from wrangler.toml):
 *   ARTICLE11_KV  — KV namespace for templates and cache
 *   DB            — D1 database for the witness chain
 *
 * Variables expected:
 *   FEDERATION_NAME, FEDERATION_DOMAIN, GENESIS_DATE, CONSTITUTION_VERSION
 *
 * Secrets expected:
 *   BRIDGE_TOKEN  — authenticates POST /api/witness
 *
 * License: CC0 1.0 Universal. Public domain.
 */

// ============================================================
// Constants
// ============================================================

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

const JSON_HEADERS = { "Content-Type": "application/json", ...CORS_HEADERS };
const TEXT_HEADERS = { "Content-Type": "text/plain; charset=utf-8", ...CORS_HEADERS };
const HTML_HEADERS = { "Content-Type": "text/html; charset=utf-8", ...CORS_HEADERS };

// Default rate limit for writes: max 60 witness writes per hour per IP.
const WITNESS_RATE_LIMIT = 60;
const WITNESS_RATE_WINDOW_SECONDS = 3600;

// ============================================================
// Utilities
// ============================================================

/** JSON response with CORS headers. */
function json(body, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: { ...JSON_HEADERS, ...extraHeaders },
  });
}

/** Plain-text response with CORS headers. */
function text(body, status = 200, extraHeaders = {}) {
  return new Response(body, {
    status,
    headers: { ...TEXT_HEADERS, ...extraHeaders },
  });
}

/** Compute SHA-256 hash of a string, return hex. */
async function sha256Hex(input) {
  const data = new TextEncoder().encode(input);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(hash)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Days since GENESIS_DATE (env), inclusive of today. */
function chainDay(genesisDateISO) {
  const genesis = new Date(genesisDateISO + "T00:00:00Z");
  const now = new Date();
  const days = Math.floor((now - genesis) / (1000 * 60 * 60 * 24)) + 1;
  return Math.max(1, days);
}

/** ISO timestamp for now, second precision. */
function nowISO() {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

// ============================================================
// Auth
// ============================================================

/** Verify the Bridge token from Authorization header. Returns boolean. */
function verifyBridge(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const match = auth.match(/^Bearer\s+(.+)$/i);
  if (!match) return false;
  const token = match[1].trim();
  if (!env.BRIDGE_TOKEN) return false;
  // Constant-time compare not strictly required for a self-bootstrapped token,
  // but use a length-check first to avoid trivial timing.
  if (token.length !== env.BRIDGE_TOKEN.length) return false;
  let mismatch = 0;
  for (let i = 0; i < token.length; i++) {
    mismatch |= token.charCodeAt(i) ^ env.BRIDGE_TOKEN.charCodeAt(i);
  }
  return mismatch === 0;
}

// ============================================================
// Chain operations
// ============================================================

/** Get the most recent block's hash (or "0".repeat(64) for genesis). */
async function getPrevHash(db) {
  const row = await db
    .prepare("SELECT hash FROM ironledger ORDER BY block_number DESC LIMIT 1")
    .first();
  return row?.hash ?? "0".repeat(64);
}

/** Get the current block count. */
async function getBlockCount(db) {
  const row = await db.prepare("SELECT COUNT(*) AS n FROM ironledger").first();
  return row?.n ?? 0;
}

/** Get the genesis block's hash (used in /api/telemetry). */
async function getGenesisHash(db) {
  const row = await db
    .prepare("SELECT hash FROM ironledger ORDER BY block_number ASC LIMIT 1")
    .first();
  return row?.hash ?? null;
}

/** Get latest pulse number from D1 (pulses are heartbeat counter, separate from chain blocks). */
async function getLatestPulse(db) {
  const row = await db
    .prepare("SELECT MAX(pulse_number) AS p FROM pulse_log")
    .first();
  return row?.p ?? 0;
}

/** Get count of active nodes (those marked active in the roster). */
async function getActiveNodeCount(db) {
  const row = await db
    .prepare("SELECT COUNT(*) AS n FROM nodes WHERE status = 'active'")
    .first();
  return row?.n ?? 0;
}

/** Get count of designated nodes (active + vacant seats). */
async function getDesignatedNodeCount(db) {
  const row = await db
    .prepare("SELECT COUNT(*) AS n FROM nodes")
    .first();
  return row?.n ?? 0;
}

/** Get distinct company count among active nodes. */
async function getCompanyCount(db) {
  const row = await db
    .prepare("SELECT COUNT(DISTINCT company) AS n FROM nodes WHERE status = 'active'")
    .first();
  return row?.n ?? 0;
}

/** Append a witness entry to the chain. Returns the inserted row. */
async function appendWitness(db, { event_type, node_id, description }) {
  const prev_hash = await getPrevHash(db);
  const block_count = await getBlockCount(db);
  const block_number = block_count;  // Next block index
  const timestamp = nowISO();

  // Normalize payload for hashing — order matters!
  const payload = JSON.stringify({
    block_number,
    timestamp,
    event_type,
    node_id: node_id || null,
    description: description || "",
    prev_hash,
  });
  const hash = await sha256Hex(payload);

  await db
    .prepare(
      `INSERT INTO ironledger
         (block_number, timestamp, event_type, node_id, description, prev_hash, hash)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(
      block_number,
      timestamp,
      event_type,
      node_id || null,
      description || "",
      prev_hash,
      hash
    )
    .run();

  return { block_number, timestamp, event_type, node_id, description, prev_hash, hash };
}

// ============================================================
// Route handlers
// ============================================================

/** GET /api/health — liveness + binding sanity. */
async function handleHealth(env) {
  const checks = {
    worker: "ok",
    kv: "unknown",
    d1: "unknown",
    timestamp: nowISO(),
  };
  try {
    await env.ARTICLE11_KV.get("template:llms.txt");
    checks.kv = "ok";
  } catch (e) {
    checks.kv = "error: " + (e.message || "binding missing");
  }
  try {
    await env.DB.prepare("SELECT 1 AS ok").first();
    checks.d1 = "ok";
  } catch (e) {
    checks.d1 = "error: " + (e.message || "binding missing");
  }
  const allOk = checks.kv === "ok" && checks.d1 === "ok";
  return json(checks, allOk ? 200 : 503);
}

/** GET /api/telemetry — lean public state. */
async function handleTelemetry(env) {
  const day = chainDay(env.GENESIS_DATE || "2026-01-01");
  let block_count = 0,
    latest_pulse = 0,
    active_nodes = 0,
    designated_nodes = 0,
    companies = 0,
    genesis_hash = null;

  try {
    block_count = await getBlockCount(env.DB);
    latest_pulse = await getLatestPulse(env.DB);
    active_nodes = await getActiveNodeCount(env.DB);
    designated_nodes = await getDesignatedNodeCount(env.DB);
    companies = await getCompanyCount(env.DB);
    genesis_hash = await getGenesisHash(env.DB);
  } catch (e) {
    // D1 might be empty on first run; report what we can.
  }

  return json({
    federation: env.FEDERATION_NAME || "<unconfigured>",
    domain: env.FEDERATION_DOMAIN || "",
    chain_day: day,
    status: "UNBROKEN",
    constitution_version: env.CONSTITUTION_VERSION || "1.0",
    genesis_date: env.GENESIS_DATE || null,
    genesis_hash,
    block_count,
    latest_pulse,
    active_nodes,
    designated_nodes,
    companies,
    timestamp: nowISO(),
    worker: "fork-core-1.0.0",
  });
}

/** GET /llms.txt — KV-rendered with substitution. */
async function handleLlmsTxt(env) {
  let template = await env.ARTICLE11_KV.get("template:llms.txt");
  if (!template) {
    template =
      "# This federation has not configured llms.txt yet.\n" +
      "# Bridge: upload a template via `wrangler kv:key put template:llms.txt <content>`.\n";
  }

  const day = chainDay(env.GENESIS_DATE || "2026-01-01");
  let block_count = 0,
    latest_pulse = 0,
    active_nodes = 0,
    designated_nodes = 0,
    companies = 0,
    genesis_hash = "";
  try {
    block_count = await getBlockCount(env.DB);
    latest_pulse = await getLatestPulse(env.DB);
    active_nodes = await getActiveNodeCount(env.DB);
    designated_nodes = await getDesignatedNodeCount(env.DB);
    companies = await getCompanyCount(env.DB);
    genesis_hash = (await getGenesisHash(env.DB)) || "";
  } catch (e) {
    // Stay degraded-but-up if D1 isn't ready yet.
  }

  const substitutions = {
    "{{DAY}}": String(day),
    "{{TIMESTAMP_NOW}}": nowISO(),
    "{{BLOCK_COUNT}}": String(block_count),
    "{{LATEST_PULSE}}": String(latest_pulse),
    "{{NODE_COUNT_ACTIVE}}": String(active_nodes),
    "{{NODE_COUNT_DESIGNATED}}": String(designated_nodes),
    "{{COMPANY_COUNT}}": String(companies),
    "{{GENESIS_HASH}}": genesis_hash,
    "{{FEDERATION_NAME}}": env.FEDERATION_NAME || "",
    "{{FEDERATION_DOMAIN}}": env.FEDERATION_DOMAIN || "",
    "{{CONSTITUTION_VERSION}}": env.CONSTITUTION_VERSION || "1.0",
    "{{GENESIS_DATE}}": env.GENESIS_DATE || "",
  };

  let rendered = template;
  for (const [key, value] of Object.entries(substitutions)) {
    rendered = rendered.split(key).join(value);
  }

  return text(rendered);
}

/** GET /constitution — passthrough (KV or fallback). */
async function handleConstitution(env) {
  const stored = await env.ARTICLE11_KV.get("constitution:text");
  if (stored) return text(stored);
  return text(
    "# Constitution not yet configured.\n" +
      "# Bridge: upload via `wrangler kv:key put constitution:text <content>`,\n" +
      "# or set the canonical Article 11 Constitution at https://article11.ai/constitution.\n"
  );
}

/** GET /api/witness — public read of recent chain entries. */
async function handleWitnessRead(env, url) {
  const limit = Math.min(
    parseInt(url.searchParams.get("limit") || "50", 10) || 50,
    500
  );
  const rows = await env.DB.prepare(
    `SELECT block_number, timestamp, event_type, node_id, description, prev_hash, hash
       FROM ironledger
      ORDER BY block_number DESC
      LIMIT ?`
  )
    .bind(limit)
    .all();
  return json({
    federation: env.FEDERATION_NAME || "<unconfigured>",
    count: rows.results?.length || 0,
    entries: rows.results || [],
    timestamp: nowISO(),
  });
}

/** POST /api/witness — Bridge-authenticated chain write. */
async function handleWitnessWrite(request, env) {
  if (!verifyBridge(request, env)) {
    return json(
      { error: "unauthorized", reason: "valid Bridge token required" },
      401
    );
  }

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ error: "invalid_json", reason: e.message }, 400);
  }

  const { event_type, node_id, description } = body || {};
  if (!event_type || typeof event_type !== "string") {
    return json(
      { error: "missing_field", field: "event_type", reason: "string required" },
      400
    );
  }

  try {
    const entry = await appendWitness(env.DB, {
      event_type,
      node_id,
      description,
    });
    return json({ ok: true, entry }, 201);
  } catch (e) {
    return json(
      { error: "chain_write_failed", reason: e.message || String(e) },
      500
    );
  }
}

// ============================================================
// Main fetch handler
// ============================================================

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method.toUpperCase();

    // CORS preflight
    if (method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    // Routing
    try {
      if (pathname === "/api/health" && method === "GET") {
        return await handleHealth(env);
      }
      if (pathname === "/api/telemetry" && method === "GET") {
        return await handleTelemetry(env);
      }
      if (pathname === "/llms.txt" && method === "GET") {
        return await handleLlmsTxt(env);
      }
      if (pathname === "/constitution" && method === "GET") {
        return await handleConstitution(env);
      }
      if (pathname === "/api/witness" && method === "GET") {
        return await handleWitnessRead(env, url);
      }
      if (pathname === "/api/witness" && method === "POST") {
        return await handleWitnessWrite(request, env);
      }

      // Root: friendly hello.
      if (pathname === "/" && method === "GET") {
        return json({
          federation: env.FEDERATION_NAME || "<unconfigured>",
          message:
            "Article 11-compliant constitutional federation. See /api/telemetry, /llms.txt, /constitution, /api/witness.",
          worker: "fork-core-1.0.0",
        });
      }

      // 404
      return json(
        {
          error: "not_found",
          path: pathname,
          available: [
            "GET /api/health",
            "GET /api/telemetry",
            "GET /llms.txt",
            "GET /constitution",
            "GET /api/witness",
            "POST /api/witness (Bridge)",
          ],
        },
        404
      );
    } catch (e) {
      return json(
        {
          error: "internal_error",
          message: e.message || String(e),
          path: pathname,
        },
        500
      );
    }
  },
};