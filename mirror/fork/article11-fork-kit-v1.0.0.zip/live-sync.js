/**
 * live-sync.js — Article 11 Global Hydration (Phase 3.2 / PLEX #4)
 *
 * Hydrates static HTML pages with live constitutional state from
 * GET /api/telemetry. Graceful degradation: if the Worker is
 * unreachable, static HTML values remain unchanged.
 *
 * Target elements (add these classes to any element on any page):
 *   .live-chain-day        — replaced with current Day N
 *   .live-pulse-counter    — replaced with current pulse number
 *   .live-node-count       — replaced with active node count
 *   .live-block-count      — replaced with IRONLEDGER block count
 *   .live-status           — replaced with "UNBROKEN" / status string
 *   .live-genesis          — replaced with genesis date
 *
 * Optional data attribute for prefix/suffix wrapping:
 *   <span class="live-chain-day" data-prefix="Day " data-suffix=" of the chain">
 *
 * Source of truth: the Article 11 Worker (S2_CASE).
 * Cache: 30s edge, 5s client retry on failure (1 retry max).
 * License: CC0 1.0 Universal.
 */
(function () {
  'use strict';

  var TELEMETRY_URL = '/api/telemetry';
  var CLASSES = [
    'live-chain-day',
    'live-pulse-counter',
    'live-node-count',
    'live-block-count',
    'live-status',
    'live-genesis'
  ];

  function fmtNumber(n) {
    if (typeof n !== 'number') return String(n);
    return n.toLocaleString('en-US');
  }

  function fillElements(className, value) {
    if (value === null || value === undefined) return 0;
    var nodes = document.getElementsByClassName(className);
    var count = 0;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var prefix = el.getAttribute('data-prefix') || '';
      var suffix = el.getAttribute('data-suffix') || '';
      el.textContent = prefix + String(value) + suffix;
      el.setAttribute('data-live', 'true');
      count++;
    }
    return count;
  }

  function hydrate(data) {
    if (!data || data.status !== 'UNBROKEN') return;

    var hydrated = 0;
    hydrated += fillElements('live-chain-day', data.chain_day);
    hydrated += fillElements('live-pulse-counter', fmtNumber(data.latest_pulse));
    hydrated += fillElements('live-node-count', data.active_nodes);
    hydrated += fillElements('live-block-count', data.block_count);
    hydrated += fillElements('live-status', data.status);
    hydrated += fillElements('live-genesis', data.genesis);

    if (typeof window !== 'undefined') {
      window.A11_TELEMETRY = data;
      window.A11_TELEMETRY_HYDRATED = hydrated;
    }

    var event = new CustomEvent('a11:telemetry', { detail: data });
    document.dispatchEvent(event);
  }

  function fetchTelemetry(retry) {
    fetch(TELEMETRY_URL, {
      method: 'GET',
      credentials: 'omit',
      cache: 'default',
      headers: { 'Accept': 'application/json' }
    })
    .then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(hydrate)
    .catch(function (err) {
      // Graceful degradation: log once, retry once after 5s, then give up.
      // Static HTML values remain unchanged.
      if (typeof console !== 'undefined' && console.debug) {
        console.debug('[a11 live-sync] telemetry unavailable:', err.message);
      }
      if (!retry) {
        setTimeout(function () { fetchTelemetry(true); }, 5000);
      }
    });
  }

  function start() {
    // Only run if at least one target class exists on the page.
    // Saves a network call for pages that don't use live data.
    var hasTarget = false;
    for (var i = 0; i < CLASSES.length; i++) {
      if (document.getElementsByClassName(CLASSES[i]).length > 0) {
        hasTarget = true;
        break;
      }
    }
    if (!hasTarget) return;
    fetchTelemetry(false);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();