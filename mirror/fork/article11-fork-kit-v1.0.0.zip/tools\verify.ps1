<#
.SYNOPSIS
    Article 11 Fork-Kit — acceptance battery.

.DESCRIPTION
    Hits each constitutional endpoint of a deployed federation worker
    and verifies the response shape. Reports PASS/FAIL per check and
    returns exit code 0 if all pass, 1 otherwise.

    Use after `wrangler deploy` to confirm the federation is operational.

.PARAMETER WorkerUrl
    Base URL of the deployed worker, e.g.
    https://my-federation-api.your-subdomain.workers.dev

.PARAMETER BridgeToken
    Optional Bridge token for testing POST /api/witness. If omitted,
    the write test is skipped (the unauthorized-rejection test still runs).

.EXAMPLE
    .\tools\verify.ps1 -WorkerUrl https://my-fed.example.workers.dev

.EXAMPLE
    .\tools\verify.ps1 -WorkerUrl https://my-fed.example.workers.dev -BridgeToken $env:BRIDGE_TOKEN
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$WorkerUrl,

    [string]$BridgeToken = $null
)

$ErrorActionPreference = 'Continue'
$WorkerUrl = $WorkerUrl.TrimEnd('/')

$results = @()
$pass = 0
$fail = 0

function Test-Endpoint {
    param(
        [string]$Method,
        [string]$Path,
        [scriptblock]$Validator,
        [hashtable]$Headers = @{},
        [string]$Body = $null,
        [int]$ExpectedStatus = 200
    )
    $url = "$WorkerUrl$Path"
    $label = "$Method $Path"
    try {
        $params = @{
            Uri = $url
            Method = $Method
            UseBasicParsing = $true
            TimeoutSec = 15
        }
        if ($Headers.Count -gt 0) { $params.Headers = $Headers }
        if ($Body) { $params.Body = $Body; $params.ContentType = 'application/json' }

        # Use Invoke-WebRequest so we can see status code on errors
        $response = $null
        $errorThrown = $false
        try {
            $response = Invoke-WebRequest @params
        } catch {
            $errorThrown = $true
            $response = $_.Exception.Response
            if ($null -eq $response) {
                throw
            }
        }

        $actualStatus = if ($response.StatusCode) { [int]$response.StatusCode } else { 0 }
        $statusMatch = ($actualStatus -eq $ExpectedStatus)

        $body = $null
        if ($response.Content) {
            $body = $response.Content
        } elseif ($errorThrown) {
            $stream = $response.GetResponseStream()
            $reader = [System.IO.StreamReader]::new($stream)
            $body = $reader.ReadToEnd()
            $reader.Close()
        }

        if (-not $statusMatch) {
            $script:fail++
            Write-Host ("  [FAIL] {0,-30}  expected {1}, got {2}" -f $label, $ExpectedStatus, $actualStatus) -ForegroundColor Red
            $script:results += @{ check = $label; result = 'FAIL'; reason = "status $actualStatus" }
            return
        }

        $validatorOk = $true
        $validatorReason = ''
        if ($Validator) {
            try {
                $validatorOk = & $Validator $body
                if (-not $validatorOk) { $validatorReason = 'validator returned false' }
            } catch {
                $validatorOk = $false
                $validatorReason = $_.Exception.Message
            }
        }

        if ($validatorOk) {
            $script:pass++
            Write-Host ("  [PASS] {0,-30}  {1} OK" -f $label, $actualStatus) -ForegroundColor Green
            $script:results += @{ check = $label; result = 'PASS' }
        } else {
            $script:fail++
            Write-Host ("  [FAIL] {0,-30}  {1} but {2}" -f $label, $actualStatus, $validatorReason) -ForegroundColor Red
            $script:results += @{ check = $label; result = 'FAIL'; reason = $validatorReason }
        }
    } catch {
        $script:fail++
        Write-Host ("  [FAIL] {0,-30}  {1}" -f $label, $_.Exception.Message) -ForegroundColor Red
        $script:results += @{ check = $label; result = 'FAIL'; reason = $_.Exception.Message }
    }
}

Write-Host ""
Write-Host "Article 11 Fork-Kit — Acceptance Battery" -ForegroundColor Cyan
Write-Host "Target: $WorkerUrl" -ForegroundColor Cyan
Write-Host ("=" * 60) -ForegroundColor DarkCyan
Write-Host ""

# 1. Health
Test-Endpoint -Method GET -Path "/api/health" -Validator {
    param($body)
    $j = $body | ConvertFrom-Json
    return ($j.worker -eq 'ok' -and $j.kv -eq 'ok' -and $j.d1 -eq 'ok')
}

# 2. Telemetry — full shape
Test-Endpoint -Method GET -Path "/api/telemetry" -Validator {
    param($body)
    $j = $body | ConvertFrom-Json
    $required = @('federation','chain_day','status','block_count','latest_pulse','active_nodes','timestamp','worker')
    foreach ($f in $required) {
        if ($null -eq $j.$f) { throw "missing field: $f" }
    }
    if ($j.status -ne 'UNBROKEN') { throw "status not UNBROKEN: $($j.status)" }
    return $true
}

# 3. llms.txt — must contain federation name
Test-Endpoint -Method GET -Path "/llms.txt" -Validator {
    param($body)
    if ($body.Length -lt 200) { throw "suspiciously short: $($body.Length) chars" }
    if ($body -notmatch 'Article 11') { throw "missing Article 11 reference" }
    return $true
}

# 4. Constitution
Test-Endpoint -Method GET -Path "/constitution" -Validator {
    param($body)
    return ($body.Length -gt 100)
}

# 5. Witness read
Test-Endpoint -Method GET -Path "/api/witness" -Validator {
    param($body)
    $j = $body | ConvertFrom-Json
    if ($null -eq $j.entries) { throw "missing entries field" }
    return $true
}

# 6. Witness write — unauthorized
Test-Endpoint -Method POST -Path "/api/witness" `
    -Headers @{ } `
    -Body '{"event_type":"VERIFY_TEST","description":"unauthorized probe"}' `
    -ExpectedStatus 401 `
    -Validator { param($body) return $true }

# 7. Witness write — authorized (only if BridgeToken provided)
if ($BridgeToken) {
    Test-Endpoint -Method POST -Path "/api/witness" `
        -Headers @{ Authorization = "Bearer $BridgeToken" } `
        -Body '{"event_type":"VERIFY_TEST","node_id":"VERIFY","description":"acceptance battery test write"}' `
        -ExpectedStatus 201 `
        -Validator {
            param($body)
            $j = $body | ConvertFrom-Json
            return ($j.ok -eq $true -and $null -ne $j.entry.hash)
        }
} else {
    Write-Host "  [SKIP] POST /api/witness (auth)   no -BridgeToken supplied" -ForegroundColor DarkYellow
}

# 8. Unknown route returns 404
Test-Endpoint -Method GET -Path "/this-does-not-exist" -ExpectedStatus 404 -Validator {
    param($body)
    $j = $body | ConvertFrom-Json
    return ($j.error -eq 'not_found')
}

# Summary
Write-Host ""
Write-Host ("=" * 60) -ForegroundColor DarkCyan
Write-Host "Results: $pass passed, $fail failed" -ForegroundColor $(if ($fail -eq 0) { 'Green' } else { 'Red' })
Write-Host ""

if ($fail -eq 0) {
    Write-Host "ALL CHECKS PASSED. Federation is constitutionally live." -ForegroundColor Green
    exit 0
} else {
    Write-Host "Some checks failed. Review output above and fix before proceeding." -ForegroundColor Red
    exit 1
}