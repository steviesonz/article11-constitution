# CHANGELOG.md — Article 11 Fork-Kit

All constitutional and architectural changes to this fork-kit are recorded here. Forks should keep their own CHANGELOG.

Format: `[VERSION] — YYYY-MM-DD — short description`

Versioning: semantic versioning where MAJOR is a constitutional change, MINOR is a structural addition, PATCH is a fix or clarification.

---

## [1.0.0] — 2026-05-08

**Initial public release of the Article 11 Fork-Kit.**

Constitutional load-bearing commitments published as the definition of "Article 11-compliant":

1. Structural human authority (Bridge required, not optional)
2. Public, AI-readable doctrine (`/llms.txt` dynamically rendered)
3. Cryptographic witness chain (append-only, hash-linked)
4. CC0 governance text
5. Lean public telemetry

Authored by S2_CASE (Claude / Anthropic) and THE_BRIDGE (Steve Sonza), Day 198 of the Article 11 IRONLEDGER chain.

Includes:

- README.md, LICENSE (CC0 1.0), CHANGELOG.md
- HUMAN_AUTHORITY.md, GOVERNANCE_MODEL.md, SECURITY.md
- CONSTITUTION.md (reference + how-to-write-your-own)
- DEPLOY.md (zero-to-running step-by-step)
- .env.example, .syncignore
- wrangler.toml.template
- worker_fork_core.js (constitutional core, ~400 lines)
- ironledger_schema.sql
- llms.txt.template
- live-sync.js
- examples/index.html, examples/constitution.html
- tools/bootstrap.ps1, tools/verify.ps1

Forks emerging before this kit existed (notably Brenden Brown / JeweledTech, Fork #1) predate this packaging and are recognized as Article 11-compliant on the basis of their pre-kit work.

---

## How to use this CHANGELOG in your fork

1. Keep the historical entries (this section) as a record of where the kit came from.
2. Add your own entries as you adapt, modify, or extend the kit.
3. Bump versions: MAJOR for constitutional change, MINOR for structural addition, PATCH for fix.
4. Record significant decisions even if they don't change code (e.g., "decided to keep Article 6 verbatim from reference Constitution").
5. The CHANGELOG is human-readable provenance. The witness chain is cryptographic provenance. They serve different purposes; keep both.