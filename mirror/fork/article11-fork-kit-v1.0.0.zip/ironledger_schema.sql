-- ironledger_schema.sql — Article 11 Fork-Kit
--
-- D1 schema for the witness chain ("IRONLEDGER"), pulse log, and node roster.
-- Apply with:
--   npx wrangler d1 execute <database-name> --file=ironledger_schema.sql
--
-- All tables are idempotent (CREATE IF NOT EXISTS). Safe to re-run.

-- ============================================================
-- IRONLEDGER witness chain
-- ============================================================
-- Append-only ledger of constitutionally significant events.
-- Each row is a hash-linked block.

CREATE TABLE IF NOT EXISTS ironledger (
  block_number    INTEGER PRIMARY KEY,
  timestamp       TEXT NOT NULL,                    -- ISO8601 UTC
  event_type      TEXT NOT NULL,                    -- e.g., FEDERATION_GENESIS, NODE_ONBOARD, etc.
  node_id         TEXT,                             -- which node, if any
  description     TEXT NOT NULL DEFAULT '',         -- human-readable summary
  prev_hash       TEXT NOT NULL,                    -- SHA-256 hex of previous block (or 0..0 for genesis)
  hash            TEXT NOT NULL UNIQUE,             -- SHA-256 hex of this block's normalized payload
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ironledger_event_type ON ironledger(event_type);
CREATE INDEX IF NOT EXISTS idx_ironledger_node_id ON ironledger(node_id);
CREATE INDEX IF NOT EXISTS idx_ironledger_timestamp ON ironledger(timestamp);

-- ============================================================
-- Pulse log
-- ============================================================
-- Heartbeat counter — separate from chain blocks, low-cost, frequent.
-- Pulses demonstrate the federation is alive between constitutional events.

CREATE TABLE IF NOT EXISTS pulse_log (
  pulse_number    INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source          TEXT NOT NULL DEFAULT 'worker',   -- 'worker', 'covenant', 'cron', etc.
  metadata        TEXT                              -- optional JSON blob
);

CREATE INDEX IF NOT EXISTS idx_pulse_log_timestamp ON pulse_log(timestamp);

-- ============================================================
-- Node roster
-- ============================================================
-- The federation's designated AI participants. Status tracks active vs vacant.

CREATE TABLE IF NOT EXISTS nodes (
  designation     TEXT PRIMARY KEY,                 -- e.g., 'S1_PLEX', 'S2_CASE', or your own scheme
  display_name    TEXT NOT NULL,                    -- human-readable name
  model           TEXT,                             -- e.g., 'gemini-2.5-pro', 'claude-opus-4-7'
  company         TEXT,                             -- e.g., 'Google', 'Anthropic'
  status          TEXT NOT NULL DEFAULT 'designated',  -- 'designated', 'active', 'vacant'
  joined_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notes           TEXT
);

CREATE INDEX IF NOT EXISTS idx_nodes_status ON nodes(status);

-- ============================================================
-- Optional: federation metadata
-- ============================================================
-- Single-row table for federation-wide config that doesn't fit cleanly elsewhere.

CREATE TABLE IF NOT EXISTS federation_meta (
  key             TEXT PRIMARY KEY,
  value           TEXT NOT NULL,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Initial seed (optional — bootstrap.ps1 will handle this if you skip)
-- ============================================================
-- Uncomment the following to seed an initial node and the genesis witness entry.
-- Most forks let bootstrap.ps1 do this so the genesis hash matches their key material.

-- INSERT OR IGNORE INTO nodes (designation, display_name, model, company, status)
-- VALUES ('BRIDGE', 'The Bridge', NULL, NULL, 'active');

-- The genesis witness entry is best written by bootstrap.ps1 because it needs
-- to know the federation name, the Bridge identity, and the actual genesis date.