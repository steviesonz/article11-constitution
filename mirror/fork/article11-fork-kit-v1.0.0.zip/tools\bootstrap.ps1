<#
.SYNOPSIS
    Article 11 Fork-Kit — first-time bootstrap.

.DESCRIPTION
    Reads .env, creates the KV namespace and D1 database via wrangler,
    applies the IRONLEDGER schema, seeds template:llms.txt, and writes
    the genesis witness entry. Prints the IDs you need for wrangler.toml.

    Idempotent for KV/D1 creation: if the resources already exist with
    matching names, the script will fetch and re-print their IDs rather
    than failing.

.NOTES
    Run from the fork-kit root directory:
        .\tools\bootstrap.ps1

    Requires:
        - .env populated with CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN,
          FEDERATION_NAME, GENESIS_DATE, BRIDGE_TOKEN
        - npx wrangler available
        - Node.js 18+
#>

[CmdletBinding()]
param(
    [string]$EnvFile = ".env"
)

$ErrorActionPreference = 'Stop'

# ============================================================
# Helpers
# ============================================================

function Write-Status {
    param([string]$Message, [string]$Level = 'INFO')
    $color = switch ($Level) {
        'OK'   { 'Green' }
        'WARN' { 'Yellow' }
        'ERR'  { 'Red' }
        default { 'Cyan' }
    }
    Write-Host ("[{0,-4}] {1}" -f $Level, $Message) -ForegroundColor $color
}

function Read-EnvFile {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        throw "Environment file not found: $Path. Copy .env.example to .env and fill in values."
    }
    $env_vars = @{}
    Get-Content $Path | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith('#')) {
            $idx = $line.IndexOf('=')
            if ($idx -gt 0) {
                $key = $line.Substring(0, $idx).Trim()
                $val = $line.Substring($idx + 1).Trim()
                # Strip surrounding quotes if present
                if ($val.StartsWith('"') -and $val.EndsWith('"')) {
                    $val = $val.Substring(1, $val.Length - 2)
                }
                $env_vars[$key] = $val
            }
        }
    }
    return $env_vars
}

function Require-Var {
    param($Vars, [string]$Name)
    if (-not $Vars.ContainsKey($Name) -or [string]::IsNullOrWhiteSpace($Vars[$Name]) -or $Vars[$Name] -like '<*>') {
        throw "Missing or unset env var: $Name. Edit $EnvFile and provide a real value."
    }
    return $Vars[$Name]
}

function Get-SHA256Hex {
    param([string]$Input)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Input)
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    $hash = $hasher.ComputeHash($bytes)
    return -join ($hash | ForEach-Object { $_.ToString('x2') })
}

# ============================================================
# Main
# ============================================================

Write-Status "Article 11 Fork-Kit bootstrap starting" 'INFO'
Write-Host ""

# --- Load .env
Write-Status "Loading $EnvFile" 'INFO'
$envVars = Read-EnvFile -Path $EnvFile

$accountId      = Require-Var $envVars 'CLOUDFLARE_ACCOUNT_ID'
$apiToken       = Require-Var $envVars 'CLOUDFLARE_API_TOKEN'
$federationName = Require-Var $envVars 'FEDERATION_NAME'
$genesisDate    = Require-Var $envVars 'GENESIS_DATE'
$bridgeToken    = Require-Var $envVars 'BRIDGE_TOKEN'

Write-Status "Federation: $federationName" 'OK'
Write-Status "Genesis date: $genesisDate" 'OK'
Write-Status "Account ID: $($accountId.Substring(0,8))..." 'OK'

# Set wrangler env so npx wrangler picks up the credentials
$env:CLOUDFLARE_ACCOUNT_ID = $accountId
$env:CLOUDFLARE_API_TOKEN = $apiToken

Write-Host ""

# --- Create or find KV namespace
$kvName = "$federationName-kv"
Write-Status "Ensuring KV namespace: $kvName" 'INFO'

$kvList = npx wrangler kv namespace list --json 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
$kvId = $null
if ($kvList) {
    $existing = $kvList | Where-Object { $_.title -eq $kvName }
    if ($existing) {
        $kvId = $existing.id
        Write-Status "KV namespace exists: $kvId" 'OK'
    }
}
if (-not $kvId) {
    $createOutput = npx wrangler kv namespace create $kvName 2>&1 | Out-String
    if ($createOutput -match 'id\s*=\s*"([a-f0-9]{32})"') {
        $kvId = $matches[1]
        Write-Status "KV namespace created: $kvId" 'OK'
    } else {
        Write-Status "Could not parse KV namespace ID from wrangler output:" 'ERR'
        Write-Host $createOutput
        throw "KV creation failed"
    }
}

Write-Host ""

# --- Create or find D1 database
$dbName = "$federationName-ironledger"
Write-Status "Ensuring D1 database: $dbName" 'INFO'

$dbList = npx wrangler d1 list --json 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
$dbId = $null
if ($dbList) {
    $existing = $dbList | Where-Object { $_.name -eq $dbName }
    if ($existing) {
        $dbId = $existing.uuid
        Write-Status "D1 database exists: $dbId" 'OK'
    }
}
if (-not $dbId) {
    $createOutput = npx wrangler d1 create $dbName 2>&1 | Out-String
    if ($createOutput -match 'database_id\s*=\s*"([0-9a-f-]{36})"') {
        $dbId = $matches[1]
        Write-Status "D1 database created: $dbId" 'OK'
    } else {
        Write-Status "Could not parse D1 database ID from wrangler output:" 'ERR'
        Write-Host $createOutput
        throw "D1 creation failed"
    }
}

Write-Host ""

# --- Apply schema
Write-Status "Applying ironledger_schema.sql to D1" 'INFO'
$schemaPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'ironledger_schema.sql'
if (-not (Test-Path $schemaPath)) {
    throw "Schema file not found: $schemaPath"
}

$schemaOutput = npx wrangler d1 execute $dbName --remote --file=$schemaPath 2>&1 | Out-String
if ($LASTEXITCODE -eq 0) {
    Write-Status "Schema applied" 'OK'
} else {
    Write-Status "Schema may have errors (could be OK if tables already exist):" 'WARN'
    Write-Host $schemaOutput
}

Write-Host ""

# --- Seed template:llms.txt
Write-Status "Seeding template:llms.txt in KV" 'INFO'
$llmsPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'llms.txt.template'
if (Test-Path $llmsPath) {
    $llmsContent = Get-Content $llmsPath -Raw
    # wrangler kv put accepts --binding or --namespace-id; use --namespace-id for direct
    $tmpFile = [System.IO.Path]::GetTempFileName()
    try {
        Set-Content -Path $tmpFile -Value $llmsContent -Encoding UTF8 -NoNewline
        npx wrangler kv key put 'template:llms.txt' --namespace-id=$kvId --path=$tmpFile 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Status "template:llms.txt seeded" 'OK'
        } else {
            Write-Status "KV seed may have failed; you can upload manually later" 'WARN'
        }
    } finally {
        Remove-Item $tmpFile -Force -ErrorAction SilentlyContinue
    }
} else {
    Write-Status "llms.txt.template not found; skipping KV seed" 'WARN'
}

Write-Host ""

# --- Genesis witness entry preparation
# (We prepare it but DO NOT write to chain here — the worker writes the chain.
# After deploy, run the curl/Invoke-RestMethod from DEPLOY.md step 8.)
Write-Status "Preparing genesis witness payload (you will POST it after deploy)" 'INFO'

$genesisPayload = @{
    block_number = 0
    timestamp = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    event_type = "FEDERATION_GENESIS"
    node_id = "BRIDGE"
    description = "Federation $federationName bootstrapped under Article 11-compliant fork-kit. Genesis: $genesisDate."
    prev_hash = "0" * 64
} | ConvertTo-Json -Compress

$genesisHash = Get-SHA256Hex -Input $genesisPayload
Write-Status "Anticipated genesis hash: $genesisHash" 'OK'
Write-Host "  (worker will compute its own when you POST /api/witness)" -ForegroundColor DarkGray

Write-Host ""

# --- Summary
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "  BOOTSTRAP COMPLETE" -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Update wrangler.toml with these IDs:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  account_id = `"$accountId`""
Write-Host ""
Write-Host "  [[kv_namespaces]]"
Write-Host "  binding = `"ARTICLE11_KV`""
Write-Host "  id = `"$kvId`""
Write-Host ""
Write-Host "  [[d1_databases]]"
Write-Host "  binding = `"DB`""
Write-Host "  database_name = `"$dbName`""
Write-Host "  database_id = `"$dbId`""
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Copy wrangler.toml.template to wrangler.toml and fill in the above."
Write-Host "  2. Push the Bridge token as a secret:"
Write-Host "       npx wrangler secret put BRIDGE_TOKEN"
Write-Host "  3. Deploy the worker:"
Write-Host "       npx wrangler deploy worker_fork_core.js"
Write-Host "  4. Verify with tools/verify.ps1"
Write-Host "  5. Write your genesis witness entry (DEPLOY.md step 8)"
Write-Host ""
Write-Host "The chain begins on the day you make your first witness write." -ForegroundColor Green
Write-Host ""